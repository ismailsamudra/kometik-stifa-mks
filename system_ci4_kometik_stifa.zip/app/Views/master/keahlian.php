<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <a href="javascript:void(0);" onclick="add()" class="btn-sm bt-1 float-left" title="ADD"><i class="fa fa-plus"></i></a>
            <h5>
                <a href="" style="color: <?= color('primary-b') ?>;">
                    <small>
                        <strong>
                            <i class="fab fa-nintendo-switch mr-2"></i> <?= strtoupper(str_replace('/', ' ', XURI)) ?>
                        </strong>
                    </small>
                </a>
                <a href="javascript:void(0);" onclick="$('#dguser').datagrid('reload');" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
            </h5>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<input type="hidden" id="idx">
<div class="row m-2">
    <div class="col-md-9 mb-2 mt-2 table-responsive">
        <div class="row">

            <div class="col-12" id="fo1">
                <center>
                    <table id="dguser" toolbar="#toolbarCustomer" class="easyui-datagrid" singleSelect="true" style="width: 100%;height:500px;" fitColumns="true" rowNumbers="true" pagination="true" url="<?= XROOT ?>master/get_keahlian" pageSize="10" pageList="[10,25,50,75,100,125,150,200]">
                        <thead>
                            <tr>
                                <th field="pur_res" width="100%" formatter="show_res"></th>
                            </tr>
                        </thead>
                    </table>
                </center>
            </div>

        </div>

    </div>
    <div class="col-md-3 mb-2 mt-2 table-responsive">
        <div class="container">
            <div class="">
                <strong>
                    M-BOOK :
                </strong>
                <hr>
                Doubel Klick pada baris data Untuk Edit.
                <hr>
                Untuk Menu Lain Klick Kanan jika desktop dan sentuh tahan jika HP.
                <hr>
            </div>
            <br>
            <br>
            <br>
        </div>
        <center>
            <i class="fab fa-nintendo-switch fa-5x"></i><br>
            <strong>
                <?= strtoupper(str_replace('/', ' ', XURI)) ?>
            </strong><br>
        </center>
    </div>
</div>
<!-- BODY END -->
<!-- TOOLBAR START -->
<div id="toolbarCustomer">
    <div class="row">
        <div class="col-md-5">
            <!---------SEARCH BOX START--------->
            <input id="searchCustomer" class="easyui-searchbox" data-options="prompt:'Cari..',searcher:doSearchCustomer,
            inputEvents: $.extend({}, $.fn.searchbox.defaults.inputEvents, {
                keyup: function(e){
                    var t = $(e.data.target);
                    var opts = t.searchbox('options');
                    t.searchbox('setValue', $(this).val());
                    opts.searcher.call(t[0],t.searchbox('getValue'),t.searchbox('getName'));
                }
            })
        " style="width:100%;"></input>
            <script>
                //-----------------------------------------start
                function doSearchCustomer() {
                    $('#dguser').datagrid('load', {
                        search_customer: $('#searchCustomer').val()
                    });
                }
                //-----------------------------------------end
            </script>
            <!---------SEARCH BOX END----------->
        </div>
    </div>
</div>
<!-- KLICK KANAN START -->
<div id="mm" class="easyui-menu">
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="edit();"><i class="fa fa-edit mr-2"></i>Edit</a>
    <a href="javascript:void(0)" class="btn-sm form-control" plain="true" onClick="destroyuser();"><i class="fa fa-trash mr-2 text-danger"></i> Hapus</a>
</div>
<!-- KLICK KANAN END -->
<!-- Start Modal 1 -->
<div class="modal fade" id="edit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div id="head"></div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form id="fm" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="id" id="id">
                    <label for=""><small>Nama Keahlian [ Wajib ]</small></label>
                    <input type="text" name="nama" id="nama" class="form-control">
                    <label for=""><small>Alias Indo [ Wajib Untuk Sertifikat ]</small></label>
                    <input type="text" name="alias_ind" id="alias_ind" class="form-control">
                    <label for=""><small>Alias Eng [ Wajib Untuk Sertifikat ]</small></label>
                    <input type="text" name="alias_eng" id="alias_eng" class="form-control">
                    <div class="row">
                        <div class="col-md-8">
                            <label for=""><small>Biaya [ Rp. <span id="lb_harga"></span> ]</small></label>
                            <input type="text" name="harga" id="harga" onkeyup="lb_harga(this.value);" class="form-control">
                        </div>
                        <div class="col-md-4">
                            <label for=""><small>Kode EC [ Wajib ]</small></label>
                            <input type="text" name="kode" id="kode" class="form-control">
                        </div>
                    </div>
                    <div class="row my-2">
                        <div class="col-md-4">
                            <label for=""><small>Status</small></label>
                        </div>
                        <div class="col-md-4">
                            <input type="radio" name="status" id="status1" value="true"> ENABLE
                        </div>
                        <div class="col-md-4">
                            <input type="radio" name="status" id="status2" value="false"> DISABLE
                        </div>
                    </div>

                </form>

            </div>
            <div class="modal-footer">
                <a href="javascript:void(0);" onclick="save();" class="btn btn-outline-dark btn-sm"><i class="fa fa-save mr-2"></i>Save</a>
            </div>

        </div>
    </div>
</div>
<!-- End Modal 1-->
<!-- TOOLBAR END -->
<script type="text/javascript">
    //-----------------------------------------start
    function add() {
        $('#fm').form('clear');
        document.getElementById("status1").checked = true;
        document.getElementById("head").innerHTML = '<h5 class="modal-title"><i class="fa fa-plus mr-2"></i>Tambah Data</h5>';
        document.getElementById("id").value = 'insert';
        $('#edit').modal('show');

    }
    //-----------------------------------------end
    //-----------------------------------------start
    function edit() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $('#fm').form('load', row);
            document.getElementById("lb_harga").innerHTML = frp(row.harga);
            document.getElementById("head").innerHTML = '<h5 class="modal-title"><i class="fa fa-edit mr-2"></i>Edit Data</h5>';
            $('#edit').modal('show');
        } else {
            msg('Error', 'Klick Sekali Lagi');
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function lb_harga(val) {
        var res = frp(val);
        document.getElementById("lb_harga").innerHTML = res;
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function show_res(val, row) {
        for (var name in row) {
            var status = (row.status == 'true') ? 'ENABLE' : 'DISABLE';

            var t = `
            <div class="card col table-responsive my-1">
                <div class="row mt-1">
                    <div class="col-md-3">
                    Nama Keahlian / Spesialisasi
                    </div>
                    <div class="col-md-9">
                    <strong class="sec-a"> ~ ` + row.nama + `</strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    Alias Indo
                    </div>
                    <div class="col-md-9">
                    <strong class="pri-a"> ~ ` + row.alias_ind + `</strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    Alias Eng
                    </div>
                    <div class="col-md-9">
                    <strong class="pri-a"> ~ ` + row.alias_eng + `</strong>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="row">
                            <div class="col-md-6">
                            Kode EC
                            </div>
                            <div class="col-md-6">
                            <strong>: ` + row.kode + `</strong>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="row">
                            <div class="col-md-6">
                            Biaya 
                            </div>
                            <div class="col-md-6">
                            <strong>: Rp. ` + frp(row.harga) + `</strong>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="row">
                            <div class="col-md-6">
                            Status 
                            </div>
                            <div class="col-md-6">
                            <strong>: ` + status + `</strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            `;
            if (row["pur_res"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function destroyuser() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Menghapus data ini ?<br>Nama  Keahlian : ' + row.nama, function(r) {
                if (r) {
                    $.post("<?= XROOT ?>master/del_keahlian", {
                        id: row.id
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload');
                            msg('Success !', 'Berhasil Di Hapus');
                        } else {
                            msg('Error', result.errorMsg);
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function save() {
        var nama = document.getElementById("nama").value;
        if (nama == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'Nama Keahlian Belum Di isi.'
            });
            $('#nama').focus();
            exit;
        }
        var alias_ind = document.getElementById("alias_ind").value;
        if (alias_ind == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'alias_ind penelitian Belum Di isi.'
            });
            $('#alias_ind').focus();
            exit;
        }
        var alias_eng = document.getElementById("alias_eng").value;
        if (alias_eng == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'alias_eng penelitian Belum Di isi.'
            });
            $('#alias_eng').focus();
            exit;
        }
        var kode = document.getElementById("kode").value;
        if (kode == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'kode Belum Di isi.'
            });
            $('#kode').focus();
            exit;
        }
        var harga = document.getElementById("harga").value;
        if (harga == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'Biaya Belum Di isi.'
            });
            $('#harga').focus();
            exit;
        }
        $('#fm').form('submit', {
            url: '<?= XROOT ?>master/save_keahlian',
            onSubmit: function() {
                return $(this).form('validate');
            },
            success: function(result) {
                var result = eval('(' + result + ')');
                if (result.success) {
                    $('#edit').modal('hide');
                    $('#dguser').datagrid('reload');
                    msg('Success !', 'Berhasil di Save');
                } else {
                    msg('Error', result.errorMsg);
                }
            }
        });
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function frp(angka, prefix) {
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split = number_string.split(','),
            sisa = split[0].length % 3,
            rupiah = split[0].substr(0, sisa),
            ribuan = split[0].substr(sisa).match(/\d{3}/gi);

        // tambahkan titik jika yang di input sudah menjadi angka ribuan
        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }

        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'IDR. ' + rupiah : '');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    $(function() {
        $('#dguser').datagrid({
            singleSelect: true,
            onRowContextMenu: function(e, index, row) {
                $(this).datagrid('selectRow', index);
                e.preventDefault();
                $('#mm').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
            },
            onDblClickRow: function() {
                edit();
            }
        })

    })
    //-----------------------------------------end
    $('#harga').on('keypress', function(event) {
        return (((event.which > 47) && (event.which < 58)) || (event.which == 13));
    });
</script>