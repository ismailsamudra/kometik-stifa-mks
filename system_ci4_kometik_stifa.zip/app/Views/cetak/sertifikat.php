<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= 'Cetak_' . $id ?></title>
    <link rel="icon" type="image/x-icon" href="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" />
    <link rel="stylesheet" href="<?= XROOT ?>script/fontawesome-5.0.9/css/fontawesome-all.min.css">
    <link rel="stylesheet" type="text/css" href="<?= XROOT ?>script/easyui/bootstrap_4.3.1.min.css">
    <style type="text/css">
        /*body{
		font-family: sans-serif;
	}*/
        table {
            margin: 20px auto;
            border-collapse: collapse;
        }

        .b1 {
            border: 1px solid #000;
        }

        #tbl_1 th td {
            border: 3px solid #3c3c3c;
            padding: 10px auto;
        }

        #tbl_2 th {
            border: 0px solid #3c3c3c;
            padding: 20px auto;
        }

        #tbl_2 td {
            border: 0px solid #3c3c3c;
            padding: 10px auto;
            border-top: 2px black solid;
            border-bottom: 2px black solid;
        }

        a {
            background: blue;
            color: red;
            padding: 8px 10px;
            text-decoration: none;
            border-radius: 2px;
        }

        button {
            background: red;
            border-color: red;
            color: red;
            padding: 8px 10px;
            text-decoration: none;
            border-radius: 2px;
            margin-top: 2px;
        }

        hr {
            border: 1px solid #3c3c3c;
            margin-left: auto;
            margin-right: auto;
            border-style: inset;
            border-width: 1px;
        }
    </style>
</head>

<body>
    <div class="mx-4">
        <div class="container mx-5">
            <center>
                <img src="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" width="140">
            </center>
            <font size="3" face='Arial'>
                <br>
                <center>
                    <h5><strong>KOMISI ETIK PENELITIAN KESEHATAN</strong></h5>
                    <h5><strong>SEKOLAH TINGGI ILMU FARMASI MAKASSAR</strong></h5>
                    THE HEALTH RESEARCH ETHICS COMMITTEE <br>
                    SEKOLAH TINGGI ILMU FARMASI MAKASSAR <br>
                    <br>
                    <h5><strong>SURAT KETERANGAN</strong></h5>
                    ETHICAL APPROVAL <br>
                    Nomor : <?= $o->no_ec ?>
                </center>
                <br>
                Komisi Etik Penelitian Kesehatan Sekolah Tinggi Ilmu Farmasi Makassar, menyatakan dengan ini bahwa penelitian dengan judul : <br>
                <i>The Health Research Ethical Committee of Sekolah Tinggi Ilmu Farmasi Makassar, states hereby that the following proposal :</i> <br>
                <br>
                <div class="col">
                    <strong>"<?= $o->judul ?>"</strong>
                </div>
                <br>
                <div class="row">
                    <div class="col-4">
                        &nbsp;&nbsp;Nomor Protokol <br>
                        &nbsp;&nbsp;<i>Protocol number</i>
                    </div>
                    <div class="col-8">
                        : <?= $o->no_protokol ?>
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-4">
                        &nbsp;&nbsp;Lokasi Penelitian <br>
                        &nbsp;&nbsp;<i>Location</i>
                    </div>
                    <div class="col-8">
                        : <?= inc('lokasi') ?>
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-4">
                        &nbsp;&nbsp;Waktu Penelitian <br>
                        &nbsp;&nbsp;<i>Time schedule</i>
                    </div>
                    <div class="col-8">
                        <?php
                        $tgl_m = date("d", strtotime($o->tgl_mulai)) . ' ' . bn(date("m", strtotime($o->tgl_mulai))) . ' ' . date("Y", strtotime($o->tgl_mulai));
                        $tgl_s = date("d", strtotime($o->tgl_akhir)) . ' ' . bn(date("m", strtotime($o->tgl_akhir))) . ' ' . date("Y", strtotime($o->tgl_akhir));
                        $tgl_m1 = date("d", strtotime($o->tgl_mulai)) . ' ' . date("F", strtotime($o->tgl_mulai)) . ' ' . date("Y", strtotime($o->tgl_mulai));
                        $tgl_s1 = date("d", strtotime($o->tgl_akhir)) . ' ' . date("F", strtotime($o->tgl_akhir)) . ' ' . date("Y", strtotime($o->tgl_akhir));
                        ?>
                        : <?= $tgl_m . ' s/d ' . $tgl_s ?><br>
                        &nbsp;&nbsp;<i><?= $tgl_m1 . ' to ' . $tgl_s1 ?></i>
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-4">
                        &nbsp;&nbsp;Responden/Subyek Penelitian <br>
                        &nbsp;&nbsp;<i>Respondent/Research Subject</i>
                    </div>
                    <div class="col-8">
                        <?php $p = db('m_penelitian')->getWhere(['id' => $o->id_penelitian], 1)->getRow(); ?>
                        : <?= $p->alias_ind ?> <br>
                        &nbsp;&nbsp;<i><?= $p->alias_eng ?></i>
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-4">
                        &nbsp;&nbsp;Peneliti Utama<br>
                        &nbsp;&nbsp;<i>Principal Investigator</i>
                    </div>
                    <div class="col-8">
                        <?php $k = db('m_keahlian')->getWhere(['id' => $o->id_keahlian], 1)->getRow(); ?>
                        <?php $u = db('users')->getWhere(['id' => $o->id_user], 1)->getRow(); ?>
                        : <strong><?= $u->nama ?></strong><br>
                        &nbsp;&nbsp;<?= $k->alias_ind . ' ' . $o->asal ?> <br>
                        &nbsp;&nbsp;NIM : <?= $o->nim ?> <br>
                        &nbsp;&nbsp;<i><?= $k->alias_eng . ' ' . $o->asal ?></i><br>
                        &nbsp;&nbsp;<i>Student ID Number : <?= $o->nim ?></i>
                    </div>
                </div>
                <br>
                <?php
                $td = date("d", strtotime($o->tgl_a));
                $tm = date("m", strtotime($o->tgl_a));
                $ty = date("Y", strtotime($o->tgl_a));
                $td2 = date("d", strtotime($o->tgl_b));
                $tm2 = date("m", strtotime($o->tgl_b));
                $ty2 = date("Y", strtotime($o->tgl_b));
                ?>
                <strong>Telah melalui prosedur kaji etik dan dinyatakan layak untuk dilaksanakan</strong><br>
                <i>Has proceeded the ethical assessment procedure and been approved for the implementation</i>
                <br>
                <br>
                Demikianlah surat keterangan lolos kaji etik ini di buat untuk di ketahui dan di maklumi oleh yang berkepentingan dan berlaku pada tanggal <?= $td . ' ' . bn($tm) . ' ' . $ty ?> sampai dengan <?= $td2 . ' ' . bn($tm2) . ' ' . $ty2 ?> <br>
                <i>This ethical approval is issue to be used appropriately and understood by all stakeholders and valid from the <br><?= $td . ' ' . date("F", strtotime($tm)) . ' ' . $ty ?> to <?= $td2 . ' ' . date("F", strtotime($tm2)) . ' ' . $ty2 ?> </i>
                <br>
                <br>
                <div class="container">
                    <div class="row">
                        <div class="col-6">
                            <div id="qrcode"></div>
                        </div>
                        <div class="col-6">
                            <?php
                            echo 'Makassar, ' . $td . ' ' . bn($tm) . ' ' . $ty . ' <br>
                                Chairman, <br>
                                <br>
                                <br>
                                <br>
                                <strong>dr.Sujud Zainur Rosyid</strong> <br>
                                <small><strong>NIK : 1402012103</strong></small>';
                            ?>
                        </div>
                    </div>
                </div>
                <small>
                    Bersama ini menyatakan bahwa dikeluarkannya surat lolos etik dari Komis Etik Penelitian Kesehatan STIFA Makassar, maka saya <strong>berkewajiban :</strong> <br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1. &nbsp;&nbsp; Menyertakan Laporan hasil penelitian dan atau Publikasi dari hasil penelitian. <br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. &nbsp;&nbsp; Menyertakan Laporan Serious Adverse Event (SAE) ke komisi etik dalam 27 jam dan dilengkapi dalam 7 hari serta <br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; laporan Suspected Unexpected Seriuos Adverse Reaction (SUSAR) dalam 72 jam setelah peneliti utama menerima laporan. <br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3. &nbsp;&nbsp; Melaporkan penyimpangan dari protokol yang telah di setujui (Protocol deviation/violation). <br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4. &nbsp;&nbsp; Mematuhi semua peraturan yang berlaku.
                </small>
            </font>
        </div>
    </div>
</body>
<script>
    window.print();
</script>
<script src="<?= XROOT ?>script/qr-code-styling.js"></script>
<script src="<?= XROOT ?>script/show_qr2.js"></script>
<script>
    var data = "<?= XURL . 'doc/sertifikat/' . $id ?>";
    var logo = "<?= XROOT ?>img/instansi/<?= inc('logo-n') ?>";
    var color = "<?= color('qrcode-a') ?>";
    qrcode("qrcode", data, logo, color, '0');
</script>

</html>