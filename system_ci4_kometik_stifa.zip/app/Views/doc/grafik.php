<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= 'Cetak_' . $id ?></title>
    <link rel="icon" type="image/x-icon" href="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" />
    <link rel="stylesheet" href="<?= XROOT ?>script/fontawesome-5.0.9/css/fontawesome-all.min.css">
    <link rel="stylesheet" type="text/css" href="<?= XROOT ?>script/easyui/bootstrap_4.3.1.min.css">
    <style type="text/css">
        /*body{
		font-family: sans-serif;
	}*/
        table {
            margin: 20px auto;
            border-collapse: collapse;
        }

        .b1 {
            border: 1px solid #000;
        }

        #tbl_1 th td {
            border: 3px solid #3c3c3c;
            padding: 10px auto;
        }

        #tbl_2 th {
            border: 0px solid #3c3c3c;
            padding: 20px auto;
        }

        #tbl_2 td {
            border: 0px solid #3c3c3c;
            padding: 10px auto;
            border-top: 2px black solid;
            border-bottom: 2px black solid;
        }

        a {
            background: blue;
            color: red;
            padding: 8px 10px;
            text-decoration: none;
            border-radius: 2px;
        }

        button {
            background: red;
            border-color: red;
            color: red;
            padding: 8px 10px;
            text-decoration: none;
            border-radius: 2px;
            margin-top: 2px;
        }

        hr {
            border: 1px solid #3c3c3c;
            margin-left: auto;
            margin-right: auto;
            border-style: inset;
            border-width: 1px;
        }
    </style>
</head>

<body>
    <div class="mx-4">
        <div class="container mx-5">
            <br>

            <font size="3" face='Arial'>

                <br>
                <div class="row">
                    <div class="col-md-12 mb-2">
                        <div class="card bg-dark text-white">
                            <x class="col">
                                <i class="fa fa-signal mr-2"></i> Total
                            </x>
                        </div>
                    </div>
                    <div class="col-md-1">
                        <center>
                            <img src="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" width="80">
                        </center>
                    </div>
                    <div class="col-md-10 ml-2">
                        <br>
                        <strong>KOMISI ETIK PENELITIAN KESEHATAN</strong><br>
                        <strong>SEKOLAH TINGGI ILMU FARMASI MAKASSAR</strong>
                    </div>
                </div>
                <hr>
                <?php
                // $tp = num_rows(inc("level_regist"), en64('status_formulir="' . $val . '"'));
                $tp = num_rows(inc("level_regist"));
                $tr = num_rows(inc("level_reviewer"));
                $sem = num_rows("data_pengajuan");
                $sr = num_rows('data_pengajuan', en64('status_formulir="SERTIFIKAT"'));
                $jp = num_rows('data_pengajuan', en64('status!="SELESAI" AND status!="DI BATALKAN"'));
                $js = num_rows('data_pengajuan', en64('status="SELESAI"'));
                $jb = num_rows('data_pengajuan', en64('status="DI BATALKAN"'));
                $tfm = num_rows('data_pengajuan', en64('status_formulir="MENUNGGU"'));
                $tfr = num_rows('data_pengajuan', en64('status_formulir="DI REVIEW"'));
                $tfb = num_rows('data_pengajuan', en64('status_formulir="BERKAS PENELITIAN"'));
                ?>
                <div class="row my-1">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            Total Peserta
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= $tp ?> Orang
                        </div>
                    </div>
                </div>
                <div class="row my-1">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            Total Reviewer
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= $tr ?> Orang
                        </div>
                    </div>
                </div>
                <div class="row my-1">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            Total Sertifikat
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <?= $sr ?>
                        </div>
                    </div>
                </div>
                <div class="row my-1">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            Total Pengajuan
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">

                            <div class="row">
                                <div class="col-md-4">
                                    Semua
                                </div>
                                <div class="col-md-8">
                                    : <?= $sem ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    On Proses
                                </div>
                                <div class="col-md-8">
                                    : <?= $jp ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    Selesai
                                </div>
                                <div class="col-md-8">
                                    : <?= $js ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    Di Batalkan
                                </div>
                                <div class="col-md-8">
                                    : <?= $jb ?>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="row my-1">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            Total Formulir
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">

                            <div class="row">
                                <div class="col-md-4">
                                    Menunggu
                                </div>
                                <div class="col-md-8">
                                    : <?= $tfm ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    Di Review
                                </div>
                                <div class="col-md-8">
                                    : <?= $tfr ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    Berkas Penelitian
                                </div>
                                <div class="col-md-8">
                                    : <?= $tfb ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    Selesai
                                </div>
                                <div class="col-md-8">
                                    : <?= $sr ?>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <hr>
            </font>
        </div>
    </div>
</body>
<script src="<?= XROOT ?>script/qr-code-styling.js"></script>
<script src="<?= XROOT ?>script/show_qr2.js"></script>
<script>
    var data = "<?= XURL . 'doc/sertifikat/' . $id ?>";
    var logo = "<?= XROOT ?>img/instansi/<?= inc('logo-n') ?>";
    var color = "<?= color('qrcode-a') ?>";
    qrcode("qrcode", data, logo, color, '0');
</script>

</html>