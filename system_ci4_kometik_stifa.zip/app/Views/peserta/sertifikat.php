<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <h5>
                <a href="" style="color: <?= color('primary-b') ?>;">
                    <small>
                        <strong>
                            <i class="fa fa-ribbon mr-2"></i> <?= strtoupper('data Sertifikat') ?>
                        </strong>
                    </small>
                </a>
                <a href="javascript:void(0);" onclick="$('#dguser').datagrid('reload');" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
            </h5>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<input type="hidden" id="idx">
<div class="row m-2">
    <div class="col-md-9 mb-2 mt-2 table-responsive">
        <div class="row">

            <div class="col-12" id="fo1">
                <center>
                    <table id="dguser" toolbar="" class="easyui-datagrid" singleSelect="true" style="width: 100%;height:500px;" fitColumns="true" rowNumbers="true" pagination="true" url="<?= XROOT ?>peserta/get_sertifikat" pageSize="10" pageList="[10,25,50,75,100,125,150,200]">
                        <thead>
                            <tr>
                                <th field="pur_res" width="100%" formatter="show_res"></th>
                            </tr>
                        </thead>
                    </table>
                </center>
            </div>

        </div>

    </div>
    <div class="col-md-3 mb-2 mt-2 table-responsive">
        <div class="container">
            <div class="">
                <strong>
                    NB :
                </strong>
                <hr>
                DATA SERTIFIKAT
                <hr>
            </div>
            <br>
            <br>
            <br>
        </div>
        <center>
            <i class="fa fa-ribbon fa-5x"></i><br>
            <strong>
                <?= strtoupper('data Sertifikat') ?>
            </strong><br>
        </center>
    </div>
</div>
<!-- BODY END -->
<!-- Start Modal 1 -->
<div class="modal fade" id="setuju" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <div id="head2"></div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body rol-300">

                <form id="fm3" method="post" enctype="multipart/form-data">
                    <iframe id="frame" src="" width="100%" scrolling="yes" height="500px" frameborder="0"></iframe>

                </form>
            </div>
            <div class="modal-footer">

            </div>

        </div>
    </div>
</div>
<!-- End Modal 1-->
<?php $xx = db('m_penelitian')->getWhere(['status' => 'true'])->getResult(); ?>
<?php $oo = db('m_keahlian')->getWhere(['status' => 'true'])->getResult(); ?>
<?php foreach ($xx as $x) : ?>
    <input type="hidden" id="nama_<?= $x->id ?>" value="<?= $x->nama ?>">
    <input type="hidden" id="tb_<?= $x->id ?>" value="<?= $x->tb ?>">
    <input type="hidden" id="peserta_<?= $x->id ?>" value="<?= $x->pdf_peserta ?>">
    <input type="hidden" id="reviewer_<?= $x->id ?>" value="<?= $x->pdf_reviewer ?>">
<?php endforeach ?>
<?php foreach ($oo as $o) : ?>
    <input type="hidden" id="nama_<?= $o->id ?>" value="<?= $o->nama ?>">
    <input type="hidden" id="biaya_<?= $o->id ?>" value="<?= $o->harga ?>">
<?php endforeach ?>
<!-- TOOLBAR END -->
<script type="text/javascript">
    //-----------------------------------------start
    function doc(id) {
        window.open("<?= XURL ?>doc/sertifikat/" + id, "mywindow", "toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=0,width=auto,height=auto,left =304,top = 150.5");
        testwindow.moveTo(0, 0);
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function pdf(id) {
        $('#fm1').form('clear');
        document.getElementById("id").value = id;
        $('#pdf').modal('show');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function lihat(id) {
        document.getElementById("head2").innerHTML = '<h5 class="modal-title"><i class="far fa-user mr-2"></i>Reviewer</h5>';
        document.getElementById('frame').src = '<?= XURL ?>admin/reviewer2/' + id;
        $('#setuju').modal('show');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function show_res(val, row) {
        for (var name in row) {
            var nmp = document.getElementById("nama_" + row.id_penelitian).value;
            var tb = document.getElementById("tb_" + row.id_penelitian).value;
            var peserta = document.getElementById("peserta_" + row.id_penelitian).value;
            var bt_peserta = (peserta == '' || row.status_formulir != 'RILIS') ? '' : `<a href="<?= XROOT ?>file/pdf/` + peserta + `" class="float-right" target="_blank">Formulir Peserta<i class="fa fa-file-pdf text-danger ml-2"></i></a>`;
            var f_peserta = (row.formulir == '') ? 'BELUM ADA' : '<a href="<?= XURL ?>file/pdf/' + row.formulir + '" target="_blank">Lihat<i class="fa fa-file-pdf text-danger ml-2"></i></a>';
            var nmk = document.getElementById("nama_" + row.id_keahlian).value;
            var bik = document.getElementById("biaya_" + row.id_keahlian).value;
            var sins = (row.instansi == 'LUAR') ? 'LUAR STIFA' : 'DALAM STIFA';
            var text1 = `<div class="row my-1">
                    <div class="col-md-3">
                    HASIL PENELITIAN
                    </div>
                    <div class="col-md-9">
                    <strong> ~ <a href="<?= XURL ?>file/pdf/` + row.hasil + `" target="_blank">Lihat<i class="fa fa-file-pdf text-danger ml-2"></i></a> </strong>
                    </div>
                </div>`;
            var hasil = (row.hasil == '') ? '' : text1;
            var text2 = `<div class="row mt-1">
                    <div class="col-md-3">
                    REVIEWER TOTAL
                    </div>
                    <div class="col-md-9">
                    <strong>: ` + row.rev + `  Orang <a href="javascript:void(0);" class="" onclick="lihat('` + row.id + `');">Lihat<i class="far fa-user ml-2"></i></a></strong>
                    </div>
                </div>`;
            var rev = (row.rev == 0) ? '' : text2;
            var text3 = `<div class="row my-1">
                    <div class="col-md-3">
                    Alasan Reupload
                    </div>
                    <div class="col-md-9">
                    <strong>: ` + row.ket3 + `</strong>
                    </div>
                </div>`;
            var ket3 = (row.ket3 == '') ? '' : text3;
            var text4 = `<div class="row my-1">
                    <div class="col-md-4">
                    Alasan Reupload Hasil Penelitian
                    </div>
                    <div class="col-md-8">
                    <strong> ~ ` + row.ket4 + `</strong>
                    </div>
                </div>`;
            var ket4 = (row.ket4 == '') ? '' : text4;
            if (row.formulir != '') {
                var form = '';
            } else {
                var form = ` <a href="javascript:void(0);" class="float-right" onclick="pdf('` + row.id + `','` + row.hp + `')">Upload Pdf formulir<i class="fa fa-upload ml-2"></i></a>`;
            }
            var t = `
            <div class="card col table-responsive my-1">
                <div class="row my-1">
                    <div class="col-md-12">
                    <strong> <a href="javascript:void(0);" onclick="doc('` + row.id + `')" class="float-right">Cetak Sertifikat<i class="fa fa-print text-primary ml-2"></i></a></strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    ID
                    </div>
                    <div class="col-md-9">
                    <strong class="pri-a"> : ` + row.id + `</strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    NO ETIK APPROVAL
                    </div>
                    <div class="col-md-9">
                    <strong class="sec-a"> : ` + row.no_ec + `</strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    NO PROTOKOL
                    </div>
                    <div class="col-md-9">
                    <strong class="sec-a"> : ` + row.no_protokol + `</strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    JENIS PENELITIAN
                    </div>
                    <div class="col-md-9">
                    <strong>: ` + nmp + `</strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    KEAHLIAN / SPESIALISASI 
                    </div>
                    <div class="col-md-9">
                    <strong>: ` + nmk + `</strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    NIM
                    </div>
                    <div class="col-md-9">
                    <strong>: ` + row.nim + `</strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    STATUS INSTANSI 
                    </div>
                    <div class="col-md-9">
                    <strong>: ` + sins + `</strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    NAMA INSTANSI
                    </div>
                    <div class="col-md-9">
                    <strong>: ` + row.asal + `</strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    WAKTU PENELITIAN
                    </div>
                    <div class="col-md-9">
                    <strong>: ` + row.tgl_mulai + ` s/d ` + row.tgl_akhir + `</strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    TANGGAL PENGAJUAN
                    </div>
                    <div class="col-md-9">
                    <strong>: ` + row.at_create + `</strong>
                    </div>
                </div>
                ` + rev + `
                <div class="row my-1">
                <div class="col-md-3">
                BERKAS AWAL
                </div>
                <div class="col-md-9">
                <strong> ~ <a href="<?= XURL ?>file/pdf/` + row.berkas + `" target="_blank">Lihat<i class="fa fa-file-pdf text-danger ml-2"></i></a> </strong>
                </div>
                </div>
                <div class="row my-1">
                <div class="col-md-3">
                FORMULIR SAYA
                </div>
                <div class="col-md-9">
                <strong> ~ ` + f_peserta + form + ` </strong>
                </div>
                </div>
                ` + hasil + `
                <div class="row my-1">
                    <div class="col-md-3">
                    Judul  Penelitian
                    </div>
                    <div class="col-md-9">
                    <textarea cols="30" rows="2" class="form-control" readonly>` + row.judul + `</textarea>
                    </div>
                </div>
                
                ` + ket3 + `
                ` + ket4 + `
            </div>
            `;
            if (row["pur_res"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function frp(angka, prefix) {
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split = number_string.split(','),
            sisa = split[0].length % 3,
            rupiah = split[0].substr(0, sisa),
            ribuan = split[0].substr(sisa).match(/\d{3}/gi);

        // tambahkan titik jika yang di input sudah menjadi angka ribuan
        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }

        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    }
    //-----------------------------------------end
</script>