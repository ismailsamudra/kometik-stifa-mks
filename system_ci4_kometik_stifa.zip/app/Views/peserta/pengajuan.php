<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <a href="javascript:void(0);" onclick="add()" class="btn-sm bt-1 float-left" title="ADD"><i class="fa fa-plus"></i></a>
            <h5>
                <a href="" style="color: <?= color('primary-b') ?>;">
                    <small>
                        <strong>
                            <i class="fa fa-id-badge mr-2"></i> <?= strtoupper('data pengajuan') ?>
                        </strong>
                    </small>
                </a>
                <a href="javascript:void(0);" onclick="$('#dguser').datagrid('reload');" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
            </h5>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<input type="hidden" id="idx">
<div class="row m-2">
    <div class="col-md-9 mb-2 mt-2 table-responsive">
        <div class="row">

            <div class="col-12" id="fo1">
                <center>
                    <table id="dguser" toolbar="" class="easyui-datagrid" singleSelect="true" style="width: 100%;height:500px;" fitColumns="true" rowNumbers="true" pagination="true" url="<?= XROOT ?>peserta/get_pengajuan" pageSize="10" pageList="[10,25,50,75,100,125,150,200]">
                        <thead>
                            <tr>
                                <th field="pur_res" width="100%" formatter="show_res"></th>
                            </tr>
                        </thead>
                    </table>
                </center>
            </div>

        </div>

    </div>
    <div class="col-md-3 mb-2 mt-2 table-responsive">
        <div class="container">
            <div class="">
                <strong>
                    M-BOOK :
                </strong>
                <hr>
                Tombol Pengajuan Berada pada samping kiri atas ber logo plus.
                <hr>
                Data tidak dapat di edit atau di batalkan jika ber status selain menunggu, dengan artian sedang di proses oleh admin.
                <hr>
                Jika pengajuan di batalkan oleh admin harap melakukan pengajuan ulang dan ikuti iyarat sesuai alasan pembatalan.
                <hr>
                Untuk Edit atau Batal Klick Kanan jika desktop dan sentuh tahan jika HP pada baris data.
                <hr>
            </div>
            <br>
            <br>
            <br>
        </div>
        <center>
            <i class="fa fa-id-badge fa-5x"></i><br>
            <strong>
                <?= strtoupper('data pengajuan') ?>
            </strong><br>
        </center>
    </div>
</div>
<!-- BODY END -->

<!-- KLICK KANAN START -->
<div id="mm" class="easyui-menu">
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="edit();"><i class="fa fa-edit mr-2"></i>Edit</a>
    <a href="javascript:void(0)" class="btn-sm form-control" plain="true" onClick="destroyuser();"><i class="fa fa-trash mr-2 text-danger"></i> Hapus</a>
</div>
<!-- KLICK KANAN END -->
<?php $xx = db('m_penelitian')->getWhere(['status' => 'true'])->getResult(); ?>
<?php $oo = db('m_keahlian')->getWhere(['status' => 'true'])->getResult(); ?>
<?php foreach ($xx as $x) : ?>
    <input type="hidden" id="nama_<?= $x->id ?>" value="<?= $x->nama ?>">
<?php endforeach ?>
<?php foreach ($oo as $o) : ?>
    <input type="hidden" id="nama_<?= $o->id ?>" value="<?= $o->nama ?>">
    <input type="hidden" id="biaya_<?= $o->id ?>" value="<?= $o->harga ?>">
<?php endforeach ?>
<!-- Start Modal 1 -->
<div class="modal fade" id="edit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div id="head"></div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form id="fm" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="id" id="id">
                    <label for=""><small>Pilih Jenis Penelitian [ Wajib ]</small></label>
                    <select name="id_penelitian" id="id_penelitian" class="form-control">
                        <?php foreach ($xx as $x) : ?>
                            <option value="<?= $x->id ?>"><?= $x->nama ?></option>
                        <?php endforeach ?>
                    </select>
                    <label for=""><small>Pilih Keahlian / Spesialisasi [ Wajib ]</small></label>
                    <select name="id_keahlian" id="id_keahlian" class="form-control">
                        <?php foreach ($oo as $o) : ?>
                            <option value="<?= $o->id ?>"><?= $o->nama   . ' ~ ' . "Rp " . number_format($o->harga, 0, ',', '.'); ?> </option>
                        <?php endforeach ?>
                    </select>
                    <label for=""><small>Nim [ Wajib ]</small></label>
                    <input type="text" class="form-control" id="nim" name="nim">
                    <label for=""><small>Judul Penelitian [ Wajib ] <i>"Bahasa Inggris Jika Ada"</i></small></label>
                    <textarea name="judul" id="judul" cols="30" rows="2" class="form-control"></textarea>
                    <div class="row my-2">
                        <div class="col-md-4">
                            <small>Status Instansi</small>
                        </div>
                        <div class="col-md-4">
                            <input type="radio" id="instansi1" name="instansi" value="DALAM" onclick="insc();"> Dalam Stifa
                        </div>
                        <div class="col-md-4">
                            <input type="radio" id="instansi2" name="instansi" value="LUAR" onclick="insc();"> Luar Stifa
                        </div>
                    </div>
                    <div class="my-2" id="fluar">
                        <label for=""><small>Sebutkan Kepanjangan Instansi [ Wajib ]</small></label>
                        <input type="text" class="form-control" id="asal" name="asal">
                    </div>
                    <div class="row my-1">
                        <div class="col-md-12">
                            <label for=""><small>Waktu Penelitian [ Wajib ]</small></label>
                        </div>
                        <div class="col-md-5">
                            <input type="date" class="form-control" id="tgl_mulai" name="tgl_mulai">
                        </div>
                        <div class="col-md-2">
                            <center>
                                s/d
                            </center>
                        </div>
                        <div class="col-md-5">
                            <input type="date" class="form-control" id="tgl_akhir" name="tgl_akhir">
                        </div>
                    </div>

                    <small id=" lb_id">UPLOAD BERKAS PDF [ Wajib ]</small>
                    <input type="file" name="file" id="file" accept="application/pdf" class="form-control">
                    <div class="container">
                        <div class="text-danger">
                            <br>
                            <strong>NB : </strong><br>
                            <strong><small>Untuk upload berkas pelajari lebih lanjut di Manual Book</small> <a href="<?= XROOT ?>users/m_book" target="_blank">Lihat</a></strong>
                        </div>
                    </div>
                </form>

            </div>
            <div class="modal-footer">
                <a href="javascript:void(0);" onclick="save();" class="btn btn-outline-dark btn-sm"><i class="fa fa-paper-plane mr-2"></i>Ajukan</a>
            </div>

        </div>
    </div>
</div>
<!-- End Modal 1-->
<!-- TOOLBAR END -->
<script type="text/javascript">
    $('#fluar').hide();
    //-----------------------------------------start
    function add() {
        $('#fm').form('clear');
        $('#lb_id').html('UPLOAD BERKAS PDF [ Wajib ]');
        document.getElementById("instansi1").checked = true;
        document.getElementById("head").innerHTML = '<h5 class="modal-title"><i class="fa fa-plus mr-2"></i>Buat Pengajuan</h5>';
        document.getElementById("id").value = 'insert';
        $('#edit').modal('show');

    }
    //-----------------------------------------end
    //-----------------------------------------start
    function insc() {
        if (document.getElementById("instansi1").checked == true) {
            $('#fluar').hide();
        } else {
            $('#fluar').show();
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function edit() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            if (row.status == 'MENUNGGU') {
                $('#fm').form('load', row);
                $('#lb_id').html('GANTI BERKAS PDF [ Optional ]');
                document.getElementById("head").innerHTML = '<h5 class="modal-title"><i class="fa fa-edit mr-2"></i>Edit Data</h5>';
                $('#edit').modal('show');
            } else {
                $.messager.show({ // show error message
                    title: 'Error',
                    msg: 'Maaf ! Status ' + row.status + ' tdk dapat di edit .'
                });
            }
        } else {
            msg('Error', 'Klick Sekali Lagi');
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function show_res(val, row) {
        for (var name in row) {
            var nmp = document.getElementById("nama_" + row.id_penelitian).value;
            var nmk = document.getElementById("nama_" + row.id_keahlian).value;
            var bik = document.getElementById("biaya_" + row.id_keahlian).value;
            var sins = (row.instansi == 'LUAR') ? 'LUAR STIFA' : 'DALAM STIFA';
            var text = `<div class="row mt-1">
                    <div class="col-md-3">
                    Alasan Di Batalkan
                    </div>
                    <div class="col-md-9">
                    <strong>: ` + row.ket + `</strong>
                    </div>
                </div>`;
            var ket = (row.ket == '') ? '' : text;
            var text2 = `<div class="row mt-1">
                    <div class="col-md-3">
                    Alasan Reupload
                    </div>
                    <div class="col-md-9">
                    <strong>: ` + row.ket2 + `</strong>
                    </div>
                </div>`;
            var ket2 = (row.ket2 == '') ? '' : text2;
            var text_pembayaran = `<div class="row mt-1">
                        <div class="col-md-3">
                        Ket.
                        </div>
                        <div class="col-md-9">
                        <strong>: Silahkan Menuju Menu Pembayaran untuk Info Pembayaran <br>~  Sesuai ID data ini. <a href="<?= XURL ?>peserta/pembayaran" target="_blank">Atau Klick disini</a></strong>
                        </div>
                    </div>`;
            var ket_bayar = (row.status != 'PEMBAYARAN') ? '' : text_pembayaran;
            var status = (row.status == 'SELESAI') ? 'SELESAI <a href="<?= XURL ?>peserta/formulir" target="_blank">Klick disini untuk menuju tabel formulir</a>' : row.status;
            var t = `
            <div class="card col table-responsive my-1">
                <div class="row mt-1">
                    <div class="col-md-3">
                    ID
                    </div>
                    <div class="col-md-9">
                    <strong class="sec-a"> : ` + row.id + `</strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    JENIS PENELITIAN
                    </div>
                    <div class="col-md-9">
                    <strong>: ` + nmp + `</strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    KEAHLIAN / SPESIALISASI 
                    </div>
                    <div class="col-md-9">
                    <strong>: ` + nmk + `</strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    NIM
                    </div>
                    <div class="col-md-9">
                    <strong>: ` + row.nim + `</strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    STATUS INSTANSI 
                    </div>
                    <div class="col-md-9">
                    <strong>: ` + sins + `</strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    NAMA INSTANSI
                    </div>
                    <div class="col-md-9">
                    <strong>: ` + row.asal + `</strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    WAKTU PENELITIAN
                    </div>
                    <div class="col-md-9">
                    <strong>: ` + row.tgl_mulai + ` s/d ` + row.tgl_akhir + `</strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    BIAYA
                    </div>
                    <div class="col-md-9">
                    <strong>: Rp. ` + frp(bik) + `</strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    BERKAS 
                    </div>
                    <div class="col-md-9">
                    <strong>: <a href="<?= XURL ?>file/pdf/` + row.berkas + `" target="_blank">Lihat <i class="fa fa-arrow-right"></i></a></strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    TANGGAL PENGAJUAN 
                    </div>
                    <div class="col-md-9">
                    <strong>: ` + row.at_create + `</strong>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-md-3">
                    Status Pengajuan
                    </div>
                    <div class="col-md-9">
                    <strong>: ` + status + `</strong>
                    </div>
                </div>
               ` + ket + `
               ` + ket2 + `
               ` + ket_bayar + `
               <div class="row my-1">
                    <div class="col-md-3">
                    Judul  Penelitian
                    </div>
                    <div class="col-md-9">
                    <textarea cols="30" rows="2" class="form-control" readonly>` + row.judul + `</textarea>
                    </div>
                </div>
            </div>
            `;
            if (row["pur_res"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function frp(angka, prefix) {
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split = number_string.split(','),
            sisa = split[0].length % 3,
            rupiah = split[0].substr(0, sisa),
            ribuan = split[0].substr(sisa).match(/\d{3}/gi);

        // tambahkan titik jika yang di input sudah menjadi angka ribuan
        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }

        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function destroyuser() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            if (row.status == 'MENUNGGU') {
                $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Menghapus data ini ?<br>ID: ' + row.id, function(r) {
                    if (r) {
                        $.post("<?= XROOT ?>peserta/del_pengajuan", {
                            id: row.id
                        }, function(result) {
                            if (result.success) {
                                $('#dguser').datagrid('reload');
                                msg('Success !', 'Berhasil Di Hapus');
                            } else {
                                msg('Error', result.errorMsg);
                            }
                        }, 'json');
                    }
                });
            } else {
                $.messager.show({ // show error message
                    title: 'Error',
                    msg: 'Maaf ! Status ' + row.status + ' tdk dapat di Hapus.'
                });
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function save() {
        var id_penelitian = document.getElementById("id_penelitian").value;
        if (id_penelitian == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'Jenis Penelitian Belum Di Pilih.'
            });
            $('#id_penelitian').focus();
            exit;
        }
        var id_keahlian = document.getElementById("id_keahlian").value;
        if (id_keahlian == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'Spesialisasi Belum Di Pilih.'
            });
            $('#id_keahlian').focus();
            exit;
        }
        var nim = document.getElementById("nim").value;
        if (nim == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'Nim Belum Di isi.'
            });
            $('#nim').focus();
            exit;
        }
        var judul = document.getElementById("judul").value;
        if (judul == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'judul Belum Di isi.'
            });
            $('#judul').focus();
            exit;
        }
        if (document.getElementById("instansi2").checked == true) {
            var asal = document.getElementById("asal").value;
            if (asal == '') {
                $.messager.show({ // show error message
                    title: 'Error',
                    msg: 'Instansi Belum Di isi.'
                });
                $('#asal').focus();
                exit;
            }
        }
        var tgl_mulai = document.getElementById("tgl_mulai").value;
        if (tgl_mulai == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'tgl_mulai Belum Di isi.'
            });
            $('#tgl_mulai').focus();
            exit;
        }
        var tgl_akhir = document.getElementById("tgl_akhir").value;
        if (tgl_akhir == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'tgl_akhir Belum Di isi.'
            });
            $('#tgl_akhir').focus();
            exit;
        }
        $('#fm').form('submit', {
            url: '<?= XROOT ?>peserta/save_pengajuan',
            onSubmit: function() {
                return $(this).form('validate');
            },
            success: function(result) {
                var result = eval('(' + result + ')');
                if (result.success) {
                    $('#edit').modal('hide');
                    $('#dguser').datagrid('reload');
                    msg('Success !', 'Berhasil di Kirim. <br> Harap menunggu konfirmasi admin lewat whatsapp atau app');
                } else {
                    msg('Error', result.errorMsg);
                }
            }
        });
    }
    //-----------------------------------------end
    //-----------------------------------------start
    $(function() {
        $('#dguser').datagrid({
            singleSelect: true,
            onRowContextMenu: function(e, index, row) {
                // if (row.status == 'MENUNGGU') {
                $(this).datagrid('selectRow', index);
                e.preventDefault();
                $('#mm').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
                // }
            }
        })

    })
    //-----------------------------------------end
    $('#no').on('keypress', function(event) {
        return (((event.which > 47) && (event.which < 58)) || (event.which == 13));
    });
</script>