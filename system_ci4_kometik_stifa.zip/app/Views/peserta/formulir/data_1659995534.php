<?php
$o = db($tb)->getWhere(['id' => $id], 1)->getRow();
$x = db('data_pengajuan')->getWhere(['id' => $id], 1)->getRow();
$n = db('m_penelitian')->getWhere(['tb' => $tb], 1)->getRow();
$a = db('m_keahlian')->getWhere(['id' => $x->id_keahlian], 1)->getRow();
?>
<style>
    .widget-save {
        position: fixed;
        bottom: 50px;
        right: 30px;
        font-size: 4px;
        -webkit-border-radius: 999px;
        -moz-border-radius: 999px;
        border-radius: 999px;
        width: 60px;
        height: 60px;
        text-align: center;
        z-index: 1999;

    }

    .widget-finis {
        position: fixed;
        bottom: 1px;
        right: 30px;
        font-size: 4px;
        -webkit-border-radius: 999px;
        -moz-border-radius: 999px;
        border-radius: 999px;
        width: 60px;
        height: 60px;
        text-align: center;
        z-index: 1999;

    }
</style>
<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <a href="javascript:void(0);" onclick="history.back()" class="btn-sm bt-1 float-left mr-2" title="Back"><i class="fa fa-arrow-left"></i></a>
            <h5>
                <a href="" style="color: <?= color('primary-b') ?>;">
                    <small>
                        <strong>
                            <i class="fa fa-copy mr-2"></i> <?= strtoupper('formulir peserta') ?>
                        </strong>
                    </small>
                </a>
                <a href="" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
            </h5>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<div class="container">
    <br>
    Formulir : <u><strong><?= $n->nama ?></strong></u> <br>
    No.Protokol : <strong><?= $o->no_protokol ?></strong>
    <br>
    <center><strong>A. INFORMASI UMUM</strong></center>
    <br>
    <!-- A 01 START -->
    <h5><strong>01.</strong></h5>
    <div class="row">
        <div class="col-md-12 mb-1">
            <small><strong>Nama Peneliti Utama </strong>[ tidak mencantumkan gelar akademik ]</small>
            <?php $nama = ($o->a1_1 == null) ? me('nama') : $o->a1_1; ?>
            <input type="text" class="form-control" placeholder="Input .." style="height: 24px;" id="a1_1" name="a1_1" value="<?= $nama ?>">
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 mb-1">
            <small><strong>Keahlian / Spesialisasi </strong></small>
            <?php $keahlian = ($o->a1_2 == null) ? $a->nama : $o->a1_2; ?>
            <input type="text" class="form-control" placeholder="Input .." style="height: 24px;" id="a1_2" name="a1_2" value="<?= $keahlian ?>">
        </div>
        <div class="col-md-6 mb-1">
            <small><strong>Jabatan / Kedudukan</strong></small>
            <input type="text" class="form-control" placeholder="Input .." style="height: 24px;" id="a1_3" name="a1_3" value="<?= $o->a1_3 ?>">
        </div>
    </div>
    <div class="row">
        <div class="col-md-4 mb-1">
            <small><strong>Telp Rumah.</strong></small>
            <input type="text" class="form-control" placeholder="Input .." style="height: 24px;" id="a1_4" name="a1_4" value="<?= $o->a1_4 ?>">
        </div>
        <div class="col-md-4 mb-1">
            <?php $hp = ($o->a1_5 == null) ? me('hp') : $o->a1_5; ?>
            <small><strong>Hp.</strong></small>
            <input type="text" class="form-control" placeholder="Input .." style="height: 24px;" id="a1_5" name="a1_5" value="<?= $hp ?>">
        </div>
        <div class="col-md-4 mb-1">
            <?php $email = ($o->a1_6 == null) ? me('email') : $o->a1_6; ?>
            <small><strong>Email.</strong></small>
            <input type="text" class="form-control" placeholder="Input .." style="height: 24px;" id="a1_6" name="a1_6" value="<?= $email ?>">
        </div>
    </div>
    <hr>
    <!-- A 01 END -->
    <!-- A 02 START -->
    <h5><strong>02.</strong></h5>
    <div class="row">
        <div class="col-md-12 mb-1">
            <small><strong>Asal Instansi & Prodi</strong></small>
            <input type="text" class="form-control" placeholder="Input .." style="height: 24px;" id="a2_1" name="a2_1" value="<?= $o->a2_1 ?>">
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 mb-1">
            <small><strong>Alamat Institusi</strong></small>
            <input type="text" class="form-control" placeholder="Input .." style="height: 24px;" id="a2_2" name="a2_2" value="<?= $o->a2_2 ?>">
        </div>
    </div>
    <div class="row">
        <div class="col-md-4 mb-1">
            <small><strong>Telp.</strong></small>
            <input type="text" class="form-control" placeholder="Input .." style="height: 24px;" id="a2_3" name="a2_3" value="<?= $o->a2_3 ?>">
        </div>
        <div class="col-md-4 mb-1">
            <small><strong>Fax.</strong></small>
            <input type="text" class="form-control" placeholder="Input .." style="height: 24px;" id="a2_4" name="a2_4" value="<?= $o->a2_4 ?>">
        </div>
        <div class="col-md-4 mb-1">
            <small><strong>Email.</strong></small>
            <input type="text" class="form-control" placeholder="Input .." style="height: 24px;" id="a2_5" name="a2_5" value="<?= $o->a2_5 ?>">
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 mb-1">
            <small><strong>Sponsor</strong> [ Individu/Swasta/Hibah Nasional/Hibah Internasional ]</small>
            <input type="text" class="form-control" placeholder="Input .." style="height: 24px;" id="a2_6" name="a2_6" value="<?= $o->a2_6 ?>">
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 mb-1">
            <small><strong>Pembimbing/Peneliti Lain</strong></small>
            <input type="text" class="form-control" placeholder="Input .." style="height: 24px;" id="a2_7" name="a2_7" value="<?= $o->a2_7 ?>">
        </div>
    </div>
    <hr>
    <!-- A 02 END -->
    <!-- A 03 START -->
    <h5><strong>03.</strong></h5>
    <div class="row">
        <div class="col-md-12 mb-1">
            <small><strong>Judul Penelitian</strong> [ Bahasa Inggris jika ada ]</small>
            <textarea cols="30" rows="2" id="a3_1" name="a3_1" class="form-control"><?= $o->a3_1 ?></textarea>
        </div>
    </div>
    <hr>
    <!-- A 03 END -->
    <!-- A 04 START -->
    <h5><strong>04.</strong></h5>
    <div class="row">
        <div class="col-md-12 mb-1">
            <script>
                var a41 = "<?= $o->a4_1 ?>";

                function load_a41() {
                    if (a41 == 'Tidak') {
                        document.getElementById("a4_1b").checked = true;
                    } else {
                        document.getElementById("a4_1a").checked = true;
                    }
                    c_a41();
                }

                function c_a41() {
                    if (document.getElementById("a4_1a").checked == true) {
                        $('#d_a4_1').show();
                    } else {
                        $('#d_a4_1').hide();
                    }
                }
            </script>
            <small><strong>Multisenter</strong></small><br>
            <input type="radio" id="a4_1a" onclick="c_a41()" name="a4_1" value="Ya"> Ya &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" id="a4_1b" onclick="c_a41()" name="a4_1" value="Tidak"> Tidak
        </div>
    </div>
    <div class="row" id="d_a4_1">
        <div class="col-md-6 mb-1">
            <small><strong>Senter Penelitian Utama</strong></small>
            <input type="text" class="form-control" placeholder="Input .." style="height: 24px;" id="a4_2" name="a4_2" value="<?= $o->a4_2 ?>">
        </div>
        <div class="col-md-6 mb-1">
            <small><strong>Senter Penelitian Satelit</strong></small>
            <input type="text" class="form-control" placeholder="Input .." style="height: 24px;" id="a4_3" name="a4_3" value="<?= $o->a4_3 ?>">
        </div>
    </div>
    <hr>
    <!-- A 04 END -->
    <!-- A 05 START -->
    <h5><strong>05.</strong></h5>
    <div class="row">
        <div class="col-md-12 mb-1">
            <script>
                // var a41 = "<?= $o->a5_1 ?>";

                // function load_a41() {
                //     if (a41 == 'Tidak') {
                //         document.getElementById("a4_1b").checked = true;
                //     } else {
                //         document.getElementById("a4_1a").checked = true;
                //     }
                // }

                // function c_a41() {
                //     if (document.getElementById("a4_1a").checked == true) {
                //         $('#d_a4_1').show();
                //     } else {
                //         $('#d_a4_1').hide();
                //     }
                // }
            </script>
            <small><strong>Penelitian</strong></small><br>
            <input type="radio" id="a5_1a" onclick="" name="a5_1" value="Bukan Kerja Sama"> Bukan Kerja Sama <br>
            <input type="radio" id="a5_1b" onclick="" name="a5_1" value="Kerja Sama Nasional"> Kerja Sama Nasional <br>
            <input type="radio" id="a5_1c" onclick="" name="a5_1" value="Internasional"> Internasional,Jumblah negara sebutkan: <br>
            <input type="radio" id="a5_1d" onclick="" name="a5_1" value="Melibatkan Ketua Peneliti Asing"> Melibatkan Ketua Peneliti Asing <br>
        </div>
    </div>
    <hr>
    <!-- A 05 END -->
</div>

<!-- BODY END -->

<!-- TOOLBAR END -->
<script type="text/javascript">
    //-----------------------------------------start
    window.onload = load;

    function load() {
        load_a41();
    }
    //-----------------------------------------end
</script>

<div class="widget-save">
    <a target="_blank" class="text-white" href="">
        <img src="<?= XROOT ?>img/dev/save_doc.png" style="margin: left 10px;" alt="" width="50" title="SAVE DOCUMENT" />

    </a>
</div>
<div class="widget-finis">
    <a target="_blank" class="text-white" href="">
        <img src="<?= XROOT ?>img/dev/finis_doc.png" style="margin: left 10px;" alt="" width="50" title="SELESAIKAN DOCUMENT" />

    </a>
</div>