<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <h5>
                <a href="" style="color: <?= color('primary-b') ?>;">
                    <small>
                        <strong>
                            <i class="fa fa-book mr-2"></i> <?= strtoupper(str_replace('/', ' ', XURI)) ?>
                        </strong>
                    </small>
                </a>
                <a href="javascript:void(0);" onclick="$('#dguser').datagrid('reload');" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
            </h5>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<input type="hidden" id="idx">
<div class="row m-2">
    <div class="col-md-9 mb-2 mt-2 table-responsive">
        <div class="row">

            <div class="col-12" id="fo1">
                <center>
                    <table id="dguser" toolbar="#toolbarCustomer" class="easyui-datagrid" singleSelect="true" style="width: 100%;height:500px;" fitColumns="true" rowNumbers="true" pagination="true" url="<?= XROOT ?>users/get_m_book" pageSize="10" pageList="[10,25,50,75,100,125,150,200]">
                        <thead>
                            <tr>
                                <th field="pur_res" width="100%" formatter="show_res"></th>
                            </tr>
                        </thead>
                    </table>
                </center>
            </div>
            <div class="col-12" id="fo2">
                <div class="card col bg-1 mb-2">
                    <x>
                        <div id="head"></div>
                        <a href="javascript:void(0);" onclick="hid()" class="float-right pri-b mx-1" title="Close"><i class="fa fa-times"></i></a>
                    </x>
                </div>
                <div id="content"></div>
            </div>

        </div>

    </div>
    <div class="col-md-3 mb-2 mt-2 table-responsive">
        <div class="container">
            <div class="">
                <strong>
                    NB :
                </strong>
                <hr>
                Doubel Klick pada baris data Untuk life preview
                <hr>
            </div>
            <br>
            <br>
            <br>
        </div>
        <center>
            <i class="fa fa-book fa-5x"></i><br>
            <strong>
                <?= strtoupper(str_replace('/', ' ', XURI)) ?>
            </strong><br>
        </center>
    </div>
</div>
<!-- BODY END -->
<!-- TOOLBAR START -->
<div id="toolbarCustomer">
    <div class="row">
        <div class="col-md-5">
            <!---------SEARCH BOX START--------->
            <input id="searchCustomer" class="easyui-searchbox" data-options="prompt:'Cari..',searcher:doSearchCustomer,
            inputEvents: $.extend({}, $.fn.searchbox.defaults.inputEvents, {
                keyup: function(e){
                    var t = $(e.data.target);
                    var opts = t.searchbox('options');
                    t.searchbox('setValue', $(this).val());
                    opts.searcher.call(t[0],t.searchbox('getValue'),t.searchbox('getName'));
                }
            })
        " style="width:100%;"></input>
            <script>
                //-----------------------------------------start
                function doSearchCustomer() {
                    $('#dguser').datagrid('load', {
                        search_customer: $('#searchCustomer').val()
                    });
                }
                //-----------------------------------------end
            </script>
            <!---------SEARCH BOX END----------->
        </div>
    </div>
</div>
<!-- TOOLBAR END -->
<script type="text/javascript">
    $('#fo2').hide();
    //-----------------------------------------start
    function show_res(val, row) {
        for (var name in row) {
            var file = (row.file == '') ? 'Tidak Ada' : `<a href="<?= XROOT ?>file/wa_media/` + row.file + `" target="_blank"><small><strong>` + row.file + `</strong></small></a>`;
            var status = (row.status == 'true') ? 'ENABLE' : 'DISABLE';

            var t = `
            <div class="card col table-responsive my-1">
                <div class="row mt-1">
                    <div class="col-md-11">
                        <strong>` + row.judul + `</strong>
                    </div>
                    <div class="col-md-1">
                        <a href="javascript:void(0)" onclick="lifeview()" class="pri-a"><i class="fa fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
            `;
            if (row["pur_res"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function hid() {
        $('#fo2').hide();
        $('#fo1').show();
        $('#content').html('');
        $('#dguser').datagrid('reload');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function lifeview() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $('#fo1').hide();
            $('#fo2').show();
            $("#head").html('<strong class="float-left">' + row.judul + '</strong>');
            if (row.role == 'PDF') {
                if (row.file != '') {
                    $('#content').html('<iframe src="<?= XROOT ?>file/pdf/' + row.file + '" frameborder="0" width="100%" height="1000px"></iframe>');
                } else {
                    $('#content').html('');
                }
            } else {
                $('#content').html(row.text);
            }
        } else {
            msg('Error', 'Klick Sekali Lagi');
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    $(function() {
        $('#dguser').datagrid({
            singleSelect: true,
            onDblClickRow: function() {
                lifeview()
            }
        })

    })
    //-----------------------------------------end
</script>