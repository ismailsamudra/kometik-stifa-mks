<script src="<?= XROOT ?>script/web/js/jquery.min.js"></script>
<script src="<?= XROOT ?>script/owlcarousel/owl.carousel.min.js"></script>
<div class="">
    <!-- Start Img Slider -->
    <style>
        .slid>img {
            width: 100%;
            height: 500px !important;
            /* min-height: 500px; */
            /* border-radius: 20px; */
            object-fit: static;
            object-position: center;
        }

        @media only screen and (max-width: 600px) {
            .slid>img {
                width: 100%;
                height: 100% !important;
                /* border-radius: 20px;  */
                object-fit: cover;
                object-position: center;
            }
        }

        /* .brd {
                    border-radius: 10px;
                    border: 1px solid <?= color('primary-c') ?>;
                    color: <?= color('primary-c') ?>;
                    } */
        .round {
            border-radius: 10px;
        }

        .bot {
            position: absolute;
            bottom: 0;
            left: 0;
        }

        .dt:hover .arr,
        .dt:hover {
            background-color: <?= color('primary-b'); ?>;
            color: #000;
        }

        .dt2:hover {
            background-color: #dce2fc;
        }

        .arr {
            color: #fff;
        }
    </style>
    <!-- <div class="container"> -->
    <div class="col-12">
        <div class="section">
            <div class="row">
                <div class="owl-carousel slider">
                    <?php $ss = db('web_slider')->getWhere(['status' => 'true'])->getResult(); ?>
                    <?php foreach ($ss as $o) : ?>
                        <div class="item slid">
                            <img src="<?= XROOT ?>img/web/slider/<?= $o->img ?>" class="" alt="...">
                        </div>
                    <?php endforeach ?>
                </div>
            </div>
        </div>
    </div>
    <!-- </div> -->
    <!-- End Img Slider -->

    <!-- <hr class="theme_bg "> -->
    <div class="section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <br>
                </div>
                <div class="col-md-12">
                    <div class="full center">
                        <div class="heading_main text_align_center">
                            <h2><span class="theme_color">TENAGA</span> KEPENDIDIKAN</h2>
                            <p class="large"><?= inc('app-name') ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <!-- TEAM START -->
                    <link rel="stylesheet" href="<?= XROOT ?>script/owlcarousel/assets/owl.carousel.min.css" />
                    <link rel="stylesheet" href="<?= XROOT ?>script/owlcarousel/assets/owl.theme.default.min.css" />
                    <div class="row">
                        <div class="owl-carousel team">
                            <?php $tm = db('web_team')->getWhere(['status' => 'true'])->getResult(); ?>
                            <?php foreach ($tm as $t) : ?>
                                <?php
                                if ($t->type == 'USERS') {
                                    $x = db('users')->getWhere(['id' => $t->user], 1)->getRow();
                                    $nama = $x->nama;
                                    $foto = ($x->foto == null) ? $x->jk . '2.png' : $x->foto;
                                } else {
                                    $nama = $t->nama;
                                    $foto = ($t->foto == null) ? $t->jk . '2.png' : $t->foto;
                                }
                                ?>
                                <div class="item col-md-12 mb-2">
                                    <div class="row">
                                        <div class="col-4 team-img">
                                            <center>
                                                <img src="<?= XROOT ?>img/avatar/<?= $foto ?>" class="rounded" width="100%">
                                            </center>
                                        </div>
                                        <div class="col-8">
                                            <small>
                                                <strong>
                                                    <h3><?= $nama ?></h3>
                                                </strong>
                                            </small>

                                            <strong><?= $t->jabatan ?></strong><br>
                                            <label><?= $t->desk ?></label>

                                        </div>
                                    </div>
                                </div>
                            <?php endforeach ?>

                        </div>
                    </div>
                    <!-- TEAM END -->
                </div>
            </div>
        </div>
    </div>

    <!-- section -->
    <div class="section layout_padding theme_bg">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="full center">
                        <div class="heading_main text_align_center">
                            <h2><span class="text-white">VISI</span> MISI</h2>
                            <p class="large text-white">**</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 white_fonts">
                    <h1 class="text-white">VISI</h1>
                    <?php $visi = db('web_visi_misi')->getWhere(['status' => 'true', 'role' => 'visi'])->getResult(); ?>
                    <div class="row">
                        <?php foreach ($visi as $o) : ?>
                            <div class="col-2 my-1">
                                <i class="fa fa-sign-out-alt fa-2x"></i>
                            </div>
                            <div class="col-10 my-1">
                                <?= $o->text ?>
                            </div>
                        <?php endforeach ?>
                    </div>
                </div>
                <div class="col-md-4 white_fonts">
                    <h1 class="text-white">MISI</h1>
                    <?php $misi = db('web_visi_misi')->getWhere(['status' => 'true', 'role' => 'misi'])->getResult(); ?>
                    <div class="row">
                        <?php foreach ($misi as $o) : ?>
                            <div class="col-2 my-1">
                                <i class="fa fa-sign-out-alt fa-2x"></i>
                            </div>
                            <div class="col-10 my-1">
                                <?= $o->text ?>
                            </div>
                        <?php endforeach ?>
                    </div>
                </div>
                <div class="col-md-4 white_fonts">
                    <h1 class="text-white">TUJUAN</h1>
                    <?php $tujuan = db('web_visi_misi')->getWhere(['status' => 'true', 'role' => 'tujuan'])->getResult(); ?>
                    <div class="row">
                        <?php foreach ($tujuan as $o) : ?>
                            <div class="col-2 my-1">
                                <i class="fa fa-sign-out-alt fa-2x"></i>
                            </div>
                            <div class="col-10 my-1">
                                <?= $o->text ?>
                            </div>
                        <?php endforeach ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end section -->

    <!-- section -->
    <div class="section layout_padding">
        <div class="container">

            <div class="row">
                <div class="col-md-12">
                    <div class="full center margin-bottom_30">
                        <div class="heading_main text_align_center">
                            <h2><span class="theme_color">LINK</span> TERKAIT</h2>
                            <p class="large">**</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <?php $link = db('web_link')->getWhere(['status' => 'true'])->getResult(); ?>

                    <marquee direction="left" scrollamount="4" align="center" behavior="alternate">
                        <?php
                        foreach ($link as $o) {
                            if ($o->logo != null) {
                                $url = ($o->url == null) ? 'href="javascip:void(0);"' : 'href="' . $o->url . '" target="_blank"';
                                echo '
                              <a ' . $url . ' class="">
                                <img class="img-responsive mx-2 round dt2" src="' . XROOT . 'img/link/' . $o->logo . '" width="120" title="' . $o->nama . '" />
                              </a>
                              ';
                            }
                        }
                        ?>
                    </marquee>
                </div>
                <div class="col-md-12 mt-4">
                    <div class="full center">
                        <a href="<?= XROOT ?>web/link" class="hvr-radial-out button-theme">Tampilkan Semua</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- end section -->

    <!-- section -->
    <div class="section layout_padding theme_bg">
        <div class="container">

            <div class="row">
                <div class="col-md-12">
                    <div class="full center">
                        <div class="heading_main text_align_center">
                            <h2><span class="text-white">BERITA</span> TERBARU</h2>
                            <p class="large text-white">**</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <?php $berita = db('web_berita')->orderBy('id', 'DESC')->getWhere(['status' => 'true'], 3)->getResult(); ?>
                    <?= (!$berita) ? '<center class="text-white"><strong><br><br><br><br>NO CONTENT<br><br><br><br></strong></center>' : ''; ?>
                    <div class="row">
                        <?php foreach ($berita as $o) : ?>
                            <?php (empty($o->img)) ? $img = 'default1.png' : $img = $o->img; ?>
                            <div class="col-md-4 my-2">
                                <div class="card bg-1 dt">
                                    <div class="row g-0 m-1">
                                        <div class="col-12">
                                            <img class="img-responsive my-2 round" src="<?= XROOT ?>img/web/berita/<?= $img ?>" alt="#" />
                                            <div class="ribbon"><a href="<?= XROOT ?>web/berita/<?= en64($o->id) ?>" class="m-2" title="Selengkapnya">Selengkapnya<i class="fa fa-sign-out-alt ml-2"></i></a></div>
                                        </div>
                                        <div class="col-12">
                                            <?= $o->judul ?><br>
                                            <small>Time Post : <?= $o->time ?></small> <br>
                                            <small>View : <?= $o->view ?></small><br>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        <?php endforeach ?>
                    </div>
                </div>

                <div class="col-md-12 mt-4">
                    <div class="full center">
                        <a href="<?= XROOT ?>web/berita" class="hvr-radial-out button-theme">Tampilkan Semua</a>
                    </div>
                </div>

            </div>

        </div>
    </div>
    <!-- end section -->

    <!-- section -->
    <div class="section layout_padding">
        <div class="container">
            <center>
                <div class="row">
                    <?php
                    if (inc('url_video_profil') != null) {
                        echo '
                    <div class="col-md-6">
                        <strong class="mb-2">Video Profile</strong>
                        <div class="">
                            <iframe width="100%" height="300" src="' . inc('url_video_profil') . '" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                    </div>
                    ';
                    }
                    ?>
                    <?php
                    if (inc('url_google_map') != null) {
                        echo '
                    <div class="col-md-6">
                    <strong class="mb-2">Google Map</strong>
                    <div class="mapouter">
                        <div class="gmap_canvas">
                            <iframe class="gmap_iframe" width="100%" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="' . inc('url_google_map') . '">
                            </iframe>
                        </div>
                        <style>
                            .mapouter {
                                position: relative;
                                text-align: right;
                                width: 100%;
                                height: 300px;
                            }

                            .gmap_canvas {
                                overflow: hidden;
                                background: none !important;
                                width: 100%;
                                height: 300px;
                            }

                            .gmap_iframe {
                                width: 100% !important;
                                height: 300px !important;
                            }
                        </style>
                    </div>
                </div>
                    ';
                    }
                    ?>
                </div>
            </center>
        </div>
    </div>
    <!-- end section -->
</div>
<script>
    $('.slider').owlCarousel({
        items: 1,
        loop: true,
        margin: 0,
        scrollPerPage: false,
        autoplay: true,
        autoplayTimeout: 5000,
        autoplayHoverPause: false,
        responsiveClass: true,
        navigation: false
    });
    $('.team').owlCarousel({
        items: 1,
        loop: true,
        margin: 0,
        scrollPerPage: false,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: false,
        responsiveClass: true,
        navigation: false,
        responsive: {
            0: {
                items: 1,
            },
            600: {
                items: 2,
            },
            1000: {
                items: 3,
            }
        }
    });
    $('.rant').owlCarousel({
        items: 3,
        loop: true,
        margin: 0,
        scrollPerPage: false,
        autoplay: true,
        autoplayTimeout: 4000,
        autoplayHoverPause: false,
        responsiveClass: true,
        navigation: false,
        responsive: {
            0: {
                items: 1,
            },
            600: {
                items: 2,
            },
            1000: {
                items: 3,
            }
        }
    });
    $('.ulas').owlCarousel({
        items: 1,
        loop: true,
        margin: 0,
        scrollPerPage: false,
        autoplay: true,
        autoplayTimeout: 8000,
        autoplayHoverPause: false,
        responsiveClass: true,
        navigation: false,
        responsive: {
            0: {
                items: 1,
            },
            600: {
                items: 1,
            },
            1000: {
                items: 1,
            }
        }
    });
</script>