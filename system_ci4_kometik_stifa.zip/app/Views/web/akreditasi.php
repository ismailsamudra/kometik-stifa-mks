<script src="<?= XROOT ?>script/web/js/jquery.min.js"></script>
<!-- BODY START ----------------------------------------------------------->
<div class="col-md-12 my-4">
    <div class="full center">
        <div class="heading_main text_align_center">
            <h2><span class="theme_color">AKREDI</span>TASI</h2>
            <p class="large" id="label_top"><?= inc('app-name') ?></p>
        </div>
    </div>
</div>

<!-- <div class="section layout_padding"> -->
<div class="container">
    <div id="pdf"></div>
    <div class="row" id="menu">
        <div class="col-12">
            <strong><label>Klik Untuk Melihat</label></strong>
        </div>
        <?php
        $dir = glob("file/pdf/*.pdf");
        // if (count($dir) == 0) echo 'XXXX';
        for ($i = 0; $i < count($dir); $i++) {
            $single_image = $dir[$i];
            $name = str_replace("file/pdf/", "", $single_image);
            $e = explode(".", $single_image);
            $ext = end($e);
            $x = str_replace(".PDF", "", strtoupper($name));
            $y = explode("__", $x);
            $time = date("d M Y", $y[1]);
            $nm = str_replace("_", " ", $y[0]);
        ?>
            <div class="col-12" id="c-<?= $i ?>">
                <a href="javascript:void(0);" onclick="show_pdf('c-<?= $i ?>','<?= en64($single_image) ?>','<?= $nm ?>');">
                    <div class="card col m-1">
                        <div class="row">
                            <div class="col-md-1">
                                <i class="fa fa-file-pdf fa-2x text-danger m-1 mr-2"></i>
                            </div>
                            <div class="col-md-7">
                                <strong><?= $nm ?></strong>
                            </div>
                            <div class="col-md-4">
                                <small>Time Update : <?= $time ?></small>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        <?php
        }
        ?>
    </div>
</div>

<!-- </div> -->

<!-- BODY END ------------------------------------------------------------->
<script>
    function show_pdf(val, item, name) {
        var pdf = `
        <a href="javascript:void(0);" class="float-right" onclick="hide_pdf()" title="Close"><i class="fa fa-times fa-border text-danger m-1"> Close</i></a>
        <iframe src="<?= XROOT ?>` + atob(item) + `" frameborder="0" width="100%" height="1200px"></iframe>
        `;
        $('#label_top').html(name);
        $('#pdf').html(pdf);
        $('#menu').hide();
    }

    function hide_pdf() {
        $('#label_top').html('<?= inc('app-name') ?>');
        $('#pdf').html('')
        $('#menu').show();
    }
</script>
<br><br><br><br><br><br><br><br>