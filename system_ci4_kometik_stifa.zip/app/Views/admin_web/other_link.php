<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <a id="btnadd"></a>
            <a href="" style="color: <?= color('primary-b') ?>;">
                <strong>
                    <i class="fa fa-globe mr-2"></i> <?= strtoupper(str_replace('/', ' ', XURI)) ?>
                </strong>
            </a>
            <a href="javascript:void(0);" onclick="$('#dguser').datagrid('reload');" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<input type="hidden" id="idx">
<div class="row m-2">
    <div class="col-md-9 mb-2 mt-2 table-responsive">
        <div class="card col-12 mb-2 bg-2">
            <div class="row">
                <div class="col-md-2">
                    <div class="">
                        <small><strong>LABEL IN WEB</strong></small>
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="col">
                        <div class="row">
                            <div class="col-md-10">
                                <div id="other_link_lb"><strong><?= inc('other_link'); ?></strong></div>
                                <input type="text" id="other_link" style="height: 23px;" value="<?= inc('other_link') ?>" class="form-control">
                            </div>
                            <div class="col-md-2">
                                <x>
                                    <a href="javascript:void(0);" id="bt_e_other_link" class="float-right sec-b" onclick="pass_e()"><i class="fa fa-edit" title="Edit"></i></a>
                                    <a href="javascript:void(0);" id="bt_s_other_link" class="float-right sec-b" onclick="save_inc('other_link')"><i class="fa fa-save" title="Save"></i></a>
                                </x>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script>
            //===========================================
            $('#other_link_lb').show();
            $('#other_link').hide();
            $('#bt_s_other_link').hide();
            $('#bt_e_other_link').show();
            //===========================================
            function pass_e() {
                $('#bt_e_other_link').hide();
                $('#bt_s_other_link').show();
                $('#other_link_lb').hide();
                $('#other_link').show();
                $('#other_link').focus();
            }
            //===========================================
            //===========================================
            function save_inc(id) {
                var val = document.getElementById(id).value;
                var url = '<?= XROOT ?>portal/save_inc_text';
                $.post(url, {
                    id,
                    val
                }, function(result) {
                    if (result.success) {
                        document.getElementById(id + '_lb').innerHTML = '<strong>' + val + '</strong>';
                        $('#' + id).hide();
                        $('#' + id + '_lb').show();
                        $('#bt_s_' + id).hide();
                        $('#bt_e_' + id).show();
                        $.messager.show({ // show error message
                            title: 'Success !',
                            msg: 'Berhasil di Update.'
                        });
                    } else {
                        $.messager.show({ // show error message
                            title: 'Error !',
                            msg: result.errorMsg
                        });
                    }
                }, 'json');
            }
            //===========================================
        </script>
        <div class="row">

            <div class="col-12" id="fo1">
                <center>
                    <table id="dguser" toolbar="" class="easyui-datagrid" singleSelect="true" style="width: 100%;" fitColumns="false" rowNumbers="true" pagination="true" url="<?= XROOT ?>admin_web/get_other_link" pageSize="10" pageList="[10,25,50,75,100,125,150,200]">
                        <thead>
                            <tr>
                                <th field="id" width="100%" formatter="show_res" sortable="true"></th>
                            </tr>
                        </thead>
                    </table>
                </center>
            </div>
            <div class="col-12" id="fo2">
                <div class="card col bg-1 mb-2">
                    <x>
                        <div id="head"></div>
                        <a href="javascript:void(0);" onclick="hid()" class="float-right pri-b mx-1" title="Close"><i class="fa fa-times"></i></a>
                        <a href="javascript:void(0)" onclick="save();" class="pri-b float-right mx-1" title="Save"><i class="fa fa-save"></i></a>
                    </x>
                </div>
                <form id="fm" method="post" enctype="multipart/form-data">
                    <input type="hidden" id="id" name="id">
                    <div class="card col my-1">
                        <div class="row my-2">
                            <div class="col-md-2">
                                <small><strong>METODE</strong></small>
                            </div>
                            <div class="col-md-4">
                                <input type="radio" class="mr-2" name="metode" id="metode1" value="THIS">Open This Tab
                            </div>
                            <div class="col-md-4">
                                <input type="radio" class="mr-2" name="metode" id="metode1" value="NEW">Open New Tab
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <small><strong>LABEL</strong></small>
                            </div>
                            <div class="col-12 mb-2">
                                <input type="text" class="form-control" placeholder="Input Label.." style="height: 24px;" id="label" name="label">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <small><strong>URL</strong></small>
                            </div>
                            <div class="col-12 mb-2">
                                <textarea name="url" id="url" cols="30" rows="2" class="form-control"></textarea>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-12" id="fo3">
                <!-- ...... -->
            </div>
        </div>

    </div>
    <div class="col-md-3 mb-2 mt-2 table-responsive">
        <div class="container">
            <div class="">
                <strong>
                    M-BOOK :
                </strong>
                <hr>
                Doubel Klick pada baris data Untuk Edit Data
                <hr>
                Untuk Menu Lain Klick Kanan jika desktop dan sentuh tahan jika HP.
                <hr>
                Tombol Save Berada Pada Kolom Kanan Atas di samping tombol close
                <hr>
            </div>
            <br>
        </div>
        <center>
            <i class="fa fa-globe fa-5x"></i><br>
            <strong>
                <?= strtoupper(str_replace('/', ' ', XURI)) ?>
            </strong><br>
        </center>
    </div>
</div>
<!-- BODY END -->
<!-- KLICK KANAN START -->
<div id="mm" class="easyui-menu">
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="edit();"><i class="fa fa-edit mr-2"></i>Edit</a>
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="change_status();"><span id="btn-status"></span></a>
    <a href="javascript:void(0)" class="btn-sm form-control" plain="true" onClick="destroyuser();"><i class="fa fa-trash mr-2 text-danger"></i> Hapus</a>
</div>
<!-- KLICK KANAN END -->
<script type="text/javascript">
    $('#btnadd').html('<a href="javascript:void(0);" onclick="add();" class="btn-sm bt-1 float-left" title="TAMBAH"><i class="fa fa-plus"></i></a>');
    $('#fo2').hide();
    $('#fo3').hide();
    $('#fo1').show();
    //-----------------------------------------start
    function hid() {
        $('#fm').form('clear');
        $('#fo2').hide();
        $('#fo3').hide();
        $('#fo1').show();
        $('#url').val('');
        $('#label').val('');
        $('#dguser').datagrid('reload');
        $('#btnadd').html('<a href="javascript:void(0);" onclick="add();" class="btn-sm bt-1 float-left" title="TAMBAH"><i class="fa fa-plus"></i></a>');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function show_res(val, row) {
        for (var name in row) {
            status = (row.status == 'true') ? 'YA' : 'TIDAK';
            metode = (row.metode == 'THIS') ? 'Open This Tab' : 'Open New Tab';
            var t = `
            <div class="card col table-responsive my-1">
                <div class="row mt-1">
                    <div class="col-md-12 col-12">
                        <div class="row">
                            <div class="col-md-2 col-6">
                                <small>Tampikan Di Web</small>
                            </div>
                            <div class="col-md-10 col-6">
                            <strong>: ` + status + `</strong>  
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2 col-6">
                                <small>LABEL</small>
                            </div>
                            <div class="col-md-10 col-6">
                            <strong>: ` + row.label + `</strong>  
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2 col-6">
                                <small>Metode</small>
                            </div>
                            <div class="col-md-10 col-6">
                            <strong>: ` + metode + `</strong>  
                            </div>
                        </div>
                        <div class="row mb-1">
                            <div class="col-md-2">
                                <small>URL</small>
                            </div>
                            <div class="col-md-10">
                            <textarea cols="30" rows="2" class="form-control iwhite" readonly>` + row.url + `</textarea> 
                            </div>
                        </div>
                    </div>
                    
                </div>
               
            </div>
            `;
            if (row["id"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function add() {
        $('#fm').form('clear');
        $('#fo1').hide();
        $('#fo3').hide();
        $('#fo2').show();
        $('#btnadd').html('');
        document.getElementById('metode1').checked = true;
        $("#head").html('<small class="float-left"><i class="fa fa-plus mr-2"></i>Tambah Data</small>')
        document.getElementById("id").value = 'insert';
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function edit() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $('#fm').form('load', row);
            $('#fo1').hide();
            $('#fo3').hide();
            $('#fo2').show();
            $('#btnadd').html('');
            $("#head").html('<small class="float-left"><i class="fa fa-edit mr-2"></i>Edit Data</small>');
        } else {
            msg('Error', 'Data tidak di pilih');
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function change_status() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Merubah Status data ini ?<br>LABEL : ' + row.label, function(r) {
                if (r) {
                    $.post("<?= XROOT ?>admin_web/status_other_link", {
                        id: row.id
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload');
                            msg('Success !', 'Status Berhasil Di Ubah');
                        } else {
                            msg('Error', result.errorMsg);
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function destroyuser() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Menghapus data ini ?<br>LABEL : ' + row.label, function(r) {
                if (r) {
                    $.post("<?= XROOT ?>admin_web/del_other_link", {
                        id: row.id
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload');
                            msg('Success !', 'Berhasil Di Hapus');
                        } else {
                            msg('Error', result.errorMsg);
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function save() {
        ($('#label').val() == '') ? [msg('Error', 'Label harus di isi'), $('#label').focus(), exit] : '';
        ($('#url').val() == '') ? [msg('Error', 'url harus di isi'), $('#url').focus(), exit] : '';
        $('#fm').form('submit', {
            url: '<?= XROOT ?>admin_web/save_other_link',
            ajax: 'true',
            iframe: 'false',
            onSubmit: function() {
                return $(this).form('validate');
            },
            success: function(result) {
                var result = eval('(' + result + ')');
                if (result.success) {
                    ($('#id').val() == 'insert') ? hid(): '';
                    msg('Success !', 'Berhasil di Save');
                } else {
                    msg('Error', result.errorMsg);
                }
            }
        });
    }
    //-----------------------------------------end
    //-----------------------------------------start
    $(function() {
        $('#dguser').datagrid({
            singleSelect: true,
            onRowContextMenu: function(e, index, row) {
                document.getElementById('id').value = row.id;
                if (row.status == 'true') {
                    document.getElementById("btn-status").innerHTML = '<i class="fa fa-globe text-danger mr-2"></i>Hide in Web';
                } else {
                    document.getElementById("btn-status").innerHTML = '<i class="fa fa-globe text-success mr-2"></i>Show in Web';
                }
                $(this).datagrid('selectRow', index);
                e.preventDefault();
                $('#mm').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
            },
            onDblClickRow: function() {
                edit();
            }
        })

    })
    //-----------------------------------------end
</script>