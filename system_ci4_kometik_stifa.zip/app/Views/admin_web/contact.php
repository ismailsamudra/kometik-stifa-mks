<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <a id="btnadd"></a>
            <a href="" style="color: <?= color('primary-b') ?>;">
                <strong>
                    <i class="fa fa-globe mr-2"></i> <?= strtoupper(str_replace('/', ' ', XURI)) ?>
                </strong>
            </a>
            <a href="javascript:void(0);" onclick="$('#dguser').datagrid('reload');" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<input type="hidden" id="idx">
<div class="row m-2">
    <div class="col-md-9 mb-2 mt-2 table-responsive">
        <div class="row">

            <div class="col-12" id="fo1">
                <center>
                    <table id="dguser" toolbar="" class="easyui-datagrid" singleSelect="true" style="width: 100%;" fitColumns="false" rowNumbers="false" pagination="true" url="<?= XROOT ?>admin_web/get_contact" pageSize="10" pageList="[10,25,50,75,100,125,150,200]">
                        <thead>
                            <tr>
                                <th field="id" width="100%" formatter="show_res" sortable="true"></th>
                            </tr>
                        </thead>
                    </table>
                </center>
            </div>
            <div class="col-12" id="fo2">
                <div class="card col bg-1 mb-2">
                    <x>
                        <div id="head"></div>
                        <a href="javascript:void(0);" onclick="hid()" class="float-right pri-b mx-1" title="Close"><i class="fa fa-times"></i></a>
                        <a href="javascript:void(0)" onclick="save();" class="pri-b float-right mx-1" title="Save"><i class="fa fa-save"></i></a>
                    </x>
                </div>
                <form id="fm" method="post" enctype="multipart/form-data">
                    <input type="hidden" id="id" name="id">
                    <div class="card col my-1">
                        <div class="row">
                            <div class="col-12">
                                <small><strong>LABEL</strong></small>
                            </div>
                            <div class="col-12 mb-2">
                                <input type="text" class="form-control" placeholder="Input Label.." style="height: 24px;" id="label" name="label">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <small><strong>URL</strong></small>
                            </div>
                            <div class="col-12 mb-2">
                                <input type="url" class="form-control" placeholder="Input Url.." style="height: 24px;" id="url" name="url">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-12" id="fo3">
                <!-- ...... -->
            </div>
        </div>

    </div>
    <div class="col-md-3 mb-2 mt-2 table-responsive">
        <div class="container">
            <div class="">
                <strong>
                    M-BOOK :
                </strong>
                <hr>
                Doubel Klick pada baris data Untuk Edit Data
                <hr>
                Untuk Menu Lain Klick Kanan jika desktop dan sentuh tahan jika HP.
                <hr>
                Tombol Save Berada Pada Kolom Kanan Atas di samping tombol close
                <hr>
            </div>
            <br>
        </div>
        <center>
            <i class="fa fa-globe fa-5x"></i><br>
            <strong>
                <?= strtoupper(str_replace('/', ' ', XURI)) ?>
            </strong><br>
        </center>
    </div>
</div>
<!-- BODY END -->
<!-- KLICK KANAN START -->
<div id="mm" class="easyui-menu">
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="edit();"><i class="fa fa-edit mr-2"></i>Edit</a>
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="change_status();"><span id="btn-status"></span></a>
    <a href="javascript:void(0)" class="btn-sm form-control" plain="true" onClick="destroyuser();"><i class="fa fa-trash mr-2 text-danger"></i> Hapus</a>
</div>
<!-- KLICK KANAN END -->
<script type="text/javascript">
    $('#btnadd').html('<a href="javascript:void(0);" onclick="add();" class="btn-sm bt-1 float-left" title="TAMBAH"><i class="fa fa-plus"></i></a>');
    $('#fo2').hide();
    $('#fo3').hide();
    $('#fo1').show();
    //-----------------------------------------start
    function hid() {
        $('#fm').form('clear');
        $('#fo2').hide();
        $('#fo3').hide();
        $('#fo1').show();
        $('#url').val('');
        $('#dguser').datagrid('reload');
        $('#btnadd').html('<a href="javascript:void(0);" onclick="add();" class="btn-sm bt-1 float-left" title="TAMBAH"><i class="fa fa-plus"></i></a>');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function show_res(val, row) {
        for (var name in row) {
            status = (row.status == 'true') ? 'YA' : 'TIDAK';
            var t = `
            <div class="card col table-responsive my-1">
                <div class="row mt-1">
                    <div class="col-md-2 col-6">
                       <center>
                           <i class="fab fa-whatsapp fa-5x text-success mt-2"></i>
                       </center>
                    </div>
                    <div class="col-md-10 col-12">
                        <div class="row">
                            <div class="col-md-2 col-6">
                                <small>Tampikan Di Web</small>
                            </div>
                            <div class="col-md-10 col-6">
                            <strong>: ` + status + `</strong>  
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2 col-6">
                                <small>LABEL</small>
                            </div>
                            <div class="col-md-10 col-6">
                            <strong>: ` + row.label + `</strong>  
                            </div>
                        </div>
                        <div class="row mb-1">
                            <div class="col-md-2">
                                <small>URL</small>
                            </div>
                            <div class="col-md-10">
                            <textarea cols="30" rows="2" class="form-control iwhite" readonly>` + row.url + `</textarea> 
                            </div>
                        </div>
                    </div>
                    
                </div>
               
            </div>
            `;
            if (row["id"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function add() {
        $('#fm').form('clear');
        $('#fo1').hide();
        $('#fo3').hide();
        $('#fo2').show();
        $('#btnadd').html('');
        $("#head").html('<small class="float-left"><i class="fa fa-plus mr-2"></i>Tambah Data</small>')
        document.getElementById("id").value = 'insert';
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function edit() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $('#fm').form('load', row);
            $('#fo1').hide();
            $('#fo3').hide();
            $('#fo2').show();
            $('#btnadd').html('');
            $("#head").html('<small class="float-left"><i class="fa fa-edit mr-2"></i>Edit Data</small>');
        } else {
            msg('Error', 'Data tidak di pilih');
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function change_status() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Merubah Status data ini ?<br>LABEL : ' + row.label, function(r) {
                if (r) {
                    $.post("<?= XROOT ?>admin_web/status_contact", {
                        id: row.id
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload');
                            msg('Success !', 'Status Berhasil Di Ubah');
                        } else {
                            msg('Error', result.errorMsg);
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function destroyuser() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Menghapus data ini ?<br>LABEL : ' + row.label, function(r) {
                if (r) {
                    $.post("<?= XROOT ?>admin_web/del_contact", {
                        id: row.id
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload');
                            msg('Success !', 'Berhasil Di Hapus');
                        } else {
                            msg('Error', result.errorMsg);
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function save() {
        ($('#label').val() == '') ? [msg('Error', 'Label harus di isi'), $('#label').focus(), exit] : '';
        ($('#url').val() == '') ? [msg('Error', 'URL harus di isi'), $('#url').focus(), exit] : '';
        $('#fm').form('submit', {
            url: '<?= XROOT ?>admin_web/save_contact',
            ajax: 'true',
            iframe: 'false',
            onSubmit: function() {
                return $(this).form('validate');
            },
            success: function(result) {
                var result = eval('(' + result + ')');
                if (result.success) {
                    ($('#id').val() == 'insert') ? hid(): '';
                    if (result.file) {
                        $('#disp_logo').html('<img class="img-responsive mx-2" src="<?= XROOT ?>img/link/' + result.file + '" width="120" />');
                    }
                    msg('Success !', 'Berhasil di Save');
                } else {
                    msg('Error', result.errorMsg);
                }
            }
        });
    }
    //-----------------------------------------end
    //-----------------------------------------start
    $(function() {
        $('#dguser').datagrid({
            singleSelect: true,
            onRowContextMenu: function(e, index, row) {
                document.getElementById('id').value = row.id;
                if (row.status == 'true') {
                    document.getElementById("btn-status").innerHTML = '<i class="fa fa-globe text-danger mr-2"></i>Hide in Web';
                } else {
                    document.getElementById("btn-status").innerHTML = '<i class="fa fa-globe text-success mr-2"></i>Show in Web';
                }
                $(this).datagrid('selectRow', index);
                e.preventDefault();
                $('#mm').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
            },
            onDblClickRow: function() {
                edit();
            }
        })

    })
    //-----------------------------------------end
</script>