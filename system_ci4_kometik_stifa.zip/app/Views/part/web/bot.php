<!-- Start Footer -->
<footer class="footer-box">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 d-md-none d-sm-block">
                <div class="logo">
                    <img src="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" width="60" />
                </div>
            </div>
            <div class="col-lg-12 white_fonts d-md-none d-sm-block">
                <h4 class="text-align"><?= inc('app-name') ?></h4>
            </div>
            <div class="margin-top_30 col-md-8 offset-md-2 white_fonts">
                <div class="row">
                    <div class="col-md-6" title="Alamat">
                        <div class="full icon text_align_center">
                            <i class="fa fa-map-marker-alt fa-2x"></i>
                        </div>
                        <div class="full white_fonts text_align_center">
                            <p>
                                <?= inc('alamat') ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6" title="Email">
                        <div class="full icon text_align_center">
                            <i class="fa fa-envelope fa-2x"></i>
                        </div>
                        <div class="full white_fonts text_align_center">
                            <p>
                                <?= inc('email') ?>
                            </p>
                        </div>
                        <div class="full icon text_align_center">
                            <i class="fa fa-phone-volume fa-2x"></i>
                        </div>
                        <div class="full white_fonts text_align_center">
                            <p>
                                <?= inc('telp') ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="row white_fonts margin-top_30">
            <div class="col-lg-12">
                <div class="full">
                    <div class="center">
                        <ul class="social_icon">
                            <?= (inc('url_facebook') != null) ? '<li><a href="' . inc('url_facebook') . '" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>' : '' ?>
                            <?= (inc('url_instagram') != null) ? '<li><a href="' . inc('url_instagram') . '" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a></li>' : '' ?>
                            <?= (inc('url_whatsapp') != null) ? '<li><a href="' . inc('url_whatsapp') . '" target="_blank" title="Whatsapp"><i class="fab fa-whatsapp"></i></a></li>' : '' ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- End Footer -->

<div class="footer_bottom">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <p class="crp">© <?= date("Y") . ' ' . inc('nama-instansi') ?> . All Rights Reserved.</p>
                <ul class="bottom_menu text-white">
                    <li>Tanggal</li>
                    <li><?= date("d M Y") ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<a href="#" id="scroll-to-top" class="hvr-radial-out"><i class="fa fa-angle-up"></i></a>

<!-- ALL JS FILES -->
<script src="<?= XROOT ?>script/web/js/jquery.min.js"></script>
<script src="<?= XROOT ?>script/web/js/popper.min.js"></script>
<script src="<?= XROOT ?>script/web/js/bootstrap.min.js"></script>
<!-- ALL PLUGINS -->
<script src="<?= XROOT ?>script/web/js/jquery.magnific-popup.min.js"></script>
<script src="<?= XROOT ?>script/web/js/jquery.pogo-slider.min.js"></script>
<script src="<?= XROOT ?>script/web/js/slider-index.js"></script>
<script src="<?= XROOT ?>script/web/js/smoothscroll.js"></script>
<script src="<?= XROOT ?>script/web/js/form-validator.min.js"></script>
<script src="<?= XROOT ?>script/web/js/contact-form-script.js"></script>
<script src="<?= XROOT ?>script/web/js/isotope.min.js"></script>
<script src="<?= XROOT ?>script/web/js/images-loded.min.js"></script>
<script src="<?= XROOT ?>script/web/js/custom.js"></script>
<script src="<?= XROOT ?>script/toastr/toastr.min.js"></script>
<script type="text/javascript">
    //=============================
    if ('<?= session()->getFlashdata('info'); ?>' == '') {} else {
        toastr.success('<?= session()->getFlashdata('info'); ?>')
    }
    if ('<?= session()->getFlashdata('error'); ?>' == '') {} else {
        toastr.error('<?= session()->getFlashdata('error'); ?>')
    }
    //=============================
</script>
<script>
    var page = "<?= session()->get('page'); ?>";
    var sty = "<?= 'background: ' . color('primary-c') . ';color: ' . color('primary-b') . ';border-radius: 20px;' ?>";
    document.getElementById(page).style = sty;
</script>
</body>

</html>