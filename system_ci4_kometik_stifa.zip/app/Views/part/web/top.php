<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?= $title ?></title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/x-icon" href="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" />
    <link rel="apple-touch-icon" href="#" />
    <link rel="stylesheet" href="<?= XROOT ?>script/web/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= XROOT ?>script/web/css/pogo-slider.min.css">
    <!-- <link rel="stylesheet" href="<?= XROOT ?>script/web/css/style.css"> -->
    <link rel="stylesheet" href="<?= XROOT ?>script/web/css/responsive.css">
    <link rel="stylesheet" href="<?= XROOT ?>script/web/css/custom.css">
    <link rel="stylesheet" href="<?= XROOT ?>script/fontawesome-5.0.9/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="<?= XROOT ?>script/toastr/toastr.min.css">
    <?php include 'css.php'; ?>
    <?php $sty = 'background: ' . color('primary-c') . ';color: ' . color('primary-b') . ';' ?>
</head>

<body id="home" data-spy="scroll" data-target="#navbar-wd" data-offset="98">

    <!-- LOADER -->
    <!-- <div id="preloader">
        <div class="loader">
            <img src="<?= XROOT ?>img/dev/loading.gif" alt="<?= inc('app-name') ?>" />
        </div>
    </div> -->
    <!-- end loader -->
    <!-- END LOADER -->

    <!-- Start header -->
    <header class="top-header">
        <nav class="navbar header-nav navbar-expand-lg">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-3 d-md-none d-block">
                        <button class="navbar-toggler bg-0" style="margin-left:10;" type="button" data-toggle="collapse" data-target="#navbar-wd" aria-controls="navbar-wd" aria-expanded="false" aria-label="Toggle navigation">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>
                    <div class="col-3 d-none d-md-block">
                        <img src="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" alt="<?= inc('app-name') ?>" width="60">
                    </div>
                    <div class="col-9 mt-2">
                        <h2 class="ml-2">
                            <span class="theme_color2"><?= inc('app-name') ?></span>
                            <br>
                            <small><?= inc('app-name-2') ?></small>
                        </h2>
                    </div>
                </div>
                <div class="collapse navbar-collapse justify-content-end" id="navbar-wd">
                    <ul class="navbar-nav">
                        <li><a class="nav-link" id="pg" href="<?= XROOT ?>">Home</a></li>
                        <li><a class="nav-link" id="berita" href="<?= XROOT ?>web/berita">Berita</a></li>
                        <li><a class="nav-link" id="contact" href="<?= XROOT ?>web/contact">Contact</a></li>
                        <li><a class="nav-link" id="link" href="<?= XROOT ?>web/link">Link Terkait</a></li>
                        <!-- <li><a class="nav-link" id="docu" href="<?= XROOT ?>web/document">Document</a></li> -->
                        <!-- <li><a class="nav-link" id="kuisioner" href="javascript:void(0);">Kuisioner</a></li> -->
                        <!-- DROPDOWN START1 -->
                        <!-- <li>
                            <div class="dropdown mt-2">
                                <a class="dropdown-toggle" id="other" data-toggle="dropdown" aria-expanded="false">OTHER PAGE</a>
                                <div class="dropdown-menu" aria-labelledby="other">
                                <a class="dropdown-item" href="#">LINK1</a>     
                                <a class="dropdown-item" href="#">LINK2</a>     
                                </div>
                            </div>
                        </li> -->
                        <!-- DROPDOWN END1 -->
                        <?php
                        $cek = num_rows('web_other', en64('status="true"'));
                        if ($cek > 0) {
                            $other = db('web_other')->getWhere(['status' => 'true'])->getResult();
                            echo '
                            <!-- DROPDOWN START1 -->
                            <li>
                                <div class="dropdown mt-2">
                                    <a class="dropdown-toggle" id="other" data-toggle="dropdown" aria-expanded="false">' . inc('other_page') . '</a>
                                    <div class="dropdown-menu" aria-labelledby="other">
                            ';
                            foreach ($other as $o) {
                                echo '
                                <a class="dropdown-item" href="' . XROOT . 'web/other/' . en64($o->id) . '">' . $o->label . '</a>             
                                ';
                            }
                            echo '
                                         </div>
                                     </div>
                                </li>
                              <!-- DROPDOWN END2 -->
                            ';
                        }
                        ?>
                        <?php
                        $cek_link = num_rows('web_other_link', en64('status="true"'));
                        if ($cek_link > 0) {
                            $ol = db('web_other_link')->getWhere(['status' => 'true'])->getResult();
                            echo '
                             <!-- DROPDOWN START2 -->
                                <li>
                                    <div class="dropdown mt-2">
                                            <a class="dropdown-toggle" id="other_link" data-toggle="dropdown" aria-expanded="false">' . inc('other_link') . '</a>
                                            <div class="dropdown-menu" aria-labelledby="other_link">
                            ';
                            foreach ($ol as $o) {
                                $metode = ($o->metode == 'NEW') ? 'target="_blank"' : '';
                                echo '
                                <a class="dropdown-item" href="' . $o->url . '" ' . $metode . '>' . $o->label . '</a>              
                                ';
                            }
                            echo '
                                         </div>
                                     </div>
                                </li>
                              <!-- DROPDOWN END2 -->
                            ';
                        }
                        ?>
                        <!-- DROPDOWN START1 -->
                        <li>
                            <div class="dropdown mt-2">
                                <a class="dropdown-toggle" id="other" data-toggle="dropdown" aria-expanded="false">USER</a>
                                <div class="dropdown-menu" aria-labelledby="other">
                                    <a class="dropdown-item" href="/login">LOGIN</a>
                                    <?php
                                    if (inc('register') == 'true') {
                                        echo '<a class="dropdown-item" href="/register">REGISTRASI</a>';
                                    }
                                    if (inc('forgot') == 'true') {
                                        echo '<a class="dropdown-item" href="/forgot">LUPA PASSWORD</a>';
                                    }
                                    ?>
                                </div>
                            </div>
                        </li>
                        <!-- DROPDOWN END1 -->
                    </ul>
                </div>
                <!-- <div class="search-box">
                    <input type="text" class="search-txt" placeholder="Search">
                    <a class="search-btn">
                        <img src="images/search_icon.png" alt="#" />
                    </a>
                </div> -->
            </div>
        </nav>
    </header>
    <!-- End header -->