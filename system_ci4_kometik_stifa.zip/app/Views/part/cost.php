<style>
    .bg-a {
        background-color: #c4d6f2;
        color: #000000;
    }

    .bg-b {
        background-color: #a3ffb4;
        color: #000000;
    }

    .bg-c {
        background-color: #fff6a3;
        color: #000000;
    }

    .bg-m {
        background-color: #f7a3a3;
        color: #000000;
    }

    .bg-0 {
        background-color: <?= color('primary-b'); ?>;
        color: <?= color('primary-a'); ?>;
    }

    .wid-t {
        top: 0rem;
        position: sticky;
        height: 50px;
        z-index: 1000
    }

    .wid-b {
        bottom: 0rem;
        position: sticky;
        height: 50px;
        z-index: 1000
    }

    .modal-top {
        position: fixed;
        z-index: 3000;
    }

    .rol-100 {
        height: 100px;
        overflow-y: scroll;
    }

    .rol-200 {
        height: 200px;
        overflow-y: scroll;
    }

    .rol-300 {
        height: 300px;
        overflow-y: scroll;
    }

    .rol-400 {
        height: 400px;
        overflow-y: scroll;
    }

    .rol-500 {
        height: 500px;
        overflow-y: scroll;
    }

    .bg-1 {
        background-color: <?= color('primary-a'); ?>;
        color: <?= color('primary-b'); ?>;
    }

    .bg-2 {
        background-color: <?= color('secondary-a'); ?>;
        color: <?= color('secondary-b'); ?>;
    }

    .bt-1 {
        background-color: <?= color('btn-wid-a'); ?>;
        color: <?= color('btn-wid-b'); ?>;
    }

    .bg-1-h {
        background-color: <?= color('primary-a'); ?>;
        color: <?= color('primary-b'); ?>;
    }

    .bg-2-h {
        background-color: <?= color('secondary-a'); ?>;
        color: <?= color('secondary-b'); ?>;
    }

    .bg-1-h:hover {
        background-color: <?= color('primary-c'); ?>;
        color: <?= color('primary-b'); ?>;
    }

    .bg-2-h:hover {
        background-color: <?= color('secondary-c'); ?>;
        color: <?= color('secondary-b'); ?>;
    }

    .bt-1:hover {
        background-color: <?= color('btn-wid-c'); ?>;
        color: <?= color('btn-wid-b'); ?>;
    }

    .pri-a {
        color: <?= color('primary-a'); ?>;
    }

    .pri-b {
        color: <?= color('primary-b'); ?>;
    }

    .pri-c {
        color: <?= color('primary-c'); ?>;
    }

    .sec-a {
        color: <?= color('secondary-a'); ?>;
    }

    .sec-b {
        color: <?= color('secondary-b'); ?>;
    }

    .sec-c {
        color: <?= color('secondary-c'); ?>;
    }

    .bw-a {
        color: <?= color('btn-wid-a'); ?>;
    }

    .bw-b {
        color: <?= color('btn-wid-b'); ?>;
    }

    .bw-c {
        color: <?= color('btn-wid-c'); ?>;
    }

    .iwhite[readonly] {
        color: black;
        border-color: #fff;
        background-color: #fff;
        font-size: small;
        font-weight: bold;
    }

    .ribbon {
        position: absolute;
        padding: 0.1em 3em;
        font-size: 1em;
        font-weight: bold;
        right: 0;
        bottom: 0em;
        line-height: 1.875em;
        color: <?= color('secondary-b'); ?>;
        background: <?= color('secondary-a'); ?>;
        box-shadow: -1px 2px 3px rgba(0, 0, 0, 0.5);
    }

    .ribbon:before,
    .ribbon:after {
        position: absolute;
        content: '';
        display: block;
    }

    .ribbon:before {
        width: 0.5em;
        height: 2.05em;
        padding: 0 0 0.5em;
        top: 0;
        right: -0.5em;
        background: <?= color('secondary-a'); ?>;
        border-radius: 0 0 0.5em 0;
    }

    .ribbon:after {
        width: 0.4em;
        height: 0.4em;
        background: rgba(0, 0, 0, 0.5);
        bottom: -0.4em;
        right: -0.4em;
        border-radius: 0 0 0.4em 0;
        box-shadow: inset -1px 2px 2px rgba(0, 0, 0, 0.3);
    }

    .consta>input {
        display: none;
    }
</style>