<div class="m-1">
    <div class="card bg-1">
        <div class="col">
            <small>
                <strong>
                    <x>
                        Data Reviewer
                        <a href="javascript:void(0);" data-toggle="modal" data-target="#rev" class="btn-sm bt-1 float-right mt-1" title="ADD"><i class="fa fa-user-plus mb-1"></i></a>
                    </x>
                </strong>
            </small>
        </div>
    </div>
    <?php foreach ($dt_rev as $o) : ?>
        <?php $y = db('users')->getWhere(['id' => $o->id_rev], 1)->getRow(); ?>
        <?php $x = db($y->level)->getWhere(['id' => $o->id_rev], 1)->getRow(); ?>
        <?php $foto = ($x->foto == null) ? $x->jk . '2.png' : $x->foto; ?>
        <div class="row">
            <div class="col-2 my-2">
                <img src="<?= XROOT ?>img/avatar/<?= $foto ?>" width="100%">
            </div>
            <div class="col-8 my-2">
                <div class="row">
                    <div class="col-4">
                        NAMA
                    </div>
                    <div class="col-8">
                        : <?= $x->nama ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        NIP / NIDN
                    </div>
                    <div class="col-8">
                        : <?= $x->nip___nidn ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <a href="javascript:void(0);" onclick="hapus('<?= $o->id ?>');"><i class="fa fa-trash text-danger mr-2"></i>Hapus</a>
                    </div>
                </div>
            </div>
        </div>

    <?php endforeach ?>
</div>
<!-- Start Modal 1 -->
<?php $rev = db(inc('level_reviewer'))->get()->getResult(); ?>
<div class="modal fade" id="rev" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fa fa-user-plus mr-2"></i>Tambah Reviewer</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form id="fm2" method="post" enctype="multipart/form-data">
                    <label for=""><small>CARI REVIEWER</small></label><br>
                    <select name="id_rev" id="id_rev" class="easyui-combobox" style="width: 340px;" required>
                        <option value=""></option>
                        <?php foreach ($rev as $o) : ?>
                            <option value="<?= $o->id ?>"><?= $o->nama ?> ~ <?= $o->nip___nidn ?></option>
                        <?php endforeach ?>
                    </select>
                </form>

            </div>
            <div class="modal-footer">
                <a href="javascript:void(0);" onclick="save();" class="btn btn-outline-dark btn-sm"><i class="fa fa-plus mr-2"></i>Tambah</a>
            </div>

        </div>
    </div>
</div>
<!-- End Modal 1-->

<script>
    //-----------------------------------------start
    function save() {
        var id_dt = '<?= $id_dt ?>';
        var id_rev = document.getElementById("id_rev").value;
        if (id_rev == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'Reviewer Harus di pilih.'
            });
            $('#id_rev').focus();
            exit;
        }
        $.post("<?= XROOT ?>admin/save_rev", {
            id_rev,
            id_dt
        }, function(result) {
            if (result.success) {
                toastr.info('Berhasil save');
                $('#rev').modal('hide');
                window.location.reload();
            } else {
                toastr.error(result.errorMsg);
            }
        }, 'json');

    }
    //-----------------------------------------end
    //-----------------------------------------start
    function hapus(id) {
        $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Menghapus data ini ?<br>ID: ' + id, function(r) {
            if (r) {
                $.post("<?= XROOT ?>admin/del_rev", {
                    id
                }, function(result) {
                    if (result.success) {
                        toastr.info('Berhasil Di Hapus');
                        window.location.reload();
                    } else {
                        toastr.error(result.errorMsg);
                    }
                }, 'json');
            }
        });
    }
    //-----------------------------------------end
</script>