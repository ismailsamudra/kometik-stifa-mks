<div class="m-1">
    <div class="card bg-1">
        <div class="col">
            <small>
                <strong>
                    <x>
                        Data Reviewer
                        <!-- <a href="javascript:void(0);" data-toggle="modal" data-target="#rev" class="btn-sm bt-1 float-right mt-1" title="ADD"><i class="fa fa-user-plus mb-1"></i></a> -->
                    </x>
                </strong>
            </small>
        </div>
    </div>
    <?php foreach ($dt_rev as $o) : ?>
        <?php $y = db('users')->getWhere(['id' => $o->id_rev], 1)->getRow(); ?>
        <?php $x = db($y->level)->getWhere(['id' => $o->id_rev], 1)->getRow(); ?>
        <?php $foto = ($x->foto == null) ? $x->jk . '2.png' : $x->foto; ?>
        <?php
        $file = ($o->formulir_rev == '') ? 'BELUM ADA' : '<a href="' . XURL . 'file/pdf/' . $o->formulir_rev . '" target="_blank">Lihat <i class="fa fa-file-pdf text-danger ml-2"></i></a>';
        ?>
        <div class="row">
            <div class="col-2 my-2">
                <img src="<?= XROOT ?>img/avatar/<?= $foto ?>" width="100%">
            </div>
            <div class="col-8 my-2">
                <div class="row">
                    <div class="col-4">
                        NAMA
                    </div>
                    <div class="col-8">
                        : <?= $x->nama ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        NIP / NIDN
                    </div>
                    <div class="col-8">
                        : <?= $x->nip___nidn ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        STATUS
                    </div>
                    <div class="col-8">
                        : <?= $o->status_rev ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        FORMULIR
                    </div>
                    <div class="col-8">
                        : <?= $file ?>
                    </div>
                </div>
            </div>
        </div>

    <?php endforeach ?>
</div>