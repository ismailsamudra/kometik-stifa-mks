<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <h5>
                <a href="" style="color: <?= color('primary-b') ?>;">
                    <small>
                        <strong>
                            <i class="fa fa-id-badge mr-2"></i> <?= strtoupper('pengajuan menunggu') ?>
                        </strong>
                    </small>
                </a>
                <a href="javascript:void(0);" onclick="$('#dguser').datagrid('reload');" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
            </h5>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<input type="hidden" id="idx">
<div class="row m-2">
    <div class="col-md-9 mb-2 mt-2 table-responsive">
        <div class="row">

            <div class="col-12" id="fo1">
                <center>
                    <table id="dguser" toolbar="#toolbarCustomer" class="easyui-datagrid" singleSelect="true" style="width: 100%;height:500px;" fitColumns="true" rowNumbers="true" pagination="true" url="<?= XROOT ?>admin/get_pengajuan_1" pageSize="10" pageList="[10,25,50,75,100,125,150,200]">
                        <thead>
                            <tr>
                                <th field="pur_res" width="100%" formatter="show_res"></th>
                            </tr>
                        </thead>
                    </table>
                </center>
            </div>

        </div>

    </div>
    <div class="col-md-3 mb-2 mt-2 table-responsive">
        <div class="container">
            <div class="">
                <strong>
                    M-BOOK :
                </strong>
                <hr>
                Doubel Klick pada baris data Untuk Konfirmasi.
                <hr>
                Untuk Menu Lain Klick Kanan jika desktop dan sentuh tahan jika HP pada baris data.
                <hr>
            </div>
            <br>
            <br>
            <br>
        </div>
        <center>
            <i class="fa fa-id-badge fa-5x"></i><br>
            <strong>
                <?= strtoupper('pengajuan menunggu') ?>
            </strong><br>
        </center>
    </div>
</div>
<!-- BODY END -->
<div id="toolbarCustomer">
    <div class="row">
        <div class="col-md-6">
            <!---------SEARCH BOX START--------->
            <input id="searchCustomer" class="easyui-searchbox" data-options="prompt:'Cari.. Hanya berdasarkan ID pengajuan',searcher:doSearchCustomer,
            inputEvents: $.extend({}, $.fn.searchbox.defaults.inputEvents, {
                keyup: function(e){
                    var t = $(e.data.target);
                    var opts = t.searchbox('options');
                    t.searchbox('setValue', $(this).val());
                    opts.searcher.call(t[0],t.searchbox('getValue'),t.searchbox('getName'));
                }
            })
        " style="width:100%;"></input>
            <!---------SEARCH BOX END----------->
        </div>
    </div>
</div>
<!-- KLICK KANAN START -->
<div id="mm" class="easyui-menu">
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="biodata();"><i class="fa fa-user mr-2"></i>Biodata</a>
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="edit();"><i class="fa fa-sync mr-2"></i>Konfirmasi</a>
    <!-- <a href="javascript:void(0)" class="btn-sm form-control" plain="true" onClick="destroyuser();"><i class="fa fa-trash mr-2 text-danger"></i> Hapus</a> -->
</div>
<!-- KLICK KANAN END -->
<?php $xx = db('m_penelitian')->getWhere(['status' => 'true'])->getResult(); ?>
<?php $oo = db('m_keahlian')->getWhere(['status' => 'true'])->getResult(); ?>
<?php $rek = db('m_rekening')->getWhere(['status' => 'true'])->getResult(); ?>
<?php $uu = db(inc('level_regist'))->get()->getResult(); ?>
<?php foreach ($uu as $u) : ?>
    <input type="hidden" id="nama_<?= $u->id ?>" value="<?= $u->nama ?>">
    <input type="hidden" id="foto_<?= $u->id ?>" value="<?= $u->foto ?>">
    <input type="hidden" id="jk_<?= $u->id ?>" value="<?= $u->jk ?>">
<?php endforeach ?>
<?php foreach ($xx as $x) : ?>
    <input type="hidden" id="nama_<?= $x->id ?>" value="<?= $x->nama ?>">
<?php endforeach ?>
<?php foreach ($oo as $o) : ?>
    <input type="hidden" id="nama_<?= $o->id ?>" value="<?= $o->nama ?>">
    <input type="hidden" id="biaya_<?= $o->id ?>" value="<?= $o->harga ?>">
<?php endforeach ?>
<!-- Start Modal 1 -->
<div class="modal fade" id="edit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div id="head"></div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form id="fm" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="id" id="id">
                    <a href="javascript:void(0);" onclick="setujui();" class="btn btn-outline-success btn-block"><i class="far fa-thumbs-up mr-2"></i>Setujui</a>
                    <a href="javascript:void(0);" onclick="batalkan();" class="btn btn-outline-danger btn-block"><i class="far fa-thumbs-down mr-2"></i>Batalkan</a>
                </form>

            </div>
            <div class="modal-footer">

            </div>

        </div>
    </div>
</div>
<!-- End Modal 1-->
<!-- Start Modal 1 -->
<div class="modal fade" id="batal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div id="head1"></div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form id="fm2" method="post" enctype="multipart/form-data">
                    <label for=""><small>Alasan Di Batalkan [ Wajib ]</small></label>
                    <textarea name="ket" id="ket" cols="30" rows="6" class="form-control"></textarea>
                </form>

            </div>
            <div class="modal-footer">
                <a href="javascript:void(0);" onclick="kirim('batal');" class="btn btn-outline-dark btn-sm"><i class="fa fa-paper-plane mr-2"></i>Kirim</a>
            </div>

        </div>
    </div>
</div>
<!-- End Modal 1-->
<!-- Start Modal 1 -->
<div class="modal fade" id="setuju" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div id="head2"></div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form id="fm3" method="post" enctype="multipart/form-data">
                    <label for=""><small>NAMA PESERTA <u>
                                <div id="nama_p"></div>
                            </u></small></label><br>
                    <label for=""><small>JENIS PENELITIAN <u>
                                <div id="jenis"></div>
                            </u></small></label><br>
                    <label for=""><small>KEAHLIAN / SPESIALISASI <u>
                                <div id="keahlian"></div>
                            </u> </small></label><br>
                    <label for=""><small>NOMINAL BIAYA : <div id="biaya"></div></small></label><br>
                    <div class="row my-2">
                        <div class="col-md-4">
                            <label for=""><small>Metode Pembayaran</small></label>
                        </div>
                        <div class="col-md-4">
                            <input type="radio" name="metode" id="metode1" onchange="p_metode()" value="va"> Virtual Account
                        </div>
                        <div class="col-md-4">
                            <input type="radio" name="metode" id="metode2" onchange="p_metode()" value="bank"> Rek. Bank
                        </div>
                    </div>
                    <div id="va">
                        <label for=""><small>Input No VA [ Wajib ] </small></label>
                        <input type="text" id="no_va" name="no_va" class="form-control">
                    </div>
                    <div id="bank">
                        <label for=""><small>Pilih Rekening [ Wajib ] </small></label>
                        <select name="id_bank" id="id_bank" class="form-control">
                            <?php foreach ($rek as $r) : ?>
                                <option value="<?= $r->id ?>"><?= $r->nama ?> ~ <?= $r->no ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </form>

            </div>
            <div class="modal-footer">
                <a href="javascript:void(0);" onclick="kirim('setuju');" class="btn btn-outline-dark btn-sm"><i class="fa fa-paper-plane mr-2"></i>Kirim</a>
            </div>

        </div>
    </div>
</div>
<!-- End Modal 1-->
<!-- TOOLBAR END -->
<script type="text/javascript">
    //-----------------------------------------start
    function biodata() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            window.location = '<?= XROOT ?>biodata/' + row.id_user;
        } else {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'Data tidak di pilih'
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function doSearchCustomer() {
        $('#dguser').datagrid('load', {
            search_customer: $('#searchCustomer').val()
        });
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function edit() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $('#fm').form('load', row);
            document.getElementById("head").innerHTML = '<h5 class="modal-title"><i class="fa fa-sync mr-2"></i>Konfirmasi Data</h5>';
            $('#edit').modal('show');
        } else {
            msg('Error', 'nampaknya ada yg error');
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function p_metode() {
        if (document.getElementById("metode1").checked == true) {
            $("#bank").hide();
            $("#va").show();
        } else {
            $("#va").hide();
            $("#bank").show();
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function setujui() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $('#fm3').form('load', row);
            var jenis = document.getElementById("nama_" + row.id_penelitian).value;
            var keahlian = document.getElementById("nama_" + row.id_keahlian).value;
            var biaya = document.getElementById("biaya_" + row.id_keahlian).value;
            var nama_p = document.getElementById("nama_" + row.id_user).value;
            document.getElementById("jenis").innerHTML = jenis;
            document.getElementById("keahlian").innerHTML = keahlian;
            document.getElementById("biaya").innerHTML = 'Rp. ' + frp(biaya);
            document.getElementById("nama_p").innerHTML = nama_p;
            document.getElementById("metode1").checked = true;
            p_metode();
            document.getElementById("head2").innerHTML = '<h5 class="modal-title"><i class="fa fa-donate mr-2"></i>Setting Pembayaran</h5>';
            $('#setuju').modal('show');
        } else {
            msg('Error', 'nampaknya ada yg error');
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function batalkan() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $('#fm2').form('load', row);
            document.getElementById("head1").innerHTML = '<h5 class="modal-title"><i class="far fa-thumbs-down mr-2"></i>Batalkan</h5>';
            $('#batal').modal('show');
        } else {
            msg('Error', 'nampaknya ada yg error');
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function kirim(val) {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            if (val == 'batal') {
                var ket = document.getElementById("ket").value;
                if (ket == '') {
                    $.messager.show({ // show error message
                        title: 'Error',
                        msg: 'Alasan  Harus di isi.'
                    });
                    $('#ket').focus();
                    exit;
                }
                $.post("<?= XROOT ?>admin/batalkan_pengajuan", {
                    id: row.id,
                    hp: row.hp,
                    ket
                }, function(result) {
                    if (result.success) {
                        $('#dguser').datagrid('reload');
                        $('#edit').modal('hide');
                        $('#batal').modal('hide');
                        msg('Success !', 'Berhasil Di Batalkan');
                    } else {
                        msg('Error', result.errorMsg);
                    }
                }, 'json');
            } else {
                if (document.getElementById("metode1").checked == true) {
                    var no_va = document.getElementById("no_va").value;
                    if (no_va == '') {
                        $.messager.show({ // show error message
                            title: 'Error',
                            msg: 'No VA Harus di isi.'
                        });
                        $('#no_va').focus();
                        exit;
                    }
                    $.post("<?= XROOT ?>admin/set_va", {
                        id: row.id,
                        hp: row.hp,
                        rp: row.biaya,
                        no_va
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload');
                            $('#edit').modal('hide');
                            $('#setuju').modal('hide');
                            msg('Success !', 'Berhasil Di Kirim');
                        } else {
                            msg('Error', result.errorMsg);
                        }
                    }, 'json');
                } else {
                    var id_bank = document.getElementById("id_bank").value;
                    if (id_bank == '') {
                        $.messager.show({ // show error message
                            title: 'Error',
                            msg: 'Rek.Bank Harus di pilih.'
                        });
                        $('#id_bank').focus();
                        exit;
                    }
                    $.post("<?= XROOT ?>admin/set_bank", {
                        id: row.id,
                        hp: row.hp,
                        rp: row.biaya,
                        id_bank
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload');
                            $('#edit').modal('hide');
                            $('#setuju').modal('hide');
                            msg('Success !', 'Berhasil Di Kirim');
                        } else {
                            msg('Error', result.errorMsg);
                        }
                    }, 'json');
                }
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function show_res(val, row) {
        for (var name in row) {
            var nmp = document.getElementById("nama_" + row.id_penelitian).value;
            var nmk = document.getElementById("nama_" + row.id_keahlian).value;
            var bik = document.getElementById("biaya_" + row.id_keahlian).value;
            var nama = document.getElementById("nama_" + row.id_user).value;
            var foto = document.getElementById("foto_" + row.id_user).value;
            var jk = document.getElementById("jk_" + row.id_user).value;
            var sins = (row.instansi == 'LUAR') ? 'LUAR STIFA' : 'DALAM STIFA';
            if (foto == '') {
                var img = '<img src="<?= XROOT ?>img/avatar/' + jk + '2.png" class="rounded elevation-2 m-1" width="100%" alt="' + nama + '">';
            } else {
                var img = '<img src="<?= XROOT ?>img/avatar/' + foto + '" class="rounded elevation-2 m-1" width="100%" alt="' + nama + '">';
            }
            var t = `
            <div class="card col table-responsive my-1">
            <div class="row">
            
            <div class="col-md-2">
                    ` + img + `
                    </div>
                    <div class="col-md-9">

                        <div class="row mt-1">
                            <div class="col-md-4">
                            ID PENGAJUAN
                            </div>
                            <div class="col-md-8">
                            <strong class="sec-a"> : ` + row.id + `</strong>
                            </div>
                        </div>
                        <div class="row mt-1">
                            <div class="col-md-4">
                            NAMA PESERTA
                            </div>
                            <div class="col-md-8">
                            <strong>: ` + nama + `</strong>
                            </div>
                        </div>
                        <div class="row mt-1">
                            <div class="col-md-4">
                            NIM
                            </div>
                            <div class="col-md-8">
                            <strong>: ` + row.nim + `</strong>
                            </div>
                        </div>
                        <div class="row mt-1">
                            <div class="col-md-4">
                            STATUS INSTANSI 
                            </div>
                            <div class="col-md-8">
                            <strong>: ` + sins + `</strong>
                            </div>
                        </div>
                        <div class="row mt-1">
                            <div class="col-md-4">
                            NAMA INSTANSI
                            </div>
                            <div class="col-md-8">
                            <strong>: ` + row.asal + `</strong>
                            </div>
                        </div>
                        <div class="row mt-1">
                            <div class="col-md-4">
                            WAKTU PENELITIAN
                            </div>
                            <div class="col-md-8">
                            <strong>: ` + row.tgl_mulai + ` s/d ` + row.tgl_akhir + `</strong>
                            </div>
                        </div>
                        <div class="row mt-1">
                            <div class="col-md-4">
                            JENIS PENELITIAN
                            </div>
                            <div class="col-md-8">
                            <strong>: ` + nmp + `</strong>
                            </div>
                        </div>
                        <div class="row mt-1">
                            <div class="col-md-4">
                            KEAHLIAN / SPESIALISASI 
                            </div>
                            <div class="col-md-8">
                            <strong>: ` + nmk + `</strong>
                            </div>
                        </div>
                        <div class="row mt-1">
                            <div class="col-md-4">
                            BIAYA
                            </div>
                            <div class="col-md-8">
                            <strong>: Rp. ` + frp(bik) + `</strong>
                            </div>
                        </div>
                        <div class="row mt-1">
                            <div class="col-md-4">
                            BERKAS 
                            </div>
                            <div class="col-md-8">
                            <strong>: <a href="<?= XURL ?>file/pdf/` + row.berkas + `" target="_blank">Lihat <i class="fa fa-arrow-right"></i></a></strong>
                            </div>
                        </div>
                        <div class="row mt-1">
                            <div class="col-md-4">
                            TANGGAL PENGAJUAN 
                            </div>
                            <div class="col-md-8">
                            <strong>: ` + row.at_create + `</strong>
                            </div>
                        </div>
                        <div class="row mt-1">
                            <div class="col-md-4">
                            Status Pengajuan
                            </div>
                            <div class="col-md-8">
                            <strong>: ` + row.status + `</strong>
                            </div>
                        </div>
                        <div class="row my-1">
                            <div class="col-md-4">
                            Judul  Penelitian
                            </div>
                            <div class="col-md-8">
                            <textarea cols="30" rows="2" class="form-control" readonly>` + row.judul + `</textarea>
                            </div>
                        </div>
                    </div>
                
            </div>
            </div>
            `;
            if (row["pur_res"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function frp(angka, prefix) {
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split = number_string.split(','),
            sisa = split[0].length % 3,
            rupiah = split[0].substr(0, sisa),
            ribuan = split[0].substr(sisa).match(/\d{3}/gi);

        // tambahkan titik jika yang di input sudah menjadi angka ribuan
        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }

        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function destroyuser() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Menghapus data ini ?<br>ID: ' + row.id, function(r) {
                if (r) {
                    $.post("<?= XROOT ?>admin/del_pengajuan", {
                        id: row.id
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload');
                            msg('Success !', 'Berhasil Di Hapus');
                        } else {
                            msg('Error', result.errorMsg);
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    $(function() {
        $('#dguser').datagrid({
            singleSelect: true,
            onRowContextMenu: function(e, index, row) {
                $(this).datagrid('selectRow', index);
                e.preventDefault();
                $('#mm').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
            },
            onDblClickRow: function() {
                edit();
            }
        })

    })
    //-----------------------------------------end
    $('#no_va').on('keypress', function(event) {
        return (((event.which > 47) && (event.which < 58)) || (event.which == 13));
    });
</script>