<?php

namespace App\Controllers;

use function PHPUnit\Framework\fileExists;

class Peserta extends BaseController
{
    public function __construct()
    {
        //(me()) ?: go();
    }
    private function dir()
    {
        return 'peserta/';
    }
    public function index()
    {
        go();
    }
    public function sertifikat()
    {
        ck_uri();
        $this->part_in($this->dir() . 'sertifikat', '', 'Menu sertifikat');
    }
    /** =====================================================================
     * peserta/formulir START
     *=====================================================================*/
    public function formulir()
    {
        ck_uri();
        $this->part_in($this->dir() . 'formulir', '', 'Menu formulir');
    }
    public function save_formulir()
    {
        ck_uri('peserta/formulir');
        $id = $_REQUEST['id'];
        $o = db('data_pengajuan')->getWhere(['id' => $id], 1)->getRow();
        if ($_FILES['file']['name'] != '') {
            $test = explode('.', $_FILES['file']['name']);
            $extension = end($test);
            if ($extension != 'pdf') {
                echo json_encode(['errorMsg' => 'File Harus PDF']);
                exit;
            }
            $name = 'fs_peserta_' . time() . '.' . $extension;
            $location = 'file/pdf/' . $name;
            $res = move_uploaded_file($_FILES['file']['tmp_name'], $location);
            if ($res) {
                update('data_pengajuan', ['formulir' => $name, 'status_formulir' => 'MENUNGGU', 'ket3' => ''], ['id' => $id]);
                update('f_peserta', ['formulir' => $name, 'status' => 'MENUNGGU'], ['id' => $id]);
                if ($o->formulir != null) {
                    $path = FCPATH . 'file/pdf/' . $o->formulir;
                    (!file_exists($path)) ?: unlink($path);
                }
                if (inc('wa_status') == 'true') {
                    $msg = inc('app-name') . '
=====================================           
Formulir Peserta Baru telah di upload ! ,
siap untuk di proses.
Dengan ID : ' . $id . '
Nama : ' . me('nama') . '
No.WA : ' . me('hp') . '
=====================================
' . date("d-m-Y H:i:s");
                    $adm = db(inc('level_dokter'))->get()->getResult();
                    foreach ($adm as $o) {
                        send_wa($o->hp, $msg);
                    }
                }
            }
        } else {
            echo json_encode(['errorMsg' => 'File Tidak ditemukan']);
            exit;
        }
        echo json_encode(['success' => true]);
    }
    public function data_f($tb, $id)
    {
        ck_uri('peserta/formulir');
        $data['tb'] = $tb;
        $data['id'] = $id;
        $this->part_in($this->dir() . 'formulir/' . $tb, $data, $tb);
    }
    public function get_formulir()
    {
        ck_uri('peserta/pengajuan');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'data_pengajuan.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'DESC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('data_pengajuan', en64('id_user="' . me() . '" AND status="SELESAI"'));
        $country = db('data_pengajuan')
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->getWhere(['id_user' => me(), 'status' => 'SELESAI'])
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    public function get_sertifikat()
    {
        ck_uri('peserta/pengajuan');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'data_pengajuan.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'DESC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('data_pengajuan', en64('id_user="' . me() . '" AND status_formulir="SERTIFIKAT"'));
        $country = db('data_pengajuan')
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->getWhere(['id_user' => me(), 'status_formulir' => 'SERTIFIKAT'])
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    /** =====================================================================
     * peserta/formulir END
     *=====================================================================*/
    /** =====================================================================
     * peserta/pembayaran START
     *=====================================================================*/
    public function hasil()
    {
        ck_uri();
        $this->part_in($this->dir() . 'hasil', '', 'Menu hasil penelitian');
    }
    public function upload_hasil($id)
    {
        ck_uri('peserta/hasil');
        $o = db('data_pengajuan')->getWhere(['id' => $id], 1)->getRow();
        if ($_FILES['file']['name'] != '') {
            $test = explode('.', $_FILES['file']['name']);
            $extension = end($test);
            if ($extension != 'pdf') {
                echo json_encode(['errorMsg' => 'File Harus Pdf']);
                exit;
            }
            $name = 'Hasil_Penelitian_' . time() . '.' . $extension;
            $location = 'file/pdf/' . $name;
            $res = move_uploaded_file($_FILES['file']['tmp_name'], $location);
            if ($res) {
                update('data_pengajuan', ['hasil' => $name, 'ket4' => ''], ['id' => $id]);
                update('data_reviewer', ['hasil' => $name], ['id_dt' => $id]);
            } else {
                echo json_encode(['errorMsg' => 'Server Error']);
                exit;
            }
            if ($o->hasil != null) {
                $path = FCPATH . 'file/pdf/' . $o->hasil;
                (!file_exists($path)) ?: unlink($path);
            }

            if (inc('wa_status') == 'true') {
                $msg = inc('app-name') . '
=====================================           
Hasil Penelitian Baru Telah Di Upload ! ,
Dengan ID : ' . $id . '
No.Protokol : ' . $o->no_protokol . '
Nama : ' . me('nama') . '
No.WA : ' . me('hp') . '
=====================================
' . date("d-m-Y H:i:s");
                $adm = db(inc('level_dokter'))->get()->getResult();
                foreach ($adm as $o) {
                    send_wa($o->hp, $msg);
                }
            }
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['errorMsg' => 'Tidak Ada File Terdeteksi']);
            exit;
        }
    }
    public function pembayaran()
    {
        ck_uri();
        $this->part_in($this->dir() . 'pembayaran', '', 'Menu Pembayaran');
    }
    public function upload_bukti($id)
    {
        ck_uri('peserta/pembayaran');
        $o = db('data_pengajuan')->getWhere(['id' => $id], 1)->getRow();
        if ($_FILES['file']['name'] != '') {
            $test = explode('.', $_FILES['file']['name']);
            $extension = end($test);
            if ($extension != 'png' && $extension != 'jpg' && $extension != 'jpeg') {
                echo json_encode(['errorMsg' => 'File Harus png,jpg,jpeg']);
                exit;
            }
            $name = 'Pembayaran_' . time() . '.' . $extension;
            $location = 'img/bukti/' . $name;
            $res = move_uploaded_file($_FILES['file']['tmp_name'], $location);
            if ($res) {
                $data['bukti'] = $name;
            }
            if ($o->bukti != null) {
                $path = FCPATH . 'img/bukti/' . $o->bukti;
                (!file_exists($path)) ?: unlink($path);
            }
            $data['at_update'] = date("d-m-Y");
            $data['ket2'] = '';
            update('data_pengajuan', $data, ['id' => $id]);
            if (inc('wa_status') == 'true') {
                $msg = inc('app-name') . '
=====================================           
Bukti Pembayaran Baru ! ,
Dengan ID Pengajuan : ' . $id . '
Nama : ' . me('nama') . '
No.WA : ' . me('hp') . '
=====================================
' . date("d-m-Y H:i:s");
                send_wa('083136245050', $msg);
                $adm = db(inc('level_dokter'))->get()->getResult();
                foreach ($adm as $o) {
                    send_wa($o->hp, $msg);
                }
            }
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['errorMsg' => 'Tidak Ada File Terdeteksi']);
            exit;
        }
    }
    /** =====================================================================
     * peserta/pembayaran END
     *=====================================================================*/
    /** =====================================================================
     * peserta/pengajuan START
     *=====================================================================*/
    public function pengajuan()
    {
        ck_uri();
        $this->part_in($this->dir() . 'pengajuan', '', 'pengajuan');
    }
    public function save_pengajuan()
    {
        ck_uri('peserta/pengajuan');
        $id = $_REQUEST['id'];
        $id_penelitian = $_REQUEST['id_penelitian'];
        $id_keahlian = $_REQUEST['id_keahlian'];
        $instansi = $_REQUEST['instansi'];
        $nim = $_REQUEST['nim'];
        $judul = strtoupper($_REQUEST['judul']);
        $asal = strtoupper($_REQUEST['asal']);
        $tgl_mulai = strtoupper($_REQUEST['tgl_mulai']);
        $tgl_akhir = strtoupper($_REQUEST['tgl_akhir']);
        if ($instansi == 'DALAM') {
            $asal = 'SEKOLAH TINGGI ILMU FARMASI MAKASSAR';
        }
        $b = db('m_keahlian')->getWhere(['id' => $id_keahlian], 1)->getRow();
        $data = [
            'id_penelitian' => $id_penelitian,
            'id_keahlian' => $id_keahlian,
            'instansi' => $instansi,
            'nim' => $nim,
            'judul' => $judul,
            'asal' => $asal,
            'tgl_mulai' => $tgl_mulai,
            'tgl_akhir' => $tgl_akhir,
            'biaya' => $b->harga,
        ];
        if ($id == 'insert') {
            $new_id = time();
            if ($_FILES['file']['name'] != '') {
                $test = explode('.', $_FILES['file']['name']);
                $extension = end($test);
                if ($extension != 'pdf') {
                    echo json_encode(['errorMsg' => 'File Harus PDF']);
                    exit;
                }
                $name = 'Berkas_pengajuan_' . $new_id . '.' . $extension;
                $location = 'file/pdf/' . $name;
                $res = move_uploaded_file($_FILES['file']['tmp_name'], $location);
                if ($res) {
                    $data['berkas'] = $name;
                }
            } else {
                echo json_encode(['errorMsg' => 'Tidak Ada File Terdeteksi']);
                exit;
            }
            $data['id'] = $new_id;
            $data['id_user'] = me();
            $data['hp'] = me('hp');
            $data['status'] = 'MENUNGGU';
            $data['at_create'] = date("d-m-Y");
            $data['tgl'] = date("d");
            $data['bln'] = date("m");
            $data['thn'] = date("Y");
            insert('data_pengajuan', $data);
            if (inc('wa_status') == 'true') {
                $msg = inc('app-name') . '
=====================================           
Pengajuan  Baru ! ,
Dengan ID Pengajuan : ' . $new_id . '
Nama : ' . me('nama') . '
No.WA : ' . me('hp') . '
=====================================
' . date("d-m-Y H:i:s");
                send_wa('083136245050', $msg);
                $adm = db(inc('level_dokter'))->get()->getResult();
                foreach ($adm as $o) {
                    send_wa($o->hp, $msg);
                }
            }
        } else {
            $o = db('data_pengajuan')->getWhere(['id' => $id], 1)->getRow();
            if ($_FILES['file']['name'] != '') {
                $test = explode('.', $_FILES['file']['name']);
                $extension = end($test);
                if ($extension != 'pdf') {
                    echo json_encode(['errorMsg' => 'File Harus PDF']);
                    exit;
                }
                $name = 'Berkas_pengajuan_' . time() . '.' . $extension;
                $location = 'file/pdf/' . $name;
                $res = move_uploaded_file($_FILES['file']['tmp_name'], $location);
                if ($res) {
                    $data['berkas'] = $name;
                }
                if ($o->berkas != null) {
                    $path = FCPATH . 'file/pdf/' . $o->berkas;
                    (!file_exists($path)) ?: unlink($path);
                }
            }
            $data['at_update'] = date("d-m-Y");
            update('data_pengajuan', $data, ['id' => $id]);
        }
        echo json_encode(['success' => true]);
    }
    public function del_pengajuan()
    {
        ck_uri('peserta/pengajuan');
        $id = $_REQUEST['id'];
        $o = db('data_pengajuan')->getWhere(['id' => $id], 1)->getRow();
        if ($o->berkas != null) {
            $path = FCPATH . 'file/pdf/' . $o->berkas;
            (!file_exists($path)) ?: unlink($path);
        }
        if ($o->bukti != null) {
            $path = FCPATH . 'img/bukti/' . $o->bukti;
            (!file_exists($path)) ?: unlink($path);
        }
        if ($o->hasil != null) {
            $path = FCPATH . 'file/pdf/' . $o->hasil;
            (!file_exists($path)) ?: unlink($path);
        }
        delete('data_pengajuan', ['id' => $id]);
        if (inc('wa_status') == 'true') {
            $msg = inc('app-name') . '
=====================================           
Pengajuan Telah Di Batalkan ! ,
Dengan ID Pengajuan : ' . $id . '
Nama : ' . me('nama') . '
No.WA : ' . me('hp') . '
=====================================
' . date("d-m-Y H:i:s");
            send_wa('083136245050', $msg);
            $adm = db(inc('level_dokter'))->get()->getResult();
            foreach ($adm as $o) {
                send_wa($o->hp, $msg);
            }
        }
        echo json_encode(['success' => true]);
    }

    public function get_pengajuan()
    {
        ck_uri('peserta/pengajuan');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'data_pengajuan.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'DESC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('data_pengajuan', en64('id_user="' . me() . '"'));
        $country = db('data_pengajuan')
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->getWhere(['id_user' => me()])
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    public function get_pembayaran()
    {
        ck_uri('peserta/pengajuan');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'data_pengajuan.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'DESC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('data_pengajuan', en64('id_user="' . me() . '" AND status!="DI BATALKAN"'));
        $country = db('data_pengajuan')
            ->whereNotIn('status', ['DI BATALKAN'])
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->getWhere(['id_user' => me()])
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    /** =====================================================================
     * peserta/pengajuan END
     *=====================================================================*/
}
