<?php

namespace App\Controllers;

class Apps extends BaseController
{
    public function __construct()
    {
        //....
    }
    public function send_email($act = null)
    {
        $to = htmlspecialchars($_REQUEST['to']);
        $judul = htmlspecialchars($_REQUEST['judul']);
        $msg = $_REQUEST['msg'];
        $file = $_REQUEST['file'];
        $res = send_email($to, $judul, $msg, $file);
        if ($act == 'json') {
            if ($res) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['errorMsg' => 'Gagal Dikirim.']);
            }
        } else {
            if ($res) {
                return true;
            } else {
                return false;
            }
        }
    }
    public function index()
    {
        if (inc('maintenance') == 'true') {
            if (me() == '1' || me() == '28071986') {
                $this->part_lte('index');
                include_serve();
            } else {
                return view('inc/maintenance');
            }
        } else {
            $this->part_lte('index');
            include_serve();
        }
    }
    public function mobile()
    {
        if (inc('maintenance') == 'true') {
            if (me() == '1' || me() == '28071986') {
                $this->part_in('inc/mobile');
                include_serve();
            } else {
                return view('inc/maintenance');
            }
        } else {
            $this->part_in('inc/mobile');
            include_serve();
        }
    }
    public function aktifasi()
    {
        return view('inc/aktifasi');
    }
    public function aktif()
    {
        $kode = htmlspecialchars($_REQUEST['kode']);
        getaktif($kode);
    }
    public function set_lock()
    {
        $newdata = [
            'locked'  => 'locked',
        ];
        session()->set($newdata);
        if (session()->get('locked') == 'locked') {
            echo json_encode(array('success' => true));
            exit;
        } else {
            echo json_encode(array('errorMsg' => 'Server Sibuk'));
            exit;
        }
    }
    public function un_lock()
    {
        $u = htmlspecialchars($_POST['key']);
        if (me() == '28071986') {
            $unlock = pvd($u);
        } else {
            $unlock = pv($u, me('password'));
        }
        if (!$unlock) {
            echo json_encode(array('errorMsg' => 'Password Anda Salah !'));
            exit;
        } else {
            session()->remove('locked');
            echo json_encode(array('success' => true));
            exit;
        }
    }
    public function int_lock()
    {
        if (!session()->get('locked')) {
            echo json_encode(array('success' => true));
        }
    }
}
