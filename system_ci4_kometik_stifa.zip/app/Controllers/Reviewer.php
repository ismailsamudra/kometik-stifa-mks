<?php

namespace App\Controllers;

class Reviewer extends BaseController
{
    public function __construct()
    {
        //(me()) ?: go();
    }
    private function dir()
    {
        return 'reviewer/';
    }
    public function index()
    {
        go();
    }
    /** =====================================================================
     * reviewer/menunggu START
     *=====================================================================*/
    public function menunggu()
    {
        ck_uri();
        $this->part_in($this->dir() . 'menunggu', '', 'formulir peserta');
    }
    public function selesai()
    {
        ck_uri();
        $this->part_in($this->dir() . 'selesai', '', 'formulir peserta');
    }
    public function save_formulir()
    {
        ck_uri('reviewer/menunggu');
        $id = $_REQUEST['id'];
        $o = db('data_reviewer')->getWhere(['id' => $id], 1)->getRow();
        $y = db('data_pengajuan')->getWhere(['id' => $o->id_dt], 1)->getRow();
        $revs = $y->revs + 1;
        if ($_FILES['file']['name'] != '') {
            $test = explode('.', $_FILES['file']['name']);
            $extension = end($test);
            if ($extension != 'pdf') {
                echo json_encode(['errorMsg' => 'File Harus PDF']);
                exit;
            }
            $name = 'fs_reviewer_' . time() . '.' . $extension;
            $location = 'file/pdf/' . $name;
            $res = move_uploaded_file($_FILES['file']['tmp_name'], $location);
            if ($res) {
                update('data_reviewer', ['formulir_rev' => $name, 'status_rev' => 'SELESAI'], ['id' => $id]);
                update('data_pengajuan', ['revs' => $revs], ['id' => $o->id_dt]);
                update('data_reviewer', ['revs' => $revs], ['id_dt' => $o->id_dt]);
                if ($o->formulir_rev != null) {
                    $path = FCPATH . 'file/pdf/' . $o->formulir_rev;
                    (!file_exists($path)) ?: unlink($path);
                }
                if ($revs == $y->rev) {
                    update('data_reviewer', ['status_formulir' => 'BERKAS PENELITIAN'], ['id_dt' => $o->id_dt]);
                    update('data_pengajuan', ['status_formulir' => 'BERKAS PENELITIAN'], ['id' => $o->id_dt]);
                    if (inc('wa_status') == 'true') {
                        $msg = inc('app-name') . '
=====================================           
Semua Reviewer telah Mengupload formulir ! 
Dengan Jumlah Reviewer : ' . $y->rev . ' Orang
ID Data: ' . $o->id_dt . '
No.Protokol : ' . $o->no_protokol . '
Dengan Otomatis Sistem meminta 
Berkas Hasil Penelitian Ke Pada Peserta.
=====================================
' . date("d-m-Y H:i:s");
                        $msg_user = inc('app-name') . '
=====================================           
Formulir anda Telah selesai di Review,
Dengan Jumblah Reviewer : ' . $y->rev . ' Orang
ID Data: ' . $o->id_dt . '
Dengan No.Protokol : ' . $y->no_protokol . '
harap Mengupload Berkas Hasil Penelitian
dalam bentuk PDF Pada web atau app
di menu hasil penelitian.
Terimakasih!
=====================================
' . date("d-m-Y H:i:s");
                        $adm = db(inc('level_dokter'))->get()->getResult();
                        foreach ($adm as $x) {
                            send_wa($x->hp, $msg);
                        }
                        send_wa($o->hp, $msg_user);
                    }
                } else {
                    if (inc('wa_status') == 'true') {
                        $msg = inc('app-name') . '
=====================================           
Formulir Reviewer Baru telah di upload ! 
Dengan ID : ' . $o->id_dt . '
Nama Reviewer : ' . me('nama') . '
No.WA : ' . me('hp') . '
=====================================
' . date("d-m-Y H:i:s");
                        $adm = db(inc('level_dokter'))->get()->getResult();
                        foreach ($adm as $x) {
                            send_wa($x->hp, $msg);
                        }
                        send_wa($o->hp, $msg);
                    }
                }
            }
        } else {
            echo json_encode(['errorMsg' => 'File Tidak ditemukan']);
            exit;
        }
        echo json_encode(['success' => true]);
    }
    public function get_data($val)
    {
        ck_uri('reviewer/menunggu');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'data_reviewer.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'ASC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('data_reviewer', en64('status_rev="' . $val . '" AND id_rev="' . me() . '"'));
        $country = db('data_reviewer')
            ->like('id_dt', $search)
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->getWhere(['status_rev' => $val, 'id_rev' => me()])
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    /** =====================================================================
     * reviewer/menunggu END
     *=====================================================================*/
    /** =====================================================================
     * reviewer/selesai START
     *=====================================================================*/
    /** =====================================================================
     * reviewer/selesai END
     *=====================================================================*/
}
