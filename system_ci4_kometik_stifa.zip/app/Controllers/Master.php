<?php

namespace App\Controllers;

use function PHPUnit\Framework\fileExists;

class Master extends BaseController
{
    public function __construct()
    {
        //(me()) ?: go();
    }
    private function dir()
    {
        return 'master/';
    }
    public function index()
    {
        go();
    }

    /** =====================================================================
     * master/penelitian START
     *=====================================================================*/
    public function penelitian()
    {
        ck_uri();
        $this->part_in($this->dir() . 'penelitian', '', 'Setting penelitian');
    }
    public function save_pdf($num)
    {
        ck_uri('master/penelitian');
        $id = $_REQUEST['id' . $num];
        $dt = ($num == '1') ? 'peserta' : 'reviewer';
        $o = db('m_penelitian')->getWhere(['id' => $id], 1)->getRow();
        $db = ($num == '1') ? $o->pdf_peserta : $o->pdf_reviewer;
        if ($_FILES['file' . $num]['name'] != '') {
            $test = explode('.', $_FILES['file' . $num]['name']);
            $extension = end($test);
            if ($extension != 'pdf') {
                echo json_encode(['errorMsg' => 'File Harus PDF']);
                exit;
            }
            $name = 'f_' . $dt . '_' . time() . '.' . $extension;
            $location = 'file/pdf/' . $name;
            $res = move_uploaded_file($_FILES['file' . $num]['tmp_name'], $location);
            if ($res) {
                update('m_penelitian', ['pdf_' . $dt => $name], ['id' => $id]);
                if ($db != null) {
                    $path = FCPATH . 'file/pdf/' . $db;
                    (!file_exists($path)) ?: unlink($path);
                }
            }
        } else {
            echo json_encode(['errorMsg' => 'File Tidak ditemukan']);
            exit;
        }
        echo json_encode(['success' => true]);
    }
    public function save_penelitian()
    {
        ck_uri('master/penelitian');
        $id = $_REQUEST['id'];
        $nama = $_REQUEST['nama'];
        $alias_ind = $_REQUEST['alias_ind'];
        $alias_eng = $_REQUEST['alias_eng'];
        $status = $_REQUEST['status'];
        $kode = $_REQUEST['kode'];
        $data = [
            'nama' => $nama,
            'alias_ind' => $alias_ind,
            'alias_eng' => $alias_eng,
            'status' => $status,
            'kode' => $kode,
        ];
        if ($id == 'insert') {
            $tm = time();
            $data['id'] = api_key();
            $data['stamp'] = $tm;
            $data['tb'] = $tm;
            insert('m_penelitian', $data);
        } else {
            update('m_penelitian', $data, ['id' => $id]);
        }
        echo json_encode(['success' => true]);
    }
    public function del_penelitian()
    {
        ck_uri('master/penelitian');
        $id = $_REQUEST['id'];
        delete('m_penelitian', ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_penelitian()
    {
        ck_uri('master/penelitian');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'm_penelitian.stamp';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'ASC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('m_penelitian');
        $country = db('m_penelitian')
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->like('nama', $search)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    /** =====================================================================
     * master/penelitian END
     *=====================================================================*/
    /** =====================================================================
     * master/jenis START
     *=====================================================================*/
    public function jenis()
    {
        ck_uri();
        $this->part_in($this->dir() . 'jenis', '', 'Setting jenis');
    }
    public function save_jenis()
    {
        ck_uri('master/jenis');
        $id = $_REQUEST['id'];
        $nama = $_REQUEST['nama'];
        $kode = $_REQUEST['kode'];
        $status = $_REQUEST['status'];
        $data = [
            'nama' => $nama,
            'kode' => $kode,
            'status' => $status,
        ];
        if ($id == 'insert') {
            insert('m_jenis', $data);
        } else {
            update('m_jenis', $data, ['id' => $id]);
        }
        echo json_encode(['success' => true]);
    }
    public function del_jenis()
    {
        ck_uri('master/jenis');
        $id = $_REQUEST['id'];
        delete('m_jenis', ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_jenis()
    {
        ck_uri('master/jenis');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'm_jenis.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'ASC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('m_jenis');
        $country = db('m_jenis')
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->like('nama', $search)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    /** =====================================================================
     * master/jenis END
     *=====================================================================*/
    /** =====================================================================
     * master/rekening START
     *=====================================================================*/
    public function rekening()
    {
        ck_uri();
        $this->part_in($this->dir() . 'rekening', '', 'Setting rekening');
    }
    public function save_rekening()
    {
        ck_uri('master/rekening');
        $id = $_REQUEST['id'];
        $nama = $_REQUEST['nama'];
        $no = $_REQUEST['no'];
        $nama_bank = $_REQUEST['nama_bank'];
        $status = $_REQUEST['status'];
        $data = [
            'nama' => $nama,
            'no' => $no,
            'nama_bank' => $nama_bank,
            'status' => $status,
        ];
        if ($id == 'insert') {
            insert('m_rekening', $data);
        } else {
            update('m_rekening', $data, ['id' => $id]);
        }
        echo json_encode(['success' => true]);
    }
    public function del_rekening()
    {
        ck_uri('master/rekening');
        $id = $_REQUEST['id'];
        delete('m_rekening', ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_rekening()
    {
        ck_uri('master/rekening');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'm_rekening.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'ASC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('m_rekening');
        $country = db('m_rekening')
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->like('nama', $search)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    /** =====================================================================
     * master/rekening END
     *=====================================================================*/
    /** =====================================================================
     * master/keahlian START
     *=====================================================================*/
    public function keahlian()
    {
        ck_uri();
        $this->part_in($this->dir() . 'keahlian', '', 'Setting keahlian');
    }
    public function save_keahlian()
    {
        ck_uri('master/keahlian');
        $id = $_REQUEST['id'];
        $nama = $_REQUEST['nama'];
        $alias_ind = $_REQUEST['alias_ind'];
        $alias_eng = $_REQUEST['alias_eng'];
        $harga = $_REQUEST['harga'];
        $status = $_REQUEST['status'];
        $kode = $_REQUEST['kode'];
        $data = [
            'nama' => $nama,
            'alias_ind' => $alias_ind,
            'alias_eng' => $alias_eng,
            'harga' => $harga,
            'status' => $status,
            'kode' => $kode,
        ];
        if ($id == 'insert') {
            insert('m_keahlian', $data);
        } else {
            update('m_keahlian', $data, ['id' => $id]);
        }
        echo json_encode(['success' => true]);
    }
    public function del_keahlian()
    {
        ck_uri('master/keahlian');
        $id = $_REQUEST['id'];
        delete('m_keahlian', ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_keahlian()
    {
        ck_uri('master/keahlian');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'm_keahlian.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'ASC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('m_keahlian');
        $country = db('m_keahlian')
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->like('nama', $search)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    /** =====================================================================
     * master/keahlian END
     *=====================================================================*/
}
