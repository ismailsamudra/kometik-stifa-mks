<?php

namespace App\Controllers;

class Init extends BaseController
{
    public function __construct()
    {
        (me() == '28071986') ?: go();
    }
    private function dir()
    {
        return 'init/';
    }
    public function index()
    {
        go();
    }
    public function keygen()
    {
        $this->part_in($this->dir() . 'keygen', '', 'Keygen Engine');
    }
    public function g_key()
    {
        $dt = $_POST['dt'];
        $val = $_POST['val'];
        if ($dt == 'encode') {
            $res = enkey($val);
            echo json_encode(['success' => true, 'data' => $res]);
        } else {
            $res = dekey($val);
            echo json_encode(['success' => true, 'data' => $res]);
        }
    }
    public function generate()
    {
        $dt = $_POST['dt'];
        $val = $_POST['val'];
        if ($dt == 'api') {
            $res = api_key();
            echo json_encode(['success' => true, 'data' => $res]);
        }
        if ($dt == 'md5') {
            $res = md5($val);
            echo json_encode(['success' => true, 'data' => $res]);
        }
        if ($dt == 'has') {
            $res = ps($val);
            echo json_encode(['success' => true, 'data' => $res]);
        }
    }
    public function sidebar()
    {
        $this->part_in($this->dir() . 'sidebar', '', 'Sidebar Engine');
    }
    public function crud_sidebar()
    {
        $id = htmlspecialchars($_REQUEST['id']);
        $colum = htmlspecialchars($_REQUEST['colum']);
        $idx = htmlspecialchars($_REQUEST['idx']);
        $gp1 = htmlspecialchars($_REQUEST['gp1']);
        $role = htmlspecialchars($_REQUEST['role']);
        $col1 = htmlspecialchars($_REQUEST['col1']);
        $col2 = htmlspecialchars($_REQUEST['col2']);
        $col3 = htmlspecialchars($_REQUEST['col3']);
        $nama = htmlspecialchars($_REQUEST['nama']);
        $url = htmlspecialchars($_REQUEST['url']);
        $icon = htmlspecialchars($_REQUEST['icon']);
        $ket = htmlspecialchars($_REQUEST['ket']);
        ($role == '1') ?: $url = "#";
        if ($id == 'addsub') {
            exit;
        }
        if ($id == 'insert') {
            $id = time();
            if ($colum == '1') {
                $ckgrup = num_rows('temp_sidebar', en64("col1='" . $col1 . "'"));
                if ($ckgrup > 0) {
                    echo json_encode(array('errorMsg' => 'No. Sudah ada'));
                    exit;
                }
                if ($icon == null) {
                    $icon = 'far fa-circle';
                };
                $group_1 = '0000000000';
                $group_2 = '0000000000';
            }
            if ($colum == '2') {
                $ckgrup = num_rows('temp_sidebar', en64("col1='" . $col1 . "' AND col2='" . $col2 . "'"));
                if ($ckgrup > 0) {
                    echo json_encode(array('errorMsg' => 'No. Sudah ada'));
                    exit;
                }
                if ($icon == null) {
                    $icon = 'fa fa-adjust';
                };
                $group_1 = $idx;
                $group_2 = '0000000000';
            }
            if ($colum == '3') {
                $ckgrup = num_rows('temp_sidebar', en64("col1='" . $col1 . "' AND col2='" . $col2 . "' AND col3='" . $col3 . "'"));
                if ($ckgrup > 0) {
                    echo json_encode(array('errorMsg' => 'No. Sudah ada'));
                    exit;
                }
                if ($icon == null) {
                    $icon = 'fa fa-circle';
                };
                $group_1 = $idx;
                $group_2 = $gp1;
            }
            $data_1 = [
                'id' => $id,
                'group_1' => $group_1,
                'group_2' => $group_2,
                'colum' => $colum,
                'role' => $role,
                'col1' => $col1,
                'col2' => $col2,
                'col3' => $col3,
                'nama' => $nama,
                'url' => $url,
                'icon' => $icon,
                'ket' => $ket,
            ];
            insert('temp_sidebar', $data_1);
        } else {
            $o = one('temp_sidebar', $id);
            if ($o->colum == '1') {
                if ($o->col1 != $col1) {
                    $ckgrup = num_rows('temp_sidebar', en64("col1='" . $col1 . "'"));
                    if ($ckgrup > 0) {
                        echo json_encode(array('errorMsg' => 'No. Sudah ada'));
                        exit;
                    }
                    update('temp_sidebar', ['col1' => $col1], ['group_1' => $id]);
                    update('temp_sidebar', ['col1' => $col1], ['group_2' => $id]);
                }
            }
            if ($o->colum == '2') {
                if ($o->col2 != $col2) {
                    $ckgrup = num_rows('temp_sidebar', en64("col1='" . $col1 . "' AND col2='" . $col2 . "'"));
                    if ($ckgrup > 0) {
                        echo json_encode(array('errorMsg' => 'No. Sudah ada'));
                        exit;
                    }
                    update('temp_sidebar', ['col2' => $col2], ['group_1' => $id]);
                }
            }
            if ($o->colum == '3') {
                if ($o->col2 != $col2) {
                    $ckgrup = num_rows('temp_sidebar', en64("col1='" . $col1 . "' AND col2='" . $col2 . "' AND col3='" . $col3 . "'"));
                    if ($ckgrup > 0) {
                        echo json_encode(array('errorMsg' => 'No. Sudah ada'));
                        exit;
                    }
                }
            }
            $data_1 = [
                'role' => $role,
                'col1' => $col1,
                'col2' => $col2,
                'col3' => $col3,
                'nama' => $nama,
                'url' => $url,
                'icon' => $icon,
                'ket' => $ket,
            ];
            update('temp_sidebar', $data_1, ['id' => $id]);
        }
        echo json_encode(array('success' => true));
    }
    public function del_sidebar()
    {
        $id = htmlspecialchars($_REQUEST['id']);
        $o = one('temp_sidebar', $id);
        if ($o->inc == '1') {
            echo json_encode(array('errorMsg' => 'Bar ini Tidak boleh di hapus'));
            exit;
        }
        delete('temp_sidebar', ['id' => $id]);
        delete('temp_sidebar', ['group_1' => $id]);
        delete('temp_sidebar', ['group_2' => $id]);
        echo json_encode(array('success' => true));
    }
    public function e_sidebar()
    {
        $id = htmlspecialchars($_REQUEST['id']);
        $aks = htmlspecialchars($_REQUEST['aks']);
        $o = one('temp_sidebar', $id);
        ($o->$aks == '0') ? $val = '1' : $val = '0';
        update('temp_sidebar', [$aks => $val], ['id' => $id]);
        if ($val == '0') {
            update('temp_sidebar', [$aks => $val], ['group_1' => $id]);
            update('temp_sidebar', [$aks => $val], ['group_2' => $id]);
        }
        if ($val == '1') {
            if ($o->colum == '3') {
                update('temp_sidebar', [$aks => $val], ['id' => $o->group_1]);
                update('temp_sidebar', [$aks => $val], ['id' => $o->group_2]);
            }
            if ($o->colum == '2') {
                update('temp_sidebar', [$aks => $val], ['id' => $o->group_1]);
            }
        }

        echo json_encode(array('success' => true));
        exit;
    }
    public function crud_sch($db)
    {
        $tb = $db . '_schema';
        $id = htmlspecialchars($_REQUEST['id']);
        $group = htmlspecialchars($_REQUEST['group']);
        $label = htmlspecialchars($_REQUEST['label']);
        $type = htmlspecialchars($_REQUEST['type']);
        $row = htmlspecialchars($_REQUEST['row']);
        $sync = htmlspecialchars($_REQUEST['sync']);
        $status = htmlspecialchars($_REQUEST['status']);
        $style = htmlspecialchars($_REQUEST['style']);
        $class = htmlspecialchars($_REQUEST['class']);
        $script = $_POST['script'];
        if ($id == 'insert') {
            $id = strtolower(str_replace([" ", "-", "/", "|"], ["_", "_", "_", "_"], $label));
            $ck = num_rows($tb, en64('id="' . $id . '"'));
            if ($ck > 0) {
                echo json_encode(array('errorMsg' => 'Label Sudah ada.'));
                exit;
            }
            forge()->addColumn($db, [$id => ['type' => 'TEXT', 'null' => false]]);
            $data_1 = [
                'id' => $id,
                'group' => $group,
                'label' => $label,
                'type' => $type,
                'row' => $row,
                'sync' => $sync,
                'status' => $status,
                'style' => $style,
                'class' => $class,
                'script' => $script,
            ];
            insert($tb, $data_1);
        } else {
            $data_1 = [
                'group' => $group,
                'label' => $label,
                'type' => $type,
                'row' => $row,
                'sync' => $sync,
                'status' => $status,
                'style' => $style,
                'class' => $class,
                'script' => $script,
            ];
            update($tb, $data_1, ['id' => $id]);
        }
        echo json_encode(array('success' => true));
    }
    public function del_schema($db)
    {
        $tb = $db . '_schema';
        $id = htmlspecialchars($_REQUEST['id']);
        forge()->dropColumn($db, $id);
        delete($tb, ['id' => $id]);
        echo json_encode(array('success' => true));
    }
    public function get_schema($id, $group)
    {
        $tb = $id . '_schema';
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'row';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'asc';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows($tb, en64($tb . '.group="' . $group . '"'));
        $country = db($tb)
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->getWhere(['group' => $group])
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    public function get_sidebar()
    {
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'col1,col2,col3';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'asc';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('temp_sidebar');
        $country = db('temp_sidebar')
            ->like('nama', $search)
            ->orLike('url', $search)
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    public function engine()
    {
        $this->part_in($this->dir() . 'engine', '', 'User Engine');
    }
    public function crud_engine()
    {
        $id = htmlspecialchars($_REQUEST['id']);
        $grup = htmlspecialchars($_REQUEST['grup']);
        $no = htmlspecialchars($_REQUEST['no']);
        $level_name = htmlspecialchars($_REQUEST['level_name']);
        $level_name = str_replace(' ', '_', $level_name);
        $akses_name = htmlspecialchars($_REQUEST['akses_name']);
        $level_name = str_replace(' ', '_', $level_name);
        $level = 'users_' . an('6');
        $akses = 'a' . an('6');
        if ($id == 'addsub') {
            $level = htmlspecialchars($_REQUEST['level']);
            $data_1 = [
                'grup' => $grup,
                'no' => $no,
                'level_name' => strtoupper($level_name),
                'level' => $level,
                'akses_name' => strtoupper($akses_name),
                'akses' => $akses,
                'role' => 'SUB_AKSES',
            ];
            insert('engine', $data_1);
            forge()->addColumn('temp_sidebar', [$akses => ['type' => 'INT', 'constraint' => 1, 'null' => false]]);
            echo json_encode(array('success' => true));
            exit;
        }
        if ($id == 'insert') {
            $ckgrup = num_rows('engine', en64("grup='" . $grup . "'"));
            if ($ckgrup > 0) {
                echo json_encode(array('errorMsg' => 'Group Sudah ada'));
                exit;
            }
            $data_1 = [
                'grup' => $grup,
                'no' => $no,
                'level_name' => strtoupper($level_name),
                'akses_name' => strtoupper($akses_name),
                'level' => $level,
                'akses' => $akses,
            ];
            insert('engine', $data_1);
            forge()->addColumn('manual_book', [$level => ['type' => 'INT', 'constraint' => 1, 'null' => false]]);
            forge()->addColumn('temp_sidebar', [$akses => ['type' => 'INT', 'constraint' => 1, 'null' => false]]);
            $this->add_tb_users($level);
            $this->add_tb_schema($level . '_schema');
            $this->insert_schema($level . '_schema');
            $o = one('temp_sidebar', inc('usid'));
            $data_2 = [
                'id' => time(),
                'group_1' => $o->id,
                'group_2' => '0000000000',
                'colum' => '2',
                'inc' => '1',
                'role' => '1',
                'col1' => $o->col1,
                'col2' => '1',
                'col3' => '0',
                'nama' => strtoupper($level_name),
                'url' => 'users/table/' . $level,
                'icon' => 'fa fa-adjust',
                'ket' => 'KUSUS ADMIN',

            ];
            insert('temp_sidebar', $data_2);
        } else {
            $o = one('engine', $id);
            if ($o->grup != $grup) {
                $ckgrup = num_rows('engine', en64("grup='" . $grup . "'"));
                if ($ckgrup > 0) {
                    echo json_encode(array('errorMsg' => 'Group Sudah ada'));
                    exit;
                }
            }
            $data_1 = [
                'grup' => $grup,
                'no' => $no,
                'level_name' => strtoupper($level_name),
            ];
            if ($o->role == 'DEFAULT_AKSES') {
                update('engine', $data_1, ['grup' => $o->grup]);
                update('temp_sidebar', ['nama' => strtoupper($level_name)], ['url' => 'users/table/' . $o->level]);
            } else {
                update('engine', $data_1, ['id' => $id]);
            }
            $data_2 = [
                'akses_name' => strtoupper($akses_name),
            ];
            update('engine', $data_2, ['id' => $id]);
        }
        echo json_encode(array('success' => true));
    }
    public function delg_engine()
    {
        $id = htmlspecialchars($_REQUEST['id']);
        $grup = htmlspecialchars($_REQUEST['grup']);
        $o = one('engine', $id);
        $xx = db('engine')->getWhere(['grup' => $o->grup])->getResult();
        $ff = db('users')->getWhere(['level' => $o->level])->getResult();
        foreach ($xx as $x) {
            forge()->dropColumn('temp_sidebar', $x->akses);
        }
        forge()->dropColumn('manual_book', $o->level);
        forge()->dropTable($o->level, true);
        forge()->dropTable($o->level . '_schema', true);
        delete('temp_sidebar', ['url' => 'users/table/' . $o->level]);
        delete('users', ['level' => $o->level]);
        foreach ($ff as $f) {
            if ($f->foto != null) {
                $path = FCPATH . '/img/avatar/' . $f->foto;
                (!file_exists($path)) ?: unlink($path);
            }
        }
        delete('engine', ['grup' => $grup]);
        echo json_encode(array('success' => true));
    }
    public function del_engine()
    {
        $id = htmlspecialchars($_REQUEST['id']);
        $x = one('engine', $id);
        forge()->dropColumn('temp_sidebar', $x->akses);
        delete('engine', ['id' => $id]);
        echo json_encode(array('success' => true));
    }
    public function get_engine()
    {
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'grup,no';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'asc';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('engine');
        $country = db('engine')
            ->like('level', $search)
            ->orLike('akses', $search)
            ->orLike('level_name', $search)
            ->orLike('akses_name', $search)
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    // FORGE START
    private function add_tb_users($name)
    {
        $fields = [
            'id' => array(
                'type' => 'VARCHAR',
                'constraint' => 100,
            ),
            'sort' => array(
                'type' => 'VARCHAR',
                'constraint' => 100,
            ),
            'status' => array(
                'type' => 'VARCHAR',
                'constraint' => 100,
            ),
            'akses' => array(
                'type' => 'VARCHAR',
                'constraint' => 100,
            ),
            'foto' => array(
                'type' => 'TEXT'
            ),
            'android' => array(
                'type' => 'VARCHAR',
                'constraint' => 200,
            ),
            'ios' => array(
                'type' => 'VARCHAR',
                'constraint' => 200,
            ),
            'last_login' => array(
                'type' => 'VARCHAR',
                'constraint' => 100,
            ),
            'nama' => array(
                'type' => 'VARCHAR',
                'constraint' => 100,
            ),
            'email' => array(
                'type' => 'VARCHAR',
                'constraint' => 100,
            ),
            'hp' => array(
                'type' => 'VARCHAR',
                'constraint' => 20,
            ),
            'jk' => array(
                'type' => 'VARCHAR',
                'constraint' => 1,
            ),
        ];
        forge()->addKey('id', true)->addField($fields)->createTable($name);
    }
    private function add_tb_schema($name)
    {
        $fields = [
            'id' => array(
                'type' => 'VARCHAR',
                'constraint' => 100,
            ),
            'label' => array(
                'type' => 'VARCHAR',
                'constraint' => 100,
            ),
            'type' => array(
                'type' => 'VARCHAR',
                'constraint' => 20,
            ),
            'row' => array(
                'type' => 'INT',
                'constraint' => 13,
            ),
            'group' => array(
                'type' => 'INT',
                'constraint' => 13,
            ),
            'sync' => array(
                'type' => 'VARCHAR',
                'constraint' => 20,
            ),
            'script' => array(
                'type' => 'TEXT',
            ),
            'class' => array(
                'type' => 'TEXT',
            ),
            'style' => array(
                'type' => 'TEXT',
            ),
            'status' => array(
                'type' => 'VARCHAR',
                'constraint' => 20,
            ),
            'r' => array(
                'type' => 'INT',
                'constraint' => 1,
            ),
        ];
        forge()->addKey('id', true)->addField($fields)->createTable($name);
    }
    private function insert_schema($db)
    {
        $dt0 = [
            'id' => 'akses',
            'label' => 'Akses*',
            'type' => 'select',
            'script' => 'akses',
            'row' => '0',
            'group' => '1',
            'sync' => 'required',
            'class' => 'card',
            'status' => 'true',
            'r' => '1',
        ];
        insert($db, $dt0);
        $dt1 = [
            'id' => 'nama',
            'label' => 'Nama',
            'type' => 'text',
            'row' => '1',
            'group' => '1',
            'sync' => 'required',
            'class' => 'form-control',
            'status' => 'true',
            'r' => '1',
        ];
        insert($db, $dt1);
        $dt2 = [
            'id' => 'email',
            'label' => 'Email',
            'type' => 'email',
            'row' => '2',
            'group' => '1',
            'sync' => 'required',
            'class' => 'form-control',
            'status' => 'true',
            'r' => '1',
        ];
        insert($db, $dt2);
        $dt3 = [
            'id' => 'hp',
            'label' => 'No Hp/Wa',
            'type' => 'text',
            'row' => '3',
            'group' => '1',
            'sync' => 'required',
            'class' => 'form-control',
            'status' => 'true',
            'r' => '1',
        ];
        insert($db, $dt3);
        $jks = '<div class="card mb-2">
<div class="row col">
<div class="col-md-6">
<input type="radio" name="jk" id="jk1" class="mr-2" value="L">Laki-Laki
</div>
<div class="col-md-6">
<input type="radio" name="jk" id="jk2" class="mr-2" value="P">Perempuan
</div>
</div>
</div>
';
        $dt4 = [
            'id' => 'jk',
            'label' => 'Jenis Kelamin',
            'type' => 'script',
            'script' => $jks,
            'row' => '20',
            'group' => '2',
            'sync' => 'required',
            'class' => 'form-control',
            'status' => 'true',
            'r' => '1',
        ];
        insert($db, $dt4);
    }
    // FORGE END
}
