<?php

namespace App\Controllers;

use function PHPUnit\Framework\fileExists;

class Inc extends BaseController
{
    public function __construct()
    {
        (me() == '28071986' || me() == '1') ?: go();
    }
    private function dir()
    {
        return 'inc/';
    }
    public function index()
    {
        go();
    }
    public function m_book()
    {
        $this->part_in($this->dir() . 'm_book', '', 'Manual Book');
    }
    public function check_m_book()
    {
        $id = htmlspecialchars($_REQUEST['id']);
        $row = htmlspecialchars($_REQUEST['row']);
        $o = db('manual_book')->getWhere(['id' => $id], 1)->getRow();
        $val = ($o->$row == '0') ? '1' : '0';
        update('manual_book', [$row => $val], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function crud_m_book()
    {
        $db = 'manual_book';
        $res = false;
        $id = htmlspecialchars($_REQUEST['id']);
        $role = htmlspecialchars($_REQUEST['role']);
        $judul = htmlspecialchars($_REQUEST['judul']);
        $text = $_REQUEST['text'];
        $data_in = [
            'role' => $role,
            'judul' => $judul,
            'text' => $text,
        ];
        if ($id == 'insert') {
            if ($role == 'PDF') {
                if ($_FILES['file']['name'] != '') {
                    $test = explode('.', $_FILES['file']['name']);
                    $extension = end($test);
                    if ($extension != 'pdf') {
                        echo json_encode(['errorMsg' => 'Gagal Di Save Extensi Salah. ONLY PDF']);
                        exit;
                    }
                    $name = $db . '_' . time() . '.' . $extension;
                    $location = FCPATH . '/file/pdf/' . $name;
                    $res = move_uploaded_file($_FILES['file']['tmp_name'], $location);
                    $data_in['file'] = ($res) ? $name : '';
                }
            }
            insert($db, $data_in);
        } else {
            if ($role == 'PDF') {
                if ($_FILES['file']['name'] != '') {
                    $test = explode('.', $_FILES['file']['name']);
                    $extension = end($test);
                    if ($extension != 'pdf') {
                        echo json_encode(['errorMsg' => 'Gagal Di Save Extensi Salah. ONLY PDF']);
                        exit;
                    }
                    $name = $db . '_' . time() . '.' . $extension;
                    $location = FCPATH . '/file/pdf/' . $name;
                    $o = db($db)->getWhere(['id' => $id], 1)->getRow();
                    if ($o->file != null) {
                        $path = FCPATH . '/file/pdf/' . $o->file;
                        (!fileExists($path)) ?: unlink($path);
                    }
                    $res = move_uploaded_file($_FILES['file']['tmp_name'], $location);
                    $data_in['file'] = ($res) ? $name : '';
                }
            }
            update($db, $data_in, ['id' => $id]);
        }
        echo json_encode(['success' => true, 'id' => $id, 'file' => $data_in['file']]);
    }
    public function del_m_book()
    {
        $db = 'manual_book';
        $id = htmlspecialchars($_REQUEST['id']);
        $o = db($db)->getWhere(['id' => $id], 1)->getRow();
        if ($o->file != null) {
            $path = FCPATH . '/file/pdf/' . $o->file;
            (!fileExists($path)) ?: unlink($path);
        }
        delete($db, ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function get_m_book()
    {
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'manual_book.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'DESC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('manual_book');
        $country = db('manual_book')
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->like('judul', $search)
            ->orLike('id', $search)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    public function smtp_email()
    {
        $this->part_in($this->dir() . 'smtp_email', '', 'Smtp Email Setting');
    }
    public function control()
    {
        $this->part_in($this->dir() . 'control', '', 'control Engine');
    }
    public function status()
    {
        $id = htmlspecialchars($_REQUEST['id']);
        $act = htmlspecialchars($_REQUEST['act']);
        if ($act == null) {
            $val = inc($id);
            $in = ($val == 'false') ? 'true' : 'false';
            update('temp_inc', ['code' => $in], ['id' => $id]);
            echo json_encode(['success' => true]);
            exit;
        } else {
            $val = inc($id);
            update('temp_inc', ['code' => $act], ['id' => $id]);
            echo json_encode(['success' => true]);
            exit;
        }
    }
    public function save_text()
    {
        $id = htmlspecialchars($_REQUEST['id']);
        $val = $_REQUEST['val'];
        if ($id == 'email_pass') {
            update('temp_inc', ['code' => enkey($val)], ['id' => $id]);
        } else if ($id == 'wa_callback') {
            $res = send_wa_callback($val);
            if ($res == 200) {
                update('temp_inc', ['code' => $val], ['id' => $id]);
                echo json_encode(['success' => true]);
                exit;
            } else {
                echo json_encode(['errorMsg' => 'Gagal Di Update']);
                exit;
            }
        } else {
            update('temp_inc', ['code' => $val], ['id' => $id]);
        }
        echo json_encode(['success' => true]);
    }
    public function status2()
    {
        $id = htmlspecialchars($_REQUEST['id']);
        $act = htmlspecialchars($_REQUEST['act']);
        if ($act == 'level') {
            update('temp_inc', ['code' => $id], ['id' => 'level_regist']);
            echo json_encode(['success' => true]);
            exit;
        }
        if ($act == null) {
            $val = inc($id);
            $in = ($val == 'false') ? 'true' : 'false';
            update('temp_inc', ['code' => $in], ['id' => $id]);
            echo json_encode(['success' => true]);
            exit;
        }
    }
    public function save_text2()
    {
        $id = htmlspecialchars($_REQUEST['id']);
        $val = $_REQUEST['val'];
        update('temp_inc', ['code' => $val], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function color()
    {
        $this->part_in($this->dir() . 'color', '', 'Color Setting');
    }
    public function save_color()
    {
        $id = htmlspecialchars($_REQUEST['id']);
        $warna = htmlspecialchars($_REQUEST['warna']);
        update('temp_color', ['code' => $warna], ['id' => $id]);
        echo json_encode(['success' => true]);
    }
    public function apps()
    {
        if (req()->getPost('app_name') != null) {
            $app_name = req()->getPost('app_name');
            $app_name2 = req()->getPost('app_name2');
            $nama_instansi = req()->getPost('nama_instansi');
            $email = req()->getPost('email');
            $telp = req()->getPost('telp');
            $hp = req()->getPost('hp');
            $slogan = req()->getPost('slogan');
            $alamat = req()->getPost('alamat');
            $desk = req()->getPost('desk');
            update('temp_inc', ['code' => $app_name], ['id' => 'app-name']);
            update('temp_inc', ['code' => $app_name2], ['id' => 'app-name-2']);
            update('temp_inc', ['code' => $nama_instansi], ['id' => 'nama-instansi']);
            update('temp_inc', ['code' => $email], ['id' => 'email']);
            update('temp_inc', ['code' => $telp], ['id' => 'telp']);
            update('temp_inc', ['code' => $hp], ['id' => 'hp']);
            update('temp_inc', ['code' => $slogan], ['id' => 'slogan']);
            update('temp_inc', ['code' => $alamat], ['id' => 'alamat']);
            update('temp_inc', ['code' => $desk], ['id' => 'desk-app']);
            session()->setFlashdata('info', 'Data Berhasil Di Update');
        }
        if (req()->getPost('desk2') != null) {
            $desk = req()->getPost('desk2');
            update('temp_inc', ['code' => $desk], ['id' => 'desk-login']);
            session()->setFlashdata('info', 'Data Berhasil Di Update');
        }
        $this->part_in($this->dir() . 'apps', '', 'Aplication Setting');
    }
    public function android()
    {
        if (req()->getPost('playstore_url') != null) {
            $playstore_url = req()->getPost('playstore_url');
            $sdk_name = req()->getPost('sdk_name');
            $sdk_id = req()->getPost('sdk_id');
            $sdk_key = req()->getPost('sdk_key');
            $desk = req()->getPost('desk');
            update('temp_inc', ['code' => $playstore_url], ['id' => 'playstore-url']);
            update('temp_inc', ['code' => $sdk_name], ['id' => 'sdk-name']);
            update('temp_inc', ['code' => $sdk_id], ['id' => 'sdk-id']);
            update('temp_inc', ['code' => $sdk_key], ['id' => 'sdk-key']);
            update('temp_inc', ['code' => $desk], ['id' => 'playstore-desk']);
            session()->setFlashdata('info', 'Data Berhasil Di Update');
        }
        $this->part_in($this->dir() . 'android', '', 'Android Setting');
    }
    public function play_s()
    {
        $status = inc('playstore-status');
        $in = ($status == 'false') ? 'true' : 'false';
        update('temp_inc', ['code' => $in], ['id' => 'playstore-status']);
        echo json_encode(['success' => true]);
    }
    public function upload_logo($id)
    {
        if ($_FILES['file']['name'] != '') {
            $test = explode('.', $_FILES['file']['name']);
            $extension = end($test);
            $name = $id . '_' . time() . '.' . $extension;

            $logo = inc($id);
            $location = 'img/instansi/' . $name;

            $res = move_uploaded_file($_FILES['file']['tmp_name'], $location);
            if ($res) {
                if ($logo) {
                    $path = FCPATH . 'img/instansi/' . $logo;
                    (!file_exists($path)) ?: unlink($path);
                }
                update('temp_inc', ['code' => $name], ['id' => $id]);
                echo '<img src="' . XURL . $location . '" width="100%" />';
            }
        }
    }
    public function upload_dev($id)
    {
        if ($_FILES['file']['name'] != '') {
            $test = explode('.', $_FILES['file']['name']);
            $extension = end($test);
            $name = $id . '_' . time() . '.' . $extension;

            $logo = inc($id);
            $location = 'img/dev/' . $name;

            $res = move_uploaded_file($_FILES['file']['tmp_name'], $location);
            if ($res) {
                if ($logo) {
                    $path = FCPATH . 'img/dev/' . $logo;
                    (!file_exists($path)) ?: unlink($path);
                }
                update('temp_inc', ['code' => $name], ['id' => $id]);
                echo '<img src="' . XURL . $location . '" width="30%" />';
            }
        }
    }
}
