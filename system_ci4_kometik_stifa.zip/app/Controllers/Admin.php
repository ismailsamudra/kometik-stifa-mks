<?php

namespace App\Controllers;

use function PHPUnit\Framework\fileExists;

class Admin extends BaseController
{
    public function __construct()
    {
        //(me()) ?: go();
    }
    private function dir()
    {
        return 'admin/';
    }
    public function index()
    {
        go();
    }

    /** =====================================================================
     * admin/formulir START
     *=====================================================================*/
    public function sertifikat()
    {
        ck_uri();
        $this->part_in($this->dir() . 'sertifikat', '', 'sertifikat peserta');
    }
    public function formulir1()
    {
        ck_uri();
        $this->part_in($this->dir() . 'formulir1', '', 'formulir peserta');
    }
    public function formulir2()
    {
        ck_uri();
        $this->part_in($this->dir() . 'formulir2', '', 'formulir peserta');
    }
    public function formulir3()
    {
        ck_uri();
        $this->part_in($this->dir() . 'formulir3', '', 'formulir peserta');
    }
    public function formulir4()
    {
        ck_uri();
        $this->part_in($this->dir() . 'formulir4', '', 'formulir peserta');
    }
    public function rilis()
    {
        ck_uri('admin/formulir3');
        $id = $_REQUEST['id'];
        $hp = $_REQUEST['hp'];
        $tgl_a = $_REQUEST['tgl_a'];
        $tgl_b = $_REQUEST['tgl_b'];
        $o = db('data_pengajuan')->getWhere(['id' => $id], 1)->getRow();
        if ($o->hasil == null) {
            echo json_encode(['errorMsg' => 'Sertifikat tidak dapat di rilis jika berkas hasil penelitian belum di upload peserta.']);
            exit;
        }
        $k1 = db('m_penelitian')->getWhere(['id' => $o->id_penelitian], 1)->getRow()->kode;
        $k2 = db('m_keahlian')->getWhere(['id' => $o->id_keahlian], 1)->getRow()->kode;
        $k3 = db('m_jenis')->getWhere(['id' => $o->jenis_doc], 1)->getRow()->kode;
        $no_urut = inc('no_urut_ec') + 1;
        if (strlen($no_urut) == 1) {
            $no_urut = '00' . $no_urut;
        }
        if (strlen($no_urut) == 2) {
            $no_urut = '0' . $no_urut;
        }
        $no_ec = $no_urut . '/EC.' . $k1 . '.' . $k2 . '.' . $k3 . '/KEPK/' . date('Y');
        update('temp_inc', ['code' => $no_urut], ['id' => 'no_urut_ec']);
        update('data_pengajuan', ['no_ec' => $no_ec, 'status_formulir' => 'SERTIFIKAT', 'tgl_a' => $tgl_a, 'tgl_b' => $tgl_b], ['id' => $id]);
        update('data_reviewer', ['no_ec' => $no_ec, 'status_formulir' => 'SERTIFIKAT', 'tgl_a' => $tgl_a, 'tgl_b' => $tgl_b], ['id_dt' => $id]);
        if (inc('wa_status') == 'true') {
            $msg = inc('app-name') . '
=====================================           
Selamat ! Sertifikat Anda telah rilis,
Silahkan menuju web atau app Untuk mencetak
Sertifikat anda.

NO Etik Approval :
' . $no_ec . '
NO Protokol :
' . $o->no_protokol . '
=====================================
' . date("d-m-Y H:i:s");
            send_wa($hp, $msg);
        }
        echo json_encode(['success' => true]);
    }
    public function reupload_hasil()
    {
        ck_uri('admin/formulir3');
        $id = $_REQUEST['id'];
        $ket4 = $_REQUEST['ket'];
        $hp = $_REQUEST['hp'];
        $o = db('data_pengajuan')->getWhere(['id' => $id], 1)->getRow();
        if ($o->hasil != null) {
            $path = FCPATH . 'file/pdf/' . $o->hasil;
            (!file_exists($path)) ?: unlink($path);
        }
        update('data_pengajuan', ['ket4' => $ket4, 'hasil' => '', 'id_admin' => me(), 'at_update' => date("d-m-Y H:i:s")], ['id' => $id]);
        if (inc('wa_status') == 'true') {
            $msg = inc('app-name') . '
=====================================           
Maaf ! Admin meminta anda untuk mengupload ulang 
Berkas hasil Penelitian,
Dengan Alasan :

' . $ket4 . '

=====================================
' . date("d-m-Y H:i:s");
            send_wa($hp, $msg);
        }
        echo json_encode(['success' => true]);
    }
    public function reviewer($id)
    {
        ck_uri('admin/formulir1');
        $data['id_dt'] = $id;
        $data['dt_rev'] = db('data_reviewer')->getWhere(['id_dt' => $id])->getResult();
        $this->part_in($this->dir() . 'reviewer', $data, 'reviewer');
    }
    public function reviewer2($id)
    {
        $data['id_dt'] = $id;
        $data['dt_rev'] = db('data_reviewer')->getWhere(['id_dt' => $id])->getResult();
        $this->part_in($this->dir() . 'reviewer2', $data, 'reviewer');
    }
    public function del_rev()
    {
        $id = $_REQUEST['id'];
        $x = db('data_reviewer')->getWhere(['id' => $id], 1)->getRow();
        $o = db('data_pengajuan')->getWhere(['id' => $x->id_dt], 1)->getRow();
        $rev = $o->rev - 1;
        delete('data_reviewer', ['id' => $id]);
        update('data_pengajuan', ['rev' => $rev], ['id' => $x->id_dt]);
        update('data_reviewer', ['rev' => $rev], ['id_dt' => $x->id_dt]);
        echo json_encode(['success' => true]);
    }
    public function save_rev()
    {
        $id_dt = $_REQUEST['id_dt'];
        $id_rev = $_REQUEST['id_rev'];
        $o = db('data_pengajuan')->getWhere(['id' => $id_dt], 1)->getRow();
        $rev = $o->rev + 1;
        $u = db('users')->getWhere(['id' => $id_rev], 1)->getRow();
        $cek = num_rows('data_reviewer', en64('id_dt="' . $id_dt . '" AND id_rev="' . $id_rev . '"'));
        if ($cek > 0) {
            echo json_encode(['errorMsg' => 'Reviewer sudah  terdaftar']);
            exit;
        }
        $data = [
            'id_dt' => $id_dt,
            'id_rev' => $id_rev,
            'id_admin' => me(),
            'hp_rev' => $u->hp,
            'id_user' => $o->id_user,
            'hp' => $o->hp,
            'id_penelitian' => $o->id_penelitian,
            'id_keahlian' => $o->id_keahlian,
            'nim' => $o->nim,
            'judul' => $o->judul,
            'asal' => $o->asal,
            'tgl_mulai' => $o->tgl_mulai,
            'tgl_akhir' => $o->tgl_akhir,
            'berkas' => $o->berkas,
            'formulir' => $o->formulir,
            'instansi' => $o->instansi,
            'no_protokol' => $o->no_protokol,
            'at_create' => $o->at_create,
            'status' => $o->status,
            'status_formulir' => $o->status_formulir,
            'status_rev' => 'BARU',
        ];
        insert('data_reviewer', $data);
        update('data_pengajuan', ['rev' => $rev], ['id' => $id_dt]);
        update('data_reviewer', ['rev' => $rev], ['id_dt' => $id_dt]);
        echo json_encode(['success' => true]);
    }
    public function kirim_rev()
    {
        ck_uri('admin/formulir1');
        $id = $_REQUEST['id'];
        $hp = $_REQUEST['hp'];
        $jenis_doc = $_REQUEST['jenis_doc'];
        $oo = db('data_reviewer')->getWhere(['id_dt' => $id], 1)->getResult();
        $cek = num_rows('data_reviewer', en64('id_dt="' . $id . '"'));
        if ($cek < 1) {
            echo json_encode(['errorMsg' => 'Reviewer Belum Ada.']);
            exit;
        }
        $data_s = [
            'at_update' => date('d-m-Y H:i:s'),
            'status_formulir' => 'DI REVIEW',
            'status_rev' => 'MENUNGGU',
            'jenis_doc' => $jenis_doc,
            'id_admin' => me()
        ];
        update('data_pengajuan', $data_s, ['id' => $id]);
        update('f_peserta', $data_s, ['id' => $id]);
        update('data_reviewer', $data_s, ['id_dt' => $id]);
        $u = db('users')->getWhere(['hp' => $hp], 1)->getRow();
        $y = db('data_pengajuan')->getWhere(['id' => $id], 1)->getRow();
        $msg = inc('app-name') . '
=====================================           
Formulir Peserta Baru telah Siap
Di review oleh anda.
Dengan ID : ' . $id . '
No.Protokol : ' . $y->no_protokol . '
Nama Peserta : ' . $u->nama . '
No.WA : ' .  $hp . '
=====================================
' . date("d-m-Y H:i:s");
        $msg_user = inc('app-name') . '
=====================================           
Hi, ' . $u->nama . ',
Formulir anda Sedang di review,
Dengan No.Protokol : ' . $y->no_protokol . '
Jumblah Reviewer : ' . $y->rev . ' Orang
harap menunggu sampai tahap review selesai 
Terimakasih!
=====================================
' . date("d-m-Y H:i:s");
        if (inc('wa_status') == 'true') {
            foreach ($oo as $o) {
                $x = db('users')->getWhere(['id' => $o->id_rev], 1)->getRow();
                send_wa($x->hp, $msg);
            }
            send_wa($hp, $msg_user);
        }
        echo json_encode(['success' => true]);
    }
    public function reupload_formulir()
    {
        ck_uri('admin/formulir1');
        $id = $_REQUEST['id'];
        $ket3 = $_REQUEST['ket'];
        $hp = $_REQUEST['hp'];
        $o = db('data_pengajuan')->getWhere(['id' => $id], 1)->getRow();
        if ($o->formulir != null) {
            $path = FCPATH . 'file/pdf/' . $o->formulir;
            (!file_exists($path)) ?: unlink($path);
        }
        update('data_pengajuan', ['ket3' => $ket3, 'formulir' => '', 'id_admin' => me(), 'status_formulir' => 'RILIS', 'at_update' => date("d-m-Y H:i:s")], ['id' => $id]);
        update('f_peserta', ['formulir' => '', 'status' => 'RILIS'], ['id' => $id]);
        if (inc('wa_status') == 'true') {
            $msg = inc('app-name') . '
=====================================           
Maaf ! Admin meminta anda untuk mengupload ulang Formulir,
Dengan Alasan :

' . $ket3 . '

=====================================
' . date("d-m-Y H:i:s");
            send_wa($hp, $msg);
        }
        echo json_encode(['success' => true]);
    }
    public function get_formulir($val)
    {
        ck_uri('admin/formulir1');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'data_pengajuan.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'ASC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('data_pengajuan', en64('status_formulir="' . $val . '"'));
        $country = db('data_pengajuan')
            ->like('id', $search)
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->getWhere(['status_formulir' => $val])
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    /** =====================================================================
     * admin/formulir END
     *=====================================================================*/
    /** =====================================================================
     * admin/pengajuan START
     *=====================================================================*/
    public function pengajuan_1()
    {
        ck_uri();
        $this->part_in($this->dir() . 'pengajuan1', '', 'Menunggu');
    }
    public function pengajuan_2()
    {
        ck_uri();
        $this->part_in($this->dir() . 'pengajuan2', '', 'Di Batalkan');
    }
    public function pengajuan_3()
    {
        ck_uri();
        $this->part_in($this->dir() . 'pengajuan3', '', 'Pembayaran');
    }
    public function pengajuan_4()
    {
        ck_uri();
        $this->part_in($this->dir() . 'pengajuan4', '', 'SELESAI');
    }
    public function lunaskan()
    {
        ck_uri('admin/pengajuan_3');
        $id = $_REQUEST['id'];
        $hp = $_REQUEST['hp'];
        $o = db('data_pengajuan')->getWhere(['id' => $id], 1)->getRow();
        $x = db('m_penelitian')->getWhere(['id' => $o->id_penelitian], 1)->getRow();
        $ins = ($o->instansi == 'DALAM') ? 11 : 12;
        $no_urut = inc('no_urut_protokol') + 1;
        if (strlen($no_urut) == 1) {
            $no_urut = '00' . $no_urut;
        }
        if (strlen($no_urut) == 2) {
            $no_urut = '0' . $no_urut;
        }
        $no_protokol = $ins . date('ym') . $no_urut;
        $data = [
            'id' => $id,
            'id_penelitian' => $o->id_penelitian,
            'id_user' => $o->id_user,
            'id_admin' => me(),
            'no_protokol' => $no_protokol,
            'instansi' => $o->instansi,
            'status' => 'RILIS',
            'at_create' => date('d-m-Y H:i:s'),
            'tgl' => date('d'),
            'bln' => date('m'),
            'thn' => date('Y'),
        ];
        insert('f_peserta', $data);
        update('data_pengajuan', ['status' => 'SELESAI', 'status_formulir' => 'RILIS', 'id_admin' => me(), 'no_protokol' => $no_protokol, 'at_update' => date('d-m-Y H:i:s')], ['id' => $id]);
        update('temp_inc', ['code' => $no_urut], ['id' => 'no_urut_protokol']);
        if (inc('wa_status') == 'true') {
            $msg = inc('app-name') . '
=====================================           
Terimakasih ! Proses Pengajuan anda telah selesai,
Dan Formulir anda telah rilis Silahkan melakukan 
pengisian formulir lewat web atau app
NO Protokol formulir:
' . $no_protokol . '
=====================================
' . date("d-m-Y H:i:s");
            send_wa($hp, $msg);
        }
        echo json_encode(['success' => true]);
    }
    public function batalkan_pengajuan()
    {
        ck_uri('admin/pengajuan_1');
        $id = $_REQUEST['id'];
        $ket = $_REQUEST['ket'];
        $hp = $_REQUEST['hp'];
        update('data_pengajuan', ['ket' => $ket, 'status' => 'DI BATALKAN', 'id_admin' => me(), 'at_update' => date("d-m-Y H:i:s")], ['id' => $id]);
        if (inc('wa_status') == 'true') {
            $msg = inc('app-name') . '
=====================================           
Maaf Pengajuan Anda Telah di batalkan oleh admin,
Dengan Alasan :

' . $ket . '

=====================================
' . date("d-m-Y H:i:s");
            send_wa($hp, $msg);
        }
        echo json_encode(['success' => true]);
    }
    public function reupload_pengajuan()
    {
        ck_uri('admin/pengajuan_3');
        $id = $_REQUEST['id'];
        $ket2 = $_REQUEST['ket'];
        $hp = $_REQUEST['hp'];
        $o = db('data_pengajuan')->getWhere(['id' => $id], 1)->getRow();
        if ($o->bukti != null) {
            $path = FCPATH . 'img/bukti/' . $o->bukti;
            (!file_exists($path)) ?: unlink($path);
        }
        update('data_pengajuan', ['ket2' => $ket2, 'bukti' => '', 'id_admin' => me(), 'at_update' => date("d-m-Y H:i:s")], ['id' => $id]);
        if (inc('wa_status') == 'true') {
            $msg = inc('app-name') . '
=====================================           
Maaf ! Admin meminta anda untuk mengupload ulang bukti pembayaran,
Dengan Alasan :

' . $ket2 . '

=====================================
' . date("d-m-Y H:i:s");
            send_wa($hp, $msg);
        }
        echo json_encode(['success' => true]);
    }
    public function set_va()
    {
        ck_uri('admin/pengajuan_1');
        $id = $_REQUEST['id'];
        $no_va = $_REQUEST['no_va'];
        $hp = $_REQUEST['hp'];
        $rp = $_REQUEST['rp'];
        $harga = number_format($rp, 0, ',', '.');
        update('data_pengajuan', ['metode' => 'va', 'no_va' => $no_va, 'status' => 'PEMBAYARAN', 'id_admin' => me(), 'at_update' => date("d-m-Y H:i:s")], ['id' => $id]);
        if (inc('wa_status') == 'true') {
            $msg = inc('app-name') . '
=====================================           
Admin Telah menyetujui Pengajuan anda,
Silahkan melakukan pembayaran dengan Metode Virtual Account
sesuai Informasi di bawah .

NOMINAL BAYAR :
      Rp. ' .  $harga . '

NO VA :
      ' . $no_va . '

Ketika Selesai Melakukan Pembayaran,
Harap mengupload bukti pembayaran lewat web atu app
pada menu pembayaran Dengan ID : ' . $id . '
=====================================
' . date("d-m-Y H:i:s");
            send_wa($hp, $msg);
        }
        echo json_encode(['success' => true]);
    }
    public function set_bank()
    {
        ck_uri('admin/pengajuan_1');
        $id = $_REQUEST['id'];
        $id_bank = $_REQUEST['id_bank'];
        $hp = $_REQUEST['hp'];
        $rp = $_REQUEST['rp'];
        $harga = number_format($rp, 0, ',', '.');
        update('data_pengajuan', ['metode' => 'bank', 'id_bank' => $id_bank, 'status' => 'PEMBAYARAN', 'id_admin' => me(), 'at_update' => date("d-m-Y H:i:s")], ['id' => $id]);
        $o = db('m_rekening')->getWhere(['id' => $id_bank], 1)->getRow();
        if (inc('wa_status') == 'true') {
            $msg = inc('app-name') . '
=====================================           
Admin Telah menyetujui Pengajuan anda,
Silahkan melakukan pembayaran dengan Metode Transfer Bank
sesuai Informasi di bawah .

NOMINAL BAYAR :
      Rp. ' .  $harga . '

Nama Bank :
      ' . $o->nama_bank . '
      
NO Rekening :
      ' . $o->no . '

Ketika Selesai Melakukan Pembayaran,
Harap mengupload bukti pembayaran lewat web atu app
pada menu pembayaran Dengan ID : ' . $id . '
=====================================
' . date("d-m-Y H:i:s");
            send_wa($hp, $msg);
        }
        echo json_encode(['success' => true]);
    }
    public function del_pengajuan()
    {
        ck_uri('admin/pengajuan_1');
        $id = $_REQUEST['id'];
        $o = db('data_pengajuan')->getWhere(['id' => $id], 1)->getRow();
        if ($o->berkas != null) {
            $path = FCPATH . 'file/pdf/' . $o->berkas;
            (!file_exists($path)) ?: unlink($path);
        }
        if ($o->bukti != null) {
            $path = FCPATH . 'img/bukti/' . $o->bukti;
            (!file_exists($path)) ?: unlink($path);
        }
        if ($o->formulir != null) {
            $path = FCPATH . 'file/pdf/' . $o->formulir;
            (!file_exists($path)) ?: unlink($path);
        }
        if ($o->hasil != null) {
            $path = FCPATH . 'file/pdf/' . $o->hasil;
            (!file_exists($path)) ?: unlink($path);
        }
        $xx = db('data_reviewer')->getWhere(['id_dt' => $id], 1)->getResult();
        foreach ($xx as $x) {
            if ($x->formulir_dev != null) {
                $path = FCPATH . 'file/pdf/' . $x->formulir_dev;
                (!file_exists($path)) ?: unlink($path);
            }
        }
        delete('data_pengajuan', ['id' => $id]);
        delete('data_reviewer', ['id_dt' => $id]);
        delete('f_peserta', ['id' => $id]);
        echo json_encode(['success' => true]);
    }

    public function get_pengajuan_1()
    {
        ck_uri('admin/pengajuan_1');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'data_pengajuan.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'ASC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('data_pengajuan', en64('status="' . 'MENUNGGU' . '"'));
        $country = db('data_pengajuan')
            ->like('id', $search)
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->getWhere(['status' => 'MENUNGGU'])
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    public function get_pengajuan_2()
    {
        ck_uri('admin/pengajuan_2');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'data_pengajuan.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'ASC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('data_pengajuan', en64('status="' . 'DI BATALKAN' . '"'));
        $country = db('data_pengajuan')
            ->like('id', $search)
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->getWhere(['status' => 'DI BATALKAN'])
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    public function get_pengajuan_3()
    {
        ck_uri('admin/pengajuan_3');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'data_pengajuan.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'ASC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('data_pengajuan', en64('status="' . 'PEMBAYARAN' . '"'));
        $country = db('data_pengajuan')
            ->like('id', $search)
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->getWhere(['status' => 'PEMBAYARAN'])
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    public function get_pengajuan_4()
    {
        ck_uri('admin/pengajuan_4');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'data_pengajuan.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'DESC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('data_pengajuan', en64('status="' . 'SELESAI' . '"'));
        $country = db('data_pengajuan')
            ->like('id', $search)
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->getWhere(['status' => 'SELESAI'])
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    /** =====================================================================
     * admin/pengajuan END
     *=====================================================================*/
}
