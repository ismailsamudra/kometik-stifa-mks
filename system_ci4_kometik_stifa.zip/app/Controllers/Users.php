<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\RequestInterface;
use App\Models\Usersimport;

class Users extends BaseController
{
    public function __construct()
    {
        //......
    }
    private function dir()
    {
        return 'users/';
    }
    public function index()
    {
        go();
        $this->part_in($this->dir() . 'index', '', 'Users');
    }
    public function m_book()
    {
        $this->part_in($this->dir() . 'm_book', '', 'MANUAL BOOK');
    }
    public function get_m_book()
    {
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'manual_book.id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'ASC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        if (me() == '1' || me() == '28071986') {
            $result['total'] = num_rows('manual_book');
            $country = db('manual_book')
                ->orderBy($sort, $order)
                ->limit($offset, $rows)
                ->like('judul', $search)
                ->orLike('id', $search)
                ->get()
                ->getResult();
        } else {
            $result['total'] = num_rows('manual_book', en64(me('level') . '="1"'));
            $country = db('manual_book')
                ->orderBy($sort, $order)
                ->limit($offset, $rows)
                ->like('judul', $search)
                ->getWhere([me('level') => '1'])
                ->getResult();
        }
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    public function table($id)
    {
        ck_uri('users/table/' . $id);
        $data['id'] = $id;
        $this->part_in($this->dir() . 'table', $data, 'Users');
    }
    public function get_me()
    {
        $level = one('users', me())->level;
        $o = one($level, me());
        echo json_encode($o);
        exit;
    }
    public function biodata()
    {
        $m = cek_mobile();
        if ($m) {
            (me()) ?: go('login');
        } else {
            (me()) ?: go();
        }
        if (req()->getPost('nama')) {
            $x = db('users')->getWhere(['id' => me()])->getRow();
            $tb = $x->level . '_schema';
            $ooo = db($tb)
                ->orderBy('row', 'ASC')
                ->whereNotIn('id', ['akses', 'email', 'hp'])
                ->getWhere(['status' => 'true'])
                ->getResult();
            foreach ($ooo as $z) {
                $zdt = req()->getPost($z->id);
                update($x->level, [$z->id => $zdt], ['id' => me()]);
            }
            update('users', ['nama' => req()->getPost('nama'), 'jk' => req()->getPost('jk')], ['id' => me()]);
            session()->setFlashdata('info', 'Data Berhasil Di Update');
        }
        $data['id'] = me();
        $this->part_in($this->dir() . 'biodata', $data, 'Biodata');
    }
    public function crud($idx)
    {
        $loop = 1;
        $tb = $idx . '_schema';
        ck_uri('users/table/' . $idx);
        $oo = db($tb)->getWhere(['r' => '0'])->getResult();
        $id = htmlspecialchars($_REQUEST['id']);
        $nama = htmlspecialchars($_REQUEST['nama']);
        $hp = htmlspecialchars($_REQUEST['hp']);
        $email = htmlspecialchars($_REQUEST['email']);
        $jk = htmlspecialchars($_REQUEST['jk']);
        $akses = htmlspecialchars($_REQUEST['akses']);
        if ($id == 'insert') {
            if (cek_hp($hp) == true) {
                echo json_encode(array('errorMsg' => 'No Hp sudah Terdaftar.'));
                exit;
            }
            // if (cek_email($email) == true) {
            //     echo json_encode(array('errorMsg' => 'Email sudah Terdaftar.'));
            //     exit;
            // }
            $id = api_key();
            $sort = date('YmdHis');
            $password = ps(inc('pass_default'));
            $data_1 = [
                'id' => $id,
                'sort' => $sort,
                'password' => $password,
                'nama' => $nama,
                'email' => $email,
                'hp' => $hp,
                'jk' => $jk,
                'akses' => $akses,
                'level' => $idx,
                'create_at' => date('d/m/Y H:i'),
            ];
            insert('users', $data_1);
            $data_2 = [
                'id' => $id,
                'sort' => $sort,
                'status' => 'true',
                'akses' => $akses,
                'nama' => $nama,
                'email' => $email,
                'hp' => $hp,
                'jk' => $jk,
            ];
            insert($idx, $data_2);
            foreach ($oo as $o) {
                $looping = $loop++;
                $looping = htmlspecialchars($_REQUEST[$o->id]);
                update($idx, [$o->id => $looping], ['id' => $id]);
                if ($o->id == 'no_rm') {
                    $no_rm = inc('rm_b') + 1;
                    update($idx, [$o->id => $no_rm], ['id' => $id]);
                    update('temp_inc', ['code' => $no_rm], ['id' => 'rm_b']);
                }
            }
            echo json_encode(array('success' => true));
        } else {
            if (one('users', $id, 'hp') != $hp) {
                if (cek_hp($hp) == true) {
                    echo json_encode(array('errorMsg' => 'No Hp sudah Terdaftar.'));
                    exit;
                }
            }
            if (one('users', $id, 'email') != $email) {
                if (cek_email($email) == true) {
                    echo json_encode(array('errorMsg' => 'Email sudah Terdaftar.'));
                    exit;
                }
            }
            $data_1 = [
                'nama' => $nama,
                'email' => $email,
                'hp' => $hp,
                'jk' => $jk,
                'akses' => $akses,
                'update_at' => date('d/m/Y H:i'),
            ];
            update('users', $data_1, ['id' => $id]);
            $data_2 = [
                'nama' => $nama,
                'email' => $email,
                'akses' => $akses,
                'hp' => $hp,
                'jk' => $jk,
            ];
            update($idx, $data_2, ['id' => $id]);
            foreach ($oo as $o) {
                $looping = $loop++;
                $looping = htmlspecialchars($_REQUEST[$o->id]);
                update($idx, [$o->id => $looping], ['id' => $id]);
            }
            echo json_encode(array('success' => true));
        }
    }
    public function get($id)
    {
        ck_uri('users/table/' . $id);
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'sort';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'DESC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows($id);
        $country = db($id)
            ->like('nama', $search)
            ->orLike('email', $search)
            ->orLike('hp', $search)
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    public function delete()
    {
        $id = htmlspecialchars($_REQUEST['id']);
        $o = db('users')->getWhere(['id' => $id], 1)->getRow();
        ck_uri('users/table/' . $o->level);
        if ($o->foto != null) {
            $path = FCPATH . '/img/avatar/' . $o->foto;
            (!file_exists($path)) ?: unlink($path);
        }
        delete($o->level, ['id' => $id]);
        delete('users', ['id' => $id]);
        delete('web_team', ['user' => $id]);
        update('surat_ket_sakit', ['admin' => '1'], ['admin' => $id]);
        echo json_encode(array('success' => true));
    }
    public function set123()
    {
        $id = htmlspecialchars($_REQUEST['id']);
        $o = db('users')->getWhere(['id' => $id], 1)->getRow();
        ck_uri('users/table/' . $o->level);
        $password = ps(inc('pass_default'));
        update('users', ['password' => $password], ['id' => $id]);
        echo json_encode(array('success' => true));
    }
    public function ban()
    {
        $id = htmlspecialchars($_REQUEST['id']);
        $o = db('users')->getWhere(['id' => $id])->getRow();
        ck_uri('users/table/' . $o->level);
        $val = ($o->status == 'true') ? 'false' : $val = 'true';
        update('users', ['status' => $val], ['id' => $id]);
        update($o->level, ['status' => $val], ['id' => $id]);
        echo json_encode(array('success' => true));
    }
    public function crop_img()
    {
        if (isset($_POST["image"])) {
            $id = $_POST["id"];
            $date = date('Ydmhis');
            $tempdir = 'img/avatar/';
            $o = db('users')->getWhere(['id' => $id], 1)->getRow();
            if (me() != $id) {
                ck_uri('users/table/' . $o->level);
            }
            if ($o->foto != null) {
                $path = FCPATH . '/img/avatar/' . $o->foto;
                (!file_exists($path)) ?: unlink($path);
            }
            $data = $_POST["image"];
            $image_array_1 = explode(";", $data);
            $image_array_2 = explode(",", $image_array_1[1]);
            $data = base64_decode($image_array_2[1]);

            $imageName = $tempdir . 'avatar_' . $date . '.png';
            $foto = 'avatar_' . $date . '.png';
            file_put_contents($imageName, $data);

            update('users', ['foto' => $foto], ['id' => $id]);
            update($o->level, ['foto' => $foto], ['id' => $id]);
            echo '<img src="' . XROOT . 'img/avatar/' . $foto . '" width="100%">';
        }
    }
    //$_SERVER['REMOTE_ADDR']
    //$_SERVER['HTTP_X_FORWARDED_FOR'];
    //$_SERVER['HTTP_CLIENT_IP'];
    //redirect($_SERVER['HTTP_REFERER']);
    //========================================================================================
    //========================================================================================
    public function import()
    {
        ck_uri();
        $data['id'] = 'import';
        $this->part_in($this->dir() . 'import', $data, 'Import');
    }
    public function crud_import()
    {
        ck_uri('users/import');
        $id = htmlspecialchars($_REQUEST['id']);
        $nama = htmlspecialchars($_REQUEST['nama']);
        $hp = htmlspecialchars($_REQUEST['hp']);
        $email = htmlspecialchars($_REQUEST['email']);
        $jk = htmlspecialchars($_REQUEST['jk']);
        $nik = htmlspecialchars($_REQUEST['nik']);
        $tanggal_lahir = htmlspecialchars($_REQUEST['tanggal_lahir']);
        $alamat = htmlspecialchars($_REQUEST['alamat']);
        $data = [
            'nama' => $nama,
            'hp' => $hp,
            'email' => $email,
            'jk' => $jk,
            'nik' => $nik,
            'tanggal_lahir' => $tanggal_lahir,
            'alamat' => $alamat,
        ];
        if ($id == 'insert') {
            insert('users_import', $data);
        } else {
            update('users_import', $data, ['id' => $id]);
        }
        echo json_encode(array('success' => true));
    }
    public function get_import()
    {
        ck_uri('users/import');
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $rows = isset($_POST['rows']) ? intval($_POST['rows']) : 50;
        $sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'id';
        $order = isset($_POST['order']) ? strval($_POST['order']) : 'DESC';
        $search = isset($_POST['search_customer']) ? strval($_POST['search_customer']) : '';
        $offset = ($page - 1) * $rows;
        $result = array();
        $result['total'] = num_rows('users_import');
        $country = db('users_import')
            ->like('nama', $search)
            ->orLike('email', $search)
            ->orLike('hp', $search)
            ->orLike('nik', $search)
            ->orderBy($sort, $order)
            ->limit($rows, $offset)
            ->get()
            ->getResult();
        $result = array_merge($result, ['rows' => $country]);
        echo json_encode($result);
    }
    public function delete_import()
    {
        ck_uri('users/import');
        $id = htmlspecialchars($_REQUEST['id']);
        $o = db('users_import')->getWhere(['id' => $id], 1)->getRow();
        if ($o->foto != null) {
            $path = FCPATH . '/img/avatar/' . $o->foto;
            (!file_exists($path)) ?: unlink($path);
        }
        delete('users_import', ['id' => $id]);
        echo json_encode(array('success' => true));
    }
    public function crop_img_import()
    {
        ck_uri('users/import');
        if (isset($_POST["image"])) {
            $id = $_POST["id"];
            $date = date('Ydmhis');
            $tempdir = 'img/avatar/';
            $o = db('users_import')->getWhere(['id' => $id], 1)->getRow();
            if ($o->foto != null) {
                $path = FCPATH . '/img/avatar/' . $o->foto;
                (!file_exists($path)) ?: unlink($path);
            }
            $data = $_POST["image"];
            $image_array_1 = explode(";", $data);
            $image_array_2 = explode(",", $image_array_1[1]);
            $data = base64_decode($image_array_2[1]);

            $imageName = $tempdir . 'avatar_' . $date . '.png';
            $foto = 'avatar_' . $date . '.png';
            file_put_contents($imageName, $data);

            update('users_import', ['foto' => $foto], ['id' => $id]);
            echo '<img src="' . XROOT . 'img/avatar/' . $foto . '" width="100%">';
        }
    }
    public function up_csv()
    {
        ck_uri('users/import');
        if ($_FILES['file']['name'] != '') {
            $test = explode('.', $_FILES['file']['name']);
            $extension = end($test);
            $name = time() . '.' . $extension;

            $location = 'csvfile/' . $name;

            $res = move_uploaded_file($_FILES['file']['tmp_name'], $location);
            if ($res) {
                $path = FCPATH . "/csvfile/" . $name;
                $file = fopen($path, "r");
                $i = 0;
                $numberOfFields = 7;
                $csvArr = array();

                while (($filedata = fgetcsv($file, 100000, ',', '\\')) !== FALSE) {
                    $num = count($filedata);
                    if ($i > 0 && $num == $numberOfFields) {
                        $csvArr[$i]['nama'] = str_replace('"', '', $filedata[0]);
                        $csvArr[$i]['email'] = $filedata[1];
                        $csvArr[$i]['hp'] = $filedata[2];
                        $csvArr[$i]['jk'] = $filedata[3];
                        $csvArr[$i]['tanggal_lahir'] = $filedata[4];
                        $csvArr[$i]['alamat'] = $filedata[5];
                        $csvArr[$i]['nik'] = str_replace('"', '', $filedata[6]);
                    }
                    $i++;
                }
                fclose($file);
                $count = 0;
                $error = 0;
                foreach ($csvArr as $userdata) {
                    $students = new Usersimport();
                    $findRecord = $students->where('hp', $userdata['hp'])->countAllResults();
                    if ($findRecord == 0) {
                        if ($students->insert($userdata)) {
                            $count++;
                        }
                    }
                    if ($findRecord == 1) {
                        $error++;
                    }
                }
                session()->setFlashdata('message', $count . ' Data Berhasil Di Import. <br>' . $error . ' Data Gagal Di Import');
                session()->setFlashdata('alert-class', 'alert-success');
                echo $count . ' Data Berhasil Di Import. <br>' . $error . ' Data Gagal Di Import';
                // (!file_exists($path)) ?: unlink($path);
            }
        }
        // $input = $this->validate([
        //     'file' => 'uploaded[file]|max_size[file,204800]|ext_in[file,csv],'
        // ]);
        // if (!$input) {
        //     $data['validation'] = $this->validator;
        //     session()->setFlashdata('message', 'Format File harus csv.');
        //     session()->setFlashdata('alert-class', 'alert-danger');
        //     go('users/import');
        // } else {
        //     if ($file = $this->request->getFile('file')) {
        //         if ($file->isValid() && !$file->hasMoved()) {
        //             $newName = $file->getRandomName();
        //             $file->move(FCPATH . '/csvfile', $newName);
        //             $path = FCPATH . "/csvfile/" . $newName;
        //             $file = fopen($path, "r");
        //             $i = 0;
        //             $numberOfFields = 7;
        //             $csvArr = array();

        //             while (($filedata = fgetcsv($file, 100000, ',', '\\')) !== FALSE) {
        //                 $num = count($filedata);
        //                 if ($i > 0 && $num == $numberOfFields) {
        //                     $csvArr[$i]['nama'] = str_replace('"', '', $filedata[0]);
        //                     $csvArr[$i]['email'] = $filedata[1];
        //                     $csvArr[$i]['hp'] = $filedata[2];
        //                     $csvArr[$i]['jk'] = $filedata[3];
        //                     $csvArr[$i]['tanggal_lahir'] = $filedata[4];
        //                     $csvArr[$i]['alamat'] = $filedata[5];
        //                     $csvArr[$i]['nik'] = str_replace('"', '', $filedata[6]);
        //                 }
        //                 $i++;
        //             }
        //             fclose($file);
        //             $count = 0;
        //             $error = 0;
        //             foreach ($csvArr as $userdata) {
        //                 $students = new Usersimport();
        //                 $findRecord = $students->where('hp', $userdata['hp'])->countAllResults();
        //                 if ($findRecord == 0) {
        //                     if ($students->insert($userdata)) {
        //                         $count++;
        //                     }
        //                 }
        //                 if ($findRecord == 1) {
        //                     $error++;
        //                 }
        //             }
        //             session()->setFlashdata('message', $count . ' Data Berhasil Di Import. <br>' . $error . ' Data Gagal Di Import');
        //             session()->setFlashdata('alert-class', 'alert-success');
        //             (!file_exists($path)) ?: unlink($path);
        //         } else {
        //             session()->setFlashdata('message', 'CSV file coud not be imported.');
        //             session()->setFlashdata('alert-class', 'alert-danger');
        //         }
        //     } else {
        //         session()->setFlashdata('message', 'CSV file coud not be imported.');
        //         session()->setFlashdata('alert-class', 'alert-danger');
        //     }
        //     go('users/import');
        // }
    }
    //========================================================================================
}
