<?php

namespace App\Controllers;

class Doc extends BaseController
{
    public function __construct()
    {
        //(me()) ?: go();
    }
    public function index()
    {
        go();
    }
    public function sertifikat($id)
    {
        $data['id'] = $id;
        $status = db('data_pengajuan')->getWhere(['id' => $id], 1)->getRow()->status_formulir;
        $data['o'] = db('data_pengajuan')->getWhere(['id' => $id], 1)->getRow();
        if ($status == 'SERTIFIKAT') {
            return view('cetak/sertifikat', $data);
        } else {
            go();
        }
    }
    public function grafik($thn = null)
    {
        $data['thn'] = $thn;
        return view('doc/grafik', $data);
    }
}
