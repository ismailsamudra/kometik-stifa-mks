<?php
function temp_email($name, $to, $code, $db = null)
{
    $msg = '';
    if ($name == 'def_regist') {
        $msg = '
        <br>
        <center>
            ===================================================
              <h1>  ' . inc("app-name") . ' </h1> 
            ===================================================
        <br>
        Registrasi anda berhasil <br>
        Silahkan masukkan username<br>
        dan password di bawah untuk login.<br>
        <br>
            <small>
                <strong>
                    Username : <h3> ' . $to . '</h3> <br>
                    Password : <h2>' . $code . '</h2><br>
                </strong>
            </small>
            ===================================================
            <br>
            Website : ' . XURL . '
            <br>
            ' . date("d-m-Y H:i") . '
            <br>
            ===================================================
        </center>
        ';
    }
    if ($name == 'def_otp') {
        $msg = '
        <br>
        <center>
            ===================================================
              <h1>  ' . inc("app-name") . ' </h1> 
            ===================================================
        <br>
        Request Kode OTP Berhasil <br>
        Silahkan masukkan Kode OTP<br>
        Pada Kolom OTP , Untuk Mendapatkan Password Baru.<br>
        <br>
            <small>
                <strong>
                    Username : <h3> ' . $to . '</h3> <br>
                    Kode OTP : <h2>' . $code . '</h2><br>
                </strong>
            </small>
            ===================================================
            <br>
            Website : ' . XURL . '
            <br>
            ' . date("d-m-Y H:i") . '
            <br>
            ===================================================
        </center>
        ';
    }
    if ($name == 'def_forgot') {
        $msg = '
        <br>
        <center>
            ===================================================
              <h1>  ' . inc("app-name") . ' </h1> 
            ===================================================
        <br>
        Password Berhasil Di Reset<br>
        Silahkan masukkan username<br>
        dan password di bawah untuk login.<br>
        <br>
            <small>
                <strong>
                    Username : <h3> ' . $to . '</h3> <br>
                    Password Baru : <h2>' . $code . '</h2><br>
                </strong>
            </small>
            ===================================================
            <br>
            Website : ' . XURL . '
            <br>
            ' . date("d-m-Y H:i") . '
            <br>
            ===================================================
        </center>
        ';
    }
    return $msg;
}
function temp_wa($name, $to, $code, $db = null)
{
    $msg = '';
    if ($name == 'def_regist') {

        $msg = '* ' . inc("app-name") . ' 
===========================================
Registrasi anda berhasil
Silahkan masukkan username
dan password di bawah untuk login.

Username :  ' . $to . '
Password : ' . $code . '

===========================================
Website : ' . XURL . '
' . date("d-m-Y H:i") . '
===========================================';
    }
    if ($name == 'def_otp') {
        $msg = '* ' . inc("app-name") . ' 
===========================================
Request Kode OTP Berhasil
Silahkan masukkan Kode OTP
Pada Kolom OTP , Untuk Mendapatkan Password Baru.

Username : ' . $to . '
Kode OTP : ' . $code . '

===========================================
Website : ' . XURL . '
' . date("d-m-Y H:i") . '
===========================================';
    }
    if ($name == 'def_forgot') {
        $msg = '*' . inc("app-name") . '  
===========================================
Password Berhasil Di Reset
Silahkan masukkan username
dan password di bawah untuk login.

Username : ' . $to . '
Password Baru : ' . $code . '

===========================================
Website : ' . XURL . '
' . date("d-m-Y H:i") . '
===========================================';
    }
    return $msg;
}

function temp_surat($val, $nama_pasient, $judul, $hasil = null)
{
    $msg = '';
    if ($val == 'wa') {
        $res = ($hasil) ? $hasil : '';
        $msg = '* ' . inc("app-name") . '

===========================================
Kepada :  ' . $nama_pasient . '

Pembuatan Surat Telah Selesai.

Jenis Surat : ' . $judul . '
' . $res . '
Pada Tanggal : ' . date("d-m-Y H:i") . '
===========================================
Website : ' . XURL . '
===========================================';
    }
    if ($val == 'email') {
        $res = ($hasil) ? $hasil : '';
        $msg = '
        <br>
        <center>
            ===================================================
              <h1>  ' . inc("app-name") . ' </h1> 
            ===================================================
        <br>
        Kepada :  ' . $nama_pasient . '
        <br>
            <small>
                <strong>
                Pembuatan Berkas / Surat Telah Selesai.<br>
        
                Jenis Surat : ' . $judul . '<br>' . $res . '
                Pada Tanggal : ' . date("d-m-Y H:i") . '<br>
                </strong>
            </small>
            <br>
            ===================================================
            <br>
            Website : ' . XURL . '
            <br>
            ===================================================
        </center>
        ';
    }
    return $msg;
}
function temp_info($val, $nama_pasient, $content)
{
    $msg = '';
    if ($val == 'wa') {
        $msg = '* ' . inc("app-name") . '

===========================================
Kepada :  ' . $nama_pasient . '

' . $content . '
Pada Tanggal : ' . date("d-m-Y H:i") . '
===========================================
Website : ' . XURL . '
===========================================';
    }
    if ($val == 'email') {
        $msg = '
    <br>
    <center>
        ===================================================
          <h1>  ' . inc("app-name") . ' </h1> 
        ===================================================
    <br>
    Kepada :  ' . $nama_pasient . '
    <br>
        <small>
            <strong>
            ' . $content . '
            Pada Tanggal : ' . date("d-m-Y H:i") . '<br>
            </strong>
        </small>
        <br>
        ===================================================
        <br>
        Website : ' . XURL . '
        <br>
        ===================================================
    </center>
    ';
        return $msg;
    }
}
